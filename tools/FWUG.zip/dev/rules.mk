LOCAL_DIR := $(GET_LOCAL_DIR)

INCLUDES += -I$(LOCAL_DIR)/snor/include
INCLUDES += -I$(LOCAL_DIR)/clk/include
INCLUDES += -I$(LOCAL_DIR)/mbox/include

OBJS += \
	$(LOCAL_DIR)/dev.o

include dev/clk/rules.mk
include dev/mbox/rules.mk