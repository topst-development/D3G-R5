/****************************************************************************
 *   FileName    : mbox_cfg.c
 *   Description : Board Support Package for MICOM
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited to re-
distribution in source or binary form is strictly prohibited.
This source code is provided "AS IS" and nothing contained in this source code shall
constitute any express or implied warranty of any kind, including without limitation, any warranty
of merchantability, fitness for a particular purpose or non-infringement of any patent, copyright
or other third party intellectual property right. No warranty is made, express or implied,
regarding the information's accuracy, completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from, out of
or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************/
#if 1
#include <debug.h>
#include <platform/interrupts.h>
#include <platform/irqs.h>
#include <platform/iomap.h>
#include <sys/types.h>
#include <kernel/thread.h>

#include <reg.h>
#include <mbox_phy.h>
#include <mbox_dev.h>
#else
#include <types.h>
#include <debug.h>
#include <osal.h>
#include <mbox_phy.h>
#include <mbox_dev.h>
#endif

mbox_callback_t mbox_callback;

int32 mbox_os_init(uint32 *lock)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_SemaCreate(lock, (const uint8 *)"Mutex Created", 1ul, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_SemaCreate fail [%d]\n", __func__, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_os_deinit(uint32 *lock)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_SemaDelete(*lock)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_DemaDelete lock[%d] fail [%d]\n", __func__, (int) lock, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_wlock(uint32 lock)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_SemaObtain(lock, OSAL_NO_TIMEOUT, OSAL_API_OPT_BLOCKING)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_SemaObtain lock[%d] fail [%d]\n", __func__, (int) lock, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_wunlock(uint32 lock)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_SemaRelease(lock)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_SemaRelease lock[%d] fail [%d]\n", __func__, (int) lock, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_rsiginit(uint32 *id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_EventCreate(id, (const uint8 *)"signal event created", 0, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_EventCreate id[%d] fail [%d]\n", __func__, (int) *id, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_rsigdeinit(uint32 *id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_EventDelete(*id, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_EventDelete id[%d] fail [%d]\n", __func__, (int) *id, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_rsignal(uint32 id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_SetEvent(id, 0x00000001ul, OSAL_EVENT_SET_OPT_FLAG_SET, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_SetEvent id[%d] fail [%d]\n", __func__, (int) id, (int) ret);
    }
    if ((ret = OSAL_SetEvent(id, 0x00000001ul, OSAL_EVENT_SET_OPT_FLAG_CLR, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_SetEvent id[%d] fail [%d]\n", __func__, (int) id, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_rsigwait(uint32 id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    int32 err;
    if ((ret = OSAL_GetEvent(id, 0x00000001ul, 0, (OSAL_EVENT_OPT_SET_ANY|OSAL_API_OPT_BLOCKING), &err, 0)) != 1)
    {
        printf("%s OSAL_GetEvent id[%d] fail [%d]\n", __func__, (int) id, (int) ret);
        ret = MBOX_ERR_TIMEOUT;
    }
    else
    {
        ret = MBOX_SUCCESS;
    }
#endif
    return ret;
}

int32 mbox_wsiginit(uint32 *id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_EventCreate(id, (const uint8 *)"signal event created", 0, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_EventCreate id[%d] fail [%d]\n", __func__, (int) *id, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_wsigdeinit(uint32 *id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_EventDelete(*id, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_EventDelete id[%d] fail [%d]\n", __func__, (int) *id, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_wsigclr(uint32 id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_SetEvent(id, 0x00000001ul, OSAL_EVENT_SET_OPT_FLAG_CLR, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_SetEvent id[%d] fail [%d]\n", __func__, (int) id, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_wsignal(uint32 id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    if ((ret = OSAL_SetEvent(id, 0x00000001ul, OSAL_EVENT_SET_OPT_FLAG_SET, 0)) != OSAL_ERR_NONE)
    {
        printf("[E] %s OSAL_SetEvent id[%d] fail [%d]\n", __func__, (int) id, (int) ret);
    }
#endif
    return ret;
}

int32 mbox_wsigwait(uint32 id)
{
    int32 ret = MBOX_SUCCESS;
#if 0 //fwug
    int32 err;
    if ((ret = OSAL_GetEvent(id, 0x00000001ul, 3, (OSAL_EVENT_OPT_SET_ANY|OSAL_API_OPT_BLOCKING), &err, 0)) != 1)
    {
        printf("%s OSAL_GetEvent id[%d] fail [%d]\n", __func__, (int) id, (int) ret);
        ret = MBOX_ERR_TIMEOUT;
    }
    else
    {
        ret = MBOX_SUCCESS;
    }
#endif
    return ret;
}

void mbox_init(void)
{
#if 1
    mbox_callback.osinit = NULL;        // Thread Safe For Writing.
    mbox_callback.osdeinit = NULL;    // Thread Safe For Writing.
    mbox_callback.wlock = NULL;           // Thread Safe For Writing.
    mbox_callback.wunlock = NULL;       // Thread Safe For Writing.
    mbox_callback.rsiginit = NULL;     // Blocking Read  Depending on OS.
    mbox_callback.rsigdeinit = NULL; // Blocking Read  Depending on OS.
    mbox_callback.rsignal = NULL;       // Blocking Read  Depending on OS.
    mbox_callback.rsigwait = NULL;     // Blocking Read  Depending on OS.
    mbox_callback.wsiginit = NULL;     // Blocking Write Depending on OS.
    mbox_callback.wsigdeinit = NULL; // Blocking Write Depending on OS.
    mbox_callback.wsignal = NULL;       // Blocking Write Depending on OS.
    mbox_callback.wsigclr = NULL;       // Blocking Write Depending on OS.
    mbox_callback.wsigwait = NULL;     // Blocking Write Depending on OS.
#else
    mbox_callback.osinit = mbox_os_init;        // Thread Safe For Writing.
    mbox_callback.osdeinit = mbox_os_deinit;    // Thread Safe For Writing.
    mbox_callback.wlock = mbox_wlock;           // Thread Safe For Writing.
    mbox_callback.wunlock = mbox_wunlock;       // Thread Safe For Writing.
    mbox_callback.rsiginit = mbox_rsiginit;     // Blocking Read  Depending on OS.
    mbox_callback.rsigdeinit = mbox_rsigdeinit; // Blocking Read  Depending on OS.
    mbox_callback.rsignal = mbox_rsignal;       // Blocking Read  Depending on OS.
    mbox_callback.rsigwait = mbox_rsigwait;     // Blocking Read  Depending on OS.
    mbox_callback.wsiginit = mbox_wsiginit;     // Blocking Write Depending on OS.
    mbox_callback.wsigdeinit = mbox_wsigdeinit; // Blocking Write Depending on OS.
    mbox_callback.wsignal = mbox_wsignal;       // Blocking Write Depending on OS.
    mbox_callback.wsigclr = mbox_wsigclr;       // Blocking Write Depending on OS.
    mbox_callback.wsigwait = mbox_wsigwait;     // Blocking Write Depending on OS.
#endif

    #if 1
    if (mbox_dev_init(MBOX_CH_CA07_NS, INT_LEVEL_8, MBOX_MAX_MULTI_OPEN, &mbox_callback) != 0)
        printf("[E] mbox init fail for MBOX_CH_CA07_NS\n");
    if (mbox_dev_init(MBOX_CH_CM04_NS, INT_LEVEL_8, MBOX_MAX_MULTI_OPEN, &mbox_callback) != 0)
        printf("[E] mbox init fail for MBOX_CH_CM04_NS\n");
    #else
    if (mbox_dev_init(MBOX_CH_CA53, INT_LEVEL_8, MBOX_MAX_MULTI_OPEN, &mbox_callback) != 0)
        printf("[E] mbox init fail for MBOX_CH_CA53\n");
    if (mbox_dev_init(MBOX_CH_CA53_NS, INT_LEVEL_8, MBOX_MAX_MULTI_OPEN, &mbox_callback) != 0)
        printf("[E] mbox init fail for MBOX_CH_CA53_NS\n");
    if (mbox_dev_init(MBOX_CH_CA07, INT_LEVEL_8, MBOX_MAX_MULTI_OPEN, &mbox_callback) != 0)
        printf("[E] mbox init fail for MBOX_CH_CA07\n");
    if (mbox_dev_init(MBOX_CH_CA07_NS, INT_LEVEL_8, MBOX_MAX_MULTI_OPEN, &mbox_callback) != 0)
        printf("[E] mbox init fail for MBOX_CH_CA07_NS\n");
    #endif

}
