/****************************************************************************************
 *   FileName    : mbox_dev.c
 *   Description :
 ****************************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited
to re-distribution in source or binary form is strictly prohibited.
This source code is provided ¡°AS IS¡± and nothing contained in this source code
shall constitute any express or implied warranty of any kind, including without limitation,
any warranty of merchantability, fitness for a particular purpose or non-infringement of any patent,
copyright or other third party intellectual property right.
No warranty is made, express or implied, regarding the information¡¯s accuracy,
completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from,
out of or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************************/
#if 1
#include <debug.h>
#include <platform/interrupts.h>
#include <platform/irqs.h>
#include <platform/iomap.h>
#include <sys/types.h>
#include <kernel/thread.h>
	
#include <reg.h>
#include <mbox_phy.h>
#include <mbox_dev.h>
#else
#include <types.h>
#include <string.h>
#include "bsp_int.h"
#include "mbox_phy.h"
#include "mbox_dev.h"
#endif

//#define MBOX_DBG
#ifdef MBOX_DBG
#include "debug.h"
#define MBOXL(fmt, args...)    printf(fmt, ## args)
#else
#define MBOXL(fmt, args...)    do {} while(0)
#endif

void mbox_dev_register_irq(MBOX_CH ch, uint32 no, int_handler fn);
void mbox_dev_clear_irq(uint32 no);

hashmap_t devIdMap[MBOX_CH_MAX][MBOX_MAX_MULTI_OPEN];

mbox_isr_func_t isr_func[MBOX_CH_MAX] = 
{
    {(int_handler)mbox_dev_isr_received_a53_secure,    (int_handler)mbox_dev_isr_write_confirm_a53_secure},
    {(int_handler)mbox_dev_isr_received_a53_nonsecure, (int_handler)mbox_dev_isr_write_confirm_a53_nonsecure},
    {(int_handler)mbox_dev_isr_received_a07_secure,    (int_handler)mbox_dev_isr_write_confirm_a07_secure},
    {(int_handler)mbox_dev_isr_received_a07_nonsecure, (int_handler)mbox_dev_isr_write_confirm_a07_nonsecure},
    {(int_handler)mbox_dev_isr_received_m04_nonsecure, (int_handler)mbox_dev_isr_write_confirm_m04_nonsecure},
};

 /* ====================================================================== *
  *  COPYRIGHT (C) 1986 Gary S. Brown.  You may use this program, or       *
  *  code or tables extracted from it, as desired without restriction.     *
  *                                                                        *
  *  First, the polynomial itself and its table of feedback terms.  The    *
  *  polynomial is                                                         *
  *  X^32+X^26+X^23+X^22+X^16+X^12+X^11+X^10+X^8+X^7+X^5+X^4+X^2+X^1+X^0   *
  *                                                                        *
  *  Note that we take it "backwards" and put the highest-order term in    *
  *  the lowest-order bit.  The X^32 term is "implied"; the LSB is the     *
  *  X^31 term, etc.  The X^0 term (usually shown as "+1") results in      *
  *  the MSB being 1.                                                      *
  *                                                                        *
  *  Note that the usual hardware shift register implementation, which     *
  *  is what we're using (we're merely optimizing it by doing eight-bit    *
  *  chunks at a time) shifts bits into the lowest-order term.  In our     *
  *  implementation, that means shifting towards the right.  Why do we     *
  *  do it this way?  Because the calculated CRC must be transmitted in    *
  *  order from highest-order term to lowest-order term.  UARTs transmit   *
  *  characters in order from LSB to MSB.  By storing the CRC this way,    *
  *  we hand it to the UART in the order low-byte to high-byte; the UART   *
  *  sends each low-bit to hight-bit; and the result is transmission bit   *
  *  by bit from highest- to lowest-order term without requiring any bit   *
  *  shuffling on our part.  Reception works similarly.                    *
  *                                                                        *
  *  The feedback terms table consists of 256, 32-bit entries.  Notes:     *
  *                                                                        *
  *      The table can be generated at runtime if desired; code to do so   *
  *      is shown later.  It might not be obvious, but the feedback        *
  *      terms simply represent the results of eight shift/xor opera-      *
  *      tions for all combinations of data and CRC register values.       *
  *                                                                        *
  *      The values must be right-shifted by eight bits by the "updcrc"    *
  *      logic; the shift must be unsigned (bring in zeroes).  On some     *
  *      hardware you could probably optimize the shift in assembler by    *
  *      using byte-swap instructions.                                     *
  *      polynomial $edb88320                                              *
  *                                                                        *
  * ====================================================================== */
static unsigned long crc32_tab[] = 
{
      0x00000000L, 0x77073096L, 0xee0e612cL, 0x990951baL, 0x076dc419L,
      0x706af48fL, 0xe963a535L, 0x9e6495a3L, 0x0edb8832L, 0x79dcb8a4L,
      0xe0d5e91eL, 0x97d2d988L, 0x09b64c2bL, 0x7eb17cbdL, 0xe7b82d07L,
      0x90bf1d91L, 0x1db71064L, 0x6ab020f2L, 0xf3b97148L, 0x84be41deL,
      0x1adad47dL, 0x6ddde4ebL, 0xf4d4b551L, 0x83d385c7L, 0x136c9856L,
      0x646ba8c0L, 0xfd62f97aL, 0x8a65c9ecL, 0x14015c4fL, 0x63066cd9L,
      0xfa0f3d63L, 0x8d080df5L, 0x3b6e20c8L, 0x4c69105eL, 0xd56041e4L,
      0xa2677172L, 0x3c03e4d1L, 0x4b04d447L, 0xd20d85fdL, 0xa50ab56bL,
      0x35b5a8faL, 0x42b2986cL, 0xdbbbc9d6L, 0xacbcf940L, 0x32d86ce3L,
      0x45df5c75L, 0xdcd60dcfL, 0xabd13d59L, 0x26d930acL, 0x51de003aL,
      0xc8d75180L, 0xbfd06116L, 0x21b4f4b5L, 0x56b3c423L, 0xcfba9599L,
      0xb8bda50fL, 0x2802b89eL, 0x5f058808L, 0xc60cd9b2L, 0xb10be924L,
      0x2f6f7c87L, 0x58684c11L, 0xc1611dabL, 0xb6662d3dL, 0x76dc4190L,
      0x01db7106L, 0x98d220bcL, 0xefd5102aL, 0x71b18589L, 0x06b6b51fL,
      0x9fbfe4a5L, 0xe8b8d433L, 0x7807c9a2L, 0x0f00f934L, 0x9609a88eL,
      0xe10e9818L, 0x7f6a0dbbL, 0x086d3d2dL, 0x91646c97L, 0xe6635c01L,
      0x6b6b51f4L, 0x1c6c6162L, 0x856530d8L, 0xf262004eL, 0x6c0695edL,
      0x1b01a57bL, 0x8208f4c1L, 0xf50fc457L, 0x65b0d9c6L, 0x12b7e950L,
      0x8bbeb8eaL, 0xfcb9887cL, 0x62dd1ddfL, 0x15da2d49L, 0x8cd37cf3L,
      0xfbd44c65L, 0x4db26158L, 0x3ab551ceL, 0xa3bc0074L, 0xd4bb30e2L,
      0x4adfa541L, 0x3dd895d7L, 0xa4d1c46dL, 0xd3d6f4fbL, 0x4369e96aL,
      0x346ed9fcL, 0xad678846L, 0xda60b8d0L, 0x44042d73L, 0x33031de5L,
      0xaa0a4c5fL, 0xdd0d7cc9L, 0x5005713cL, 0x270241aaL, 0xbe0b1010L,
      0xc90c2086L, 0x5768b525L, 0x206f85b3L, 0xb966d409L, 0xce61e49fL,
      0x5edef90eL, 0x29d9c998L, 0xb0d09822L, 0xc7d7a8b4L, 0x59b33d17L,
      0x2eb40d81L, 0xb7bd5c3bL, 0xc0ba6cadL, 0xedb88320L, 0x9abfb3b6L,
      0x03b6e20cL, 0x74b1d29aL, 0xead54739L, 0x9dd277afL, 0x04db2615L,
      0x73dc1683L, 0xe3630b12L, 0x94643b84L, 0x0d6d6a3eL, 0x7a6a5aa8L,
      0xe40ecf0bL, 0x9309ff9dL, 0x0a00ae27L, 0x7d079eb1L, 0xf00f9344L,
      0x8708a3d2L, 0x1e01f268L, 0x6906c2feL, 0xf762575dL, 0x806567cbL,
      0x196c3671L, 0x6e6b06e7L, 0xfed41b76L, 0x89d32be0L, 0x10da7a5aL,
      0x67dd4accL, 0xf9b9df6fL, 0x8ebeeff9L, 0x17b7be43L, 0x60b08ed5L,
      0xd6d6a3e8L, 0xa1d1937eL, 0x38d8c2c4L, 0x4fdff252L, 0xd1bb67f1L,
      0xa6bc5767L, 0x3fb506ddL, 0x48b2364bL, 0xd80d2bdaL, 0xaf0a1b4cL,
      0x36034af6L, 0x41047a60L, 0xdf60efc3L, 0xa867df55L, 0x316e8eefL,
      0x4669be79L, 0xcb61b38cL, 0xbc66831aL, 0x256fd2a0L, 0x5268e236L,
      0xcc0c7795L, 0xbb0b4703L, 0x220216b9L, 0x5505262fL, 0xc5ba3bbeL,
      0xb2bd0b28L, 0x2bb45a92L, 0x5cb36a04L, 0xc2d7ffa7L, 0xb5d0cf31L,
      0x2cd99e8bL, 0x5bdeae1dL, 0x9b64c2b0L, 0xec63f226L, 0x756aa39cL,
      0x026d930aL, 0x9c0906a9L, 0xeb0e363fL, 0x72076785L, 0x05005713L,
      0x95bf4a82L, 0xe2b87a14L, 0x7bb12baeL, 0x0cb61b38L, 0x92d28e9bL,
      0xe5d5be0dL, 0x7cdcefb7L, 0x0bdbdf21L, 0x86d3d2d4L, 0xf1d4e242L,
      0x68ddb3f8L, 0x1fda836eL, 0x81be16cdL, 0xf6b9265bL, 0x6fb077e1L,
      0x18b74777L, 0x88085ae6L, 0xff0f6a70L, 0x66063bcaL, 0x11010b5cL,
      0x8f659effL, 0xf862ae69L, 0x616bffd3L, 0x166ccf45L, 0xa00ae278L,
      0xd70dd2eeL, 0x4e048354L, 0x3903b3c2L, 0xa7672661L, 0xd06016f7L,
      0x4969474dL, 0x3e6e77dbL, 0xaed16a4aL, 0xd9d65adcL, 0x40df0b66L,
      0x37d83bf0L, 0xa9bcae53L, 0xdebb9ec5L, 0x47b2cf7fL, 0x30b5ffe9L,
      0xbdbdf21cL, 0xcabac28aL, 0x53b39330L, 0x24b4a3a6L, 0xbad03605L,
      0xcdd70693L, 0x54de5729L, 0x23d967bfL, 0xb3667a2eL, 0xc4614ab8L,
      0x5d681b02L, 0x2a6f2b94L, 0xb40bbe37L, 0xc30c8ea1L, 0x5a05df1bL,
      0x2d02ef8dL
};

 /* ====================================================================== *
  * Function    : mbox_dev_init                                            *
  * Return      : int32                                                    *
  * Parameters  : MBOX_CH ch ()                                            *
  *               uint32 ilv ()                                            *
  *               uint8 opn ()                                             *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_init(MBOX_CH ch, uint32 ilv, uint8 opn, mbox_callback_t *func)
{
    int32 ret = MBOX_SUCCESS;

    if ((ret = mbox_phy_ready(ch, opn)) == MBOX_SUCCESS)
    {
        mbox_phy_bitset_ctrl(ch, FLUSH_BIT|D_FLUSH_BIT);
        mbox_phy_bitset_ctrl(ch, RD_IEN_BIT|ilv);
        mbox_dev_register_irq(ch, mboxInfo[ch]._rirq, isr_func[ch]._recv);
        mbox_phy_set_own_tmn_sts(ch, MBOX_ENABLE);

        if (func != NULL)
        {
            mboxInfo[ch]._os_func.osinit = func->osinit;
            mboxInfo[ch]._os_func.wlock = func->wlock;
            mboxInfo[ch]._os_func.wunlock = func->wunlock;
            mboxInfo[ch]._os_func.rsiginit = func->rsiginit;
            mboxInfo[ch]._os_func.rsigdeinit = func->rsigdeinit;
            mboxInfo[ch]._os_func.rsignal = func->rsignal;
            mboxInfo[ch]._os_func.rsigwait = func->rsigwait;
            mboxInfo[ch]._os_func.wsiginit = func->wsiginit;
            mboxInfo[ch]._os_func.wsigdeinit = func->wsigdeinit;
            mboxInfo[ch]._os_func.wsignal = func->wsignal;
            mboxInfo[ch]._os_func.wsigclr = func->wsigclr;
            mboxInfo[ch]._os_func.wsigwait = func->wsigwait;
            if (mboxInfo[ch]._os_func.osinit != NULL)
                mboxInfo[ch]._os_func.osinit((uint32 *) &mboxInfo[ch]._lock);
            if (mboxInfo[ch]._os_func.wsiginit != NULL)
            {
                mboxInfo[ch]._os_func.wsiginit((uint32 *) &mboxInfo[ch]._sigId);
                mbox_dev_register_irq(ch, mboxInfo[ch]._wirq, isr_func[ch]._write);
                mbox_phy_bitset_ctrl(ch, WR_IEN_BIT);
            }
        }
        else
        {
            MBOXL("[W] %s callback is null\n", __func__);
        }
    }
    else
    {
        MBOXL("[E] %s mbox_phy_ready fail [%d]\n", __func__, (int) ret);
    }

    return ret;
}

 /* ====================================================================== *
  * Function    : mbox_dev_open                                            *
  * Return      : int32                                                    *
  * Parameters  : MBOX_CH ch ()                                            *
  *               char *dev_name ()                                        *
  *               uint8 flag ()                                            *
  * Description :                                                          *
  * ====================================================================== */
mbox_dvice_t *mbox_dev_open(MBOX_CH ch, char *dev_name, uint8 flag)
{
    int dev_id = -1;
    int32 ret = MBOX_SUCCESS;
    mbox_dvice_t *mbox_dev = NULL;

    if ((ch < MBOX_CH_MAX) && (ch > MBOX_CH_INVALID))
    {
        if (mboxInfo[ch]._os_func.wlock != NULL)
        {
            if ((ret = mboxInfo[ch]._os_func.wlock(mboxInfo[ch]._lock)) != MBOX_SUCCESS)
            {   mbox_dev = NULL;
                goto err;
            }
        }

        if ((dev_name != NULL) && ((dev_id = mbox_dev_new(ch, (unsigned char *) dev_name)) >= 0))
        {
            if ((mboxInfo[ch]._dev_list != NULL) &&
                (mboxInfo[ch]._dev_list[dev_id].queue != NULL))
            {
    
                mboxInfo[ch]._dev_list[dev_id].ch           = ch;
                mboxInfo[ch]._dev_list[dev_id].devId        = dev_id;
                mboxInfo[ch]._dev_list[dev_id].flag         = flag;
                mboxInfo[ch]._dev_list[dev_id].queue->front = -1;
                mboxInfo[ch]._dev_list[dev_id].queue->rear  = -1;
                mboxInfo[ch]._dev_list[dev_id].dev_name[0] = dev_name[0];
                mboxInfo[ch]._dev_list[dev_id].dev_name[1] = dev_name[1];
                mboxInfo[ch]._dev_list[dev_id].dev_name[2] = dev_name[2];
                mboxInfo[ch]._dev_list[dev_id].dev_name[3] = dev_name[3];
                mboxInfo[ch]._dev_list[dev_id].dev_name[4] = dev_name[4];
                mboxInfo[ch]._dev_list[dev_id].dev_name[5] = dev_name[5];
                mboxInfo[ch]._dev_list[dev_id].dev_name[6] = dev_name[6];
                if (mboxInfo[ch]._os_func.rsiginit != NULL)
                    mboxInfo[ch]._os_func.rsiginit((uint32 *) &mboxInfo[ch]._dev_list[dev_id].sigId);
                mbox_dev = &mboxInfo[ch]._dev_list[dev_id];
            }
            else
            {
                MBOXL("[E] %s : open fail ch[%d] not initialized\n", __FUNCTION__, ch);
            }
        }
        else
        {
            MBOXL("[E] %s : open fail ch[%d] dev[%s] dev_id[%d]\n", __func__, ch, dev_name, (int) dev_id);
        }
    
        if (mboxInfo[ch]._os_func.wunlock != NULL)
        {
            if ((ret = mboxInfo[ch]._os_func.wunlock(mboxInfo[ch]._lock)) != MBOX_SUCCESS)
            {
                mbox_dev = NULL;
                goto err;
            }
        }
    }
    else
    {
        MBOXL("[E] %s : open fail ch[%d] dev[%d] invalid param\n", __FUNCTION__, (int) ch, (int) dev_id);
    }

err:
    return mbox_dev;
}

#if 1 //fwug
/* ====================================================================== *
 * Function    : mbox_dev_send                                            *
 * Return      : int32                                                    *
 * Parameters  : mbox_dvice_t *dev ()                                     *
 *               uint32 *cmd ()                                           *
 *               uint32 *data ()                                          *
 *               uint32 len ()                                            *
 * Description :                                                          *
 * ====================================================================== */
int32 mbox_dev_send(mbox_dvice_t *dev, uint32 *cmd, uint32 *data, uint32 len)
{
    int32  ret    = MBOX_SUCCESS;
    uint32 scmd[8] = {0, };

    if (MBOX_DEV_NULLCHK(dev) && MBOX_DEV_NULLCHK(data) && MBOX_DEV_VALIDDL(len))
    {
        if (mboxInfo[dev->ch]._os_func.wlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }

        if (MBOX_DEV_VALIDID(dev->devId) && MBOX_DEV_VALIDCH(dev->ch))
        {
            if ((mbox_phy_empty_mdata(dev->ch) == 0x01) && (mbox_phy_empty_mcmd(dev->ch) == 0x01))
            {
                if (mbox_phy_write_data(dev->ch, data, len) == MBOX_SUCCESS)
                {
                    scmd[0] = ((dev->dev_name[5] << 24) | dev->dev_name[4] << 16) & 0xFFFF0000;
                    scmd[1] = cmd[0]; scmd[2] = cmd[1]; scmd[3] = cmd[2]; scmd[4] = cmd[3]; scmd[5] = cmd[4]; scmd[6] = cmd[5];
                    scmd[7] = (dev->dev_name[3] << 24) | (dev->dev_name[2] << 16) | (dev->dev_name[1] << 8) | dev->dev_name[0];

                    if (mboxInfo[dev->ch]._os_func.wsigclr != NULL)
                    {
                        ret = mboxInfo[dev->ch]._os_func.wsigclr(mboxInfo[dev->ch]._sigId);
                    }

                    mbox_phy_bitclear_ctrl(dev->ch, OEN_BIT);
                    ret = mbox_phy_write_cmd(dev->ch, scmd); 
                    mbox_phy_bitset_ctrl(dev->ch, OEN_BIT);
                
                    if (mboxInfo[dev->ch]._os_func.wsigwait != NULL)
                    {
                        ret = mboxInfo[dev->ch]._os_func.wsigwait(mboxInfo[dev->ch]._sigId);
                    }
                }
                else
                {
                    ret = MBOX_ERR_WRITE; 
                    MBOXL("[E] %s : mbox phy write err[%d]\n", __FUNCTION__, ret);
                }
            }
            else
            {
                ret =  MBOX_ERR_FIFO_FULL;
                MBOXL("[E] %s : no space for len[%d]\n", __FUNCTION__, len);
            }
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
            MBOXL("[E] %s : devId %d, ch %d \n", __FUNCTION__, dev->devId, dev->ch);
        }

        if (mboxInfo[dev->ch]._os_func.wunlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wunlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
        MBOXL("[E] %s : send fail dev[%p] data[%p] len[%d] invalid param\n", __FUNCTION__, dev, data, (int) len);
    }

err:
    return ret;
}
#endif

 /* ====================================================================== *
  * Function    : mbox_dev_send_cmd                                        *
  * Return      : int32                                                    *
  * Parameters  : mbox_dvice_t *dev ()                                     *
  *               uint32 *cmd ()                                           *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_send_cmd(mbox_dvice_t *dev, uint32 *cmd)
{
    int32 ret = MBOX_SUCCESS;
    uint32 scmd[8] = {0, };

    if (MBOX_DEV_NULLCHK(dev) && MBOX_DEV_NULLCHK(cmd))
    {
        if (mboxInfo[dev->ch]._os_func.wlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }

        if (MBOX_DEV_VALIDID(dev->devId) && MBOX_DEV_VALIDCH(dev->ch))
        {
            if (mbox_phy_empty_mcmd(dev->ch) == 0x01)
            {
                scmd[0] = ((dev->dev_name[5] << 24) | (dev->dev_name[4] << 16)) & 0xFFFF0000;
                scmd[1] = cmd[0]; scmd[2] = cmd[1]; scmd[3] = cmd[2]; scmd[4] = cmd[3]; scmd[5] = cmd[4]; scmd[6] = cmd[5];
                scmd[7] = (dev->dev_name[3] << 24) | (dev->dev_name[2] << 16) | (dev->dev_name[1] << 8) | dev->dev_name[0];

                if (mboxInfo[dev->ch]._os_func.wsigclr != NULL)
                {
                    ret = mboxInfo[dev->ch]._os_func.wsigclr(mboxInfo[dev->ch]._sigId);
                }

                mbox_phy_bitclear_ctrl(dev->ch, OEN_BIT);
                ret = mbox_phy_write_cmd(dev->ch, scmd); 
                mbox_phy_bitset_ctrl(dev->ch, OEN_BIT); 

                if (mboxInfo[dev->ch]._os_func.wsigwait != NULL)
                {
                    ret = mboxInfo[dev->ch]._os_func.wsigwait(mboxInfo[dev->ch]._sigId);
                }
            }
            else
            {
                ret =  MBOX_ERR_FIFO_FULL;
                MBOXL("[E] %s : open fail tx cmd fifo full\n", __FUNCTION__);
            }
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
            MBOXL("[E] %s : devId %d, ch %d \n", __FUNCTION__, dev->devId, dev->ch);
        }
            
        if (mboxInfo[dev->ch]._os_func.wunlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wunlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }
    }
    else    
    {
        ret = MBOX_ERR_ARGUMENT; 
        MBOXL("[E] %s : send fail dev[%p] cmd[%p] invalid param\n", __FUNCTION__, dev, cmd);
    }

err:
    return ret;
}

#if 1 //fwug
/* ====================================================================== *
 * Function    : mbox_dev_send_data                                       *
 * Return      : int32                                                    *
 * Parameters  : mbox_dvice_t *dev ()                                     *
 *               uint32 *cmd ()                                           *
 *               uint32 *data ()                                          *
 *               uint32 len ()                                            *
 * Description :                                                          *
 * ====================================================================== */
int32 mbox_dev_send_data(mbox_dvice_t *dev, uint32 *data, uint32 len)
{
    int32  ret    = MBOX_SUCCESS;
    uint32 scmd[8] = {0, };

    if (MBOX_DEV_NULLCHK(dev) && MBOX_DEV_NULLCHK(data) && MBOX_DEV_VALIDDL(len))
    {
        if (mboxInfo[dev->ch]._os_func.wlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }

        if (MBOX_DEV_VALIDID(dev->devId) && MBOX_DEV_VALIDCH(dev->ch))
        {
            if ((mbox_phy_empty_mdata(dev->ch) == 0x01) && (mbox_phy_empty_mcmd(dev->ch) == 0x01))
            {
                if (mbox_phy_write_data(dev->ch, data, len) == MBOX_SUCCESS)
                {
                    scmd[0] = ((dev->dev_name[5] << 24) | dev->dev_name[4] << 16) & 0xFFFF0000;
                    scmd[1] = 0; scmd[2] = 0; scmd[3] = 0; scmd[4] = 0; scmd[5] = 0; scmd[6] = 0;
                    scmd[7] = (dev->dev_name[3] << 24) | (dev->dev_name[2] << 16) | (dev->dev_name[1] << 8) | dev->dev_name[0];

                    if (mboxInfo[dev->ch]._os_func.wsigclr != NULL)
                    {
                        ret = mboxInfo[dev->ch]._os_func.wsigclr(mboxInfo[dev->ch]._sigId);
                    }

                    mbox_phy_bitclear_ctrl(dev->ch, OEN_BIT);
                    ret = mbox_phy_write_cmd(dev->ch, scmd); 
                    mbox_phy_bitset_ctrl(dev->ch, OEN_BIT);
                
                    if (mboxInfo[dev->ch]._os_func.wsigwait != NULL)
                    {
                        ret = mboxInfo[dev->ch]._os_func.wsigwait(mboxInfo[dev->ch]._sigId);
                    }
                }
                else
                {
                    ret = MBOX_ERR_WRITE; 
                    MBOXL("[E] %s : mbox phy write err[%d]\n", __FUNCTION__, ret);
                }
            }
            else
            {
                ret =  MBOX_ERR_FIFO_FULL;
                MBOXL("[E] %s : no space for len[%d]\n", __FUNCTION__, len);
            }
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
            MBOXL("[E] %s : devId %d, ch %d \n", __FUNCTION__, dev->devId, dev->ch);
        }

        if (mboxInfo[dev->ch]._os_func.wunlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wunlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
        MBOXL("[E] %s : send fail dev[%p] data[%p] len[%d] invalid param\n", __FUNCTION__, dev, data, (int) len);
    }

err:
    return ret;
}
#endif

/* ====================================================================== *
 * Function    : mbox_dev_recv                                            *
 * Return      : < 0 if error, = 0 if read cmd only, > 0 if read data     *
 * Parameters  : mbox_dvice_t *dev ()                                     *
 *               uint32 *cmd ()                                           *
 *               uint32 *data ()                                          *
 * Description :                                                          *
 * ====================================================================== */
int32 mbox_dev_recv(mbox_dvice_t *dev, uint32 *cmd, uint32 *data)
{
    int32 ret = MBOX_SUCCESS;
    if (MBOX_DEV_NULLCHK(dev) && (MBOX_DEV_NULLCHK(cmd) || MBOX_DEV_NULLCHK(data)))
    {
        if (MBOX_DEV_VALIDID(dev->devId) && MBOX_DEV_VALIDCH(dev->ch))
        {
            while ((ret = mbox_dev_qget(dev->ch, dev->devId, dev->queue, cmd, data)) == MBOX_ERR_QUEUE_EMPTY)
            {
                if (mboxInfo[dev->ch]._os_func.rsigwait != NULL)
                {
                    if ((ret = mboxInfo[dev->ch]._os_func.rsigwait(dev->sigId)) != MBOX_SUCCESS) 
                        break;
                }
                else
                {
                    break;
                }
            } 
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_OPENED;
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
    }

    return ret;
}

/* ====================================================================== *
 * Function    : mbox_dev_recv_cmd                                        *
 * Return      : < 0 if error, = 0 if read cmd only, > 0 if read data     *
 * Parameters  : mbox_dvice_t *dev ()                                     *
 *               uint32 *cmd ()                                           *
 * Description :                                                          *
 * ====================================================================== */
int32 mbox_dev_recv_cmd(mbox_dvice_t *dev, uint32 *cmd)
{
    return mbox_dev_recv(dev, cmd, NULL);
}

/* ====================================================================== *
 * Function    : mbox_dev_recv_cmd_data                                   *
 * Return      : < 0 if error, = 0 if read cmd only, > 0 if read data     *
 * Parameters  : mbox_dvice_t *dev ()                                     *
 *               uint32 *data ()                                           *
 * Description :                                                          *
 * ====================================================================== */
int32 mbox_dev_recv_data(mbox_dvice_t *dev, uint32 *data)
{
    return mbox_dev_recv(dev, NULL, data);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_received_a53_secure                         *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_received_a53_secure(void *arg)
{
    if (mbox_dev_deploy_swbuf(MBOX_CH_CA53, ccnt(MBOX_CH_CA53)) < 0)
    {
        MBOXL("[E] %s : deploy data fail\n", __func__);
        // send NAK --> with reason : queue full, no such device
    }
    
    // TEST
    //SW_IRQ_Assert(INT_MBOX1_SLV_S_W - GIC_SPI_START, 0);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_received_a53_nonsecure                      *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_received_a53_nonsecure(void *arg)
{
    if (mbox_dev_deploy_swbuf(MBOX_CH_CA53_NS, ccnt(MBOX_CH_CA53_NS)) < 0)
    {
        MBOXL("[E] %s : deploy data fail\n", __func__);
        // send NAK --> with reason : queue full, no such device
    }
    
    // TEST     
    //SW_IRQ_Assert(INT_MBOX1_SLV_NS_W - GIC_SPI_START, 0);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_received_a07_secure                         *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_received_a07_secure(void *arg)
{
    if (mbox_dev_deploy_swbuf(MBOX_CH_CA07, ccnt(MBOX_CH_CA07)) < 0)
    {
        MBOXL("[E] %s : deploy data fail\n", __func__);
        // send NAK --> with reason : queue full, no such device
    }
    
    // TEST
    //SW_IRQ_Assert(INT_MBOX0_SLV_S_W - GIC_SPI_START, 0);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_received_a07_nonsecure                      *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_received_a07_nonsecure(void *arg)
{
    if (mbox_dev_deploy_swbuf(MBOX_CH_CA07_NS, ccnt(MBOX_CH_CA07_NS)) < 0)
    {
        MBOXL("[E] %s : deploy data fail\n", __func__);
        // send NAK --> with reason : queue full, no such device
    }
                        
    // TEST
    //SW_IRQ_Assert(INT_MBOX0_SLV_NS_W - GIC_SPI_START, 0);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_received_m04_nonsecure                      *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_received_m04_nonsecure(void *arg)
{
    if (mbox_dev_deploy_swbuf(MBOX_CH_CM04_NS, ccnt(MBOX_CH_CM04_NS)) < 0)
    {
        MBOXL("[E] %s : deploy data fail\n", __func__);
        // send NAK --> with reason : queue full, no such device
    }
    
    // TEST 
    //SW_IRQ_Assert(INT_MBOX2_SLV_R - GIC_SPI_START, 0);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_write_confirm_a53secure                     *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_write_confirm_a53_secure(void *arg)
{
    if (mboxInfo[MBOX_CH_CA53]._os_func.wsignal != NULL)
        mboxInfo[MBOX_CH_CA53]._os_func.wsignal(mboxInfo[MBOX_CH_CA53]._sigId); 
    mbox_phy_bitset_ctrl(MBOX_CH_CA53, WR_ICLR_BIT);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_write_confirm_a53nonsecure                     *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_write_confirm_a53_nonsecure(void *arg)
{
    if (mboxInfo[MBOX_CH_CA53_NS]._os_func.wsignal != NULL)
        mboxInfo[MBOX_CH_CA53_NS]._os_func.wsignal(mboxInfo[MBOX_CH_CA53_NS]._sigId); 
    mbox_phy_bitset_ctrl(MBOX_CH_CA53_NS, WR_ICLR_BIT);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_write_confirm_a07secure                     *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_write_confirm_a07_secure(void *arg)
{
    if (mboxInfo[MBOX_CH_CA07]._os_func.wsignal != NULL)
        mboxInfo[MBOX_CH_CA07]._os_func.wsignal(mboxInfo[MBOX_CH_CA07]._sigId); 
    mbox_phy_bitset_ctrl(MBOX_CH_CA07, WR_ICLR_BIT);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_write_confirm_a07_nonsecure                 *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_write_confirm_a07_nonsecure(void *arg)
{
    if (mboxInfo[MBOX_CH_CA07_NS]._os_func.wsignal != NULL)
        mboxInfo[MBOX_CH_CA07_NS]._os_func.wsignal(mboxInfo[MBOX_CH_CA07_NS]._sigId); 
    mbox_phy_bitset_ctrl(MBOX_CH_CA07_NS, WR_ICLR_BIT);
}

/* ====================================================================== *
 * Function    : mbox_dev_isr_write_confirm_m04_nonsecure                 *
 * Return      : void                                                     *
 * Parameters  : void *arg ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_isr_write_confirm_m04_nonsecure(void *arg)
{
    if (mboxInfo[MBOX_CH_CM04_NS]._os_func.wsignal != NULL)
        mboxInfo[MBOX_CH_CM04_NS]._os_func.wsignal(mboxInfo[MBOX_CH_CM04_NS]._sigId); 
    mbox_phy_bitset_ctrl(MBOX_CH_CM04_NS, WR_ICLR_BIT);
}
 /* ====================================================================== *
  * Function    : mbox_dev_deploy_swbuf                                    *
  * Return      : int32                                                    *
  * Parameters  : MBOX_CH ch ()                                            *
  *               uint32 len ()                                            *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_deploy_swbuf(MBOX_CH ch, int32 clen)
{
    int32 ret = MBOX_SUCCESS; 
    int32 devId = -1;
    
    if (MBOX_DEV_NULLCHK(mboxInfo[ch]._dev_list) && MBOX_DEV_VALIDCL(clen)) 
    {
        devId = mbox_dev_find(ch, &mboxInfo[ch]._msg);
        if (MBOX_DEV_VALIDID(devId))
        {
            ret = mbox_dev_qput(ch, devId, mboxInfo[ch]._dev_list[devId].queue, dcnt(ch));

            if (mboxInfo[ch]._os_func.rsignal != NULL)
                mboxInfo[ch]._os_func.rsignal(mboxInfo[ch]._dev_list[devId].sigId);
        }
        else
        {
            ret = MBOX_ERR_DEV_NOT_FOUND; 
            MBOXL("[E] %s : no such device dev[%d]\n", __FUNCTION__, (int) devId);
        }
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE; 
        MBOXL("[E] %s : dev no initialized clen[%d]\n", __FUNCTION__, (int) clen);
    }

    return ret;
}

 /* ====================================================================== *
  * Function    : mbox_dev_qput                                            *
  * Return      : int32                                                    *
  * Parameters  : MBOX_CH ch ()                                            *
  *               uint32 devId ()                                          *
  *               mbox_queue_t *queue ()                                   *
  *               uint32 length ()                                         *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_qput(MBOX_CH ch, int32 devId, mbox_queue_t *queue, int32 length)
{
    int32 ret = MBOX_SUCCESS; 

    if (MBOX_DEV_VALIDID(devId) && MBOX_DEV_NULLCHK(queue))
    {
        if (((queue->rear + 1) % MBOX_MAX_QUEUE_SIZE) == queue->front)
        {
            ret = MBOX_ERR_QUEUE_FULL;
            MBOXL("[E] %s : queue full for ch[%d] devId[%d]\n", __FUNCTION__, (int) ch, devId);
        }
        else
        {
            queue->rear = ((queue->rear + 1) % MBOX_MAX_QUEUE_SIZE);
            queue->data[queue->rear].dlen = 0;
            mbox_dev_memcpy(queue->data[queue->rear].cmd, mboxInfo[ch]._msg.cmd, MBOX_CMD_FIFO_SIZE); 
            if (MBOX_DEV_VALIDDL(length))
            {
                queue->data[queue->rear].dlen = length;
                mbox_dev_memcpy(queue->data[queue->rear].data, mboxInfo[ch]._msg.data, length);
            }
        }
    }
    else
    {
        ret = MBOX_ERR_NO_SUCH_DEV; 
        MBOXL("[E] %s : no such device dev[%d]\n", __FUNCTION__, (int) devId);
    }

    return ret;
}

 /* ====================================================================== *
  * Function    : mbox_dev_qget                                            *
  * Return      : int32                                                    *
  * Parameters  : MBOX_CH ch ()                                            *
  *               uint32 devId ()                                          *
  *               mbox_queue_t *queue ()                                   *
  *               uint32 *cmd ()                                           *
  *               uint32 *data ()                                          *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_qget(MBOX_CH ch, int32 devId, mbox_queue_t *queue, uint32 *cmd, uint32 *data)
{
    int32 ret = MBOX_SUCCESS;
    if ((MBOX_DEV_NULLCHK(queue) && MBOX_DEV_NULLCHK(cmd)) || MBOX_DEV_NULLCHK(data))
    {
        if (queue->front == queue->rear)
        {
            ret = MBOX_ERR_QUEUE_EMPTY;
            MBOXL("[I] %s : queue empty for ch[%d] devId[%d]\n", __FUNCTION__, (int) ch, devId);
        }
        else
        {
            queue->front = ((queue->front + 1) % MBOX_MAX_QUEUE_SIZE);
            mbox_dev_memcpy(cmd, &queue->data[queue->front].cmd[1], (MBOX_CMD_FIFO_SIZE - 2));

            if (MBOX_DEV_VALIDDL(queue->data[queue->front].dlen))
            {
                mbox_dev_memcpy(data, queue->data[queue->front].data, queue->data[queue->front].dlen);
            }
            ret = queue->data[queue->front].dlen;
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
    }

    return ret;
}

/* ====================================================================== *
 * Function    : mbox_dev_register_irq                                    *
 * Return      : void                                                     *
 * Parameters  : MBOX_CH ch ()                                            *
 *               uint32 no ()                                             *
 *               BSP_INT_FNCT_PTR fn ()                                   *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_register_irq(MBOX_CH ch, uint32 no, int_handler fn)
{
#if 1 //fwug
	register_int_handler(no, fn, 0);
	unmask_interrupt(no);
#else
	BSP_IntVectSet(no, PRIORITY_NO_MEAN, INT_TYPE_LEVEL_HIGH, fn, 0);
    BSP_IntSrcEn(no);
#endif
}

/* ====================================================================== *
 * Function    : mbox_dev_clear_irq                                       *
 * Return      : void                                                     *
 * Parameters  : uint32 no ()                                             *
 * Description :                                                          *
 * ====================================================================== */
void mbox_dev_clear_irq(uint32 no)
{
#if 0 //fwug
    BSP_IntSrcEn(no);
#endif
}

 /* ====================================================================== *
  * Function    : mbox_dev_close                                           *
  * Return      : int32                                                    *
  * Parameters  : mbox_dvice_t *dev ()                                     *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_close(mbox_dvice_t *dev)
{
    int32 ret = MBOX_SUCCESS;

    if (MBOX_DEV_NULLCHK(dev) && MBOX_DEV_VALIDCH(dev->ch))
    {
        if (mboxInfo[dev->ch]._os_func.wlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }

        if (mboxInfo[dev->ch]._dev_list[dev->devId].devId >= 0)
        {
            mbox_dev_map_del(dev->ch, (unsigned char *) dev->dev_name);
            mboxInfo[dev->ch]._dev_list[dev->devId].devId = -1;

            if (mboxInfo[dev->ch]._os_func.rsigdeinit != NULL)
                ret = mboxInfo[dev->ch]._os_func.rsigdeinit((uint32 *) &mboxInfo[dev->ch]._dev_list[dev->devId].sigId);
        }
        else
        {
            MBOXL("[E] %s : no intialized[%d]\n", __FUNCTION__, (int) dev->devId);
            ret = MBOX_ERR_NOT_INITIALIZE; 
        }
    
        if (mboxInfo[dev->ch]._os_func.wunlock != NULL)
        {
            if ((ret = mboxInfo[dev->ch]._os_func.wunlock(mboxInfo[dev->ch]._lock)) != MBOX_SUCCESS)
                goto err;
        }
    }
    else
    {
        MBOXL("[E] %s : invalid param dev[%p] ch[%d]\n", __FUNCTION__, dev, (int) dev->ch);
        ret = MBOX_ERR_ARGUMENT;
    } 

err:
    return ret;
}

 /* ====================================================================== *
  * Function    : mbox_dev_deinit                                          *
  * Return      : int32                                                    *
  * Parameters  : MBOX_CH ch ()                                            *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_deinit(MBOX_CH ch)
{
    int32 idx = 0, ret = MBOX_SUCCESS;

    if (MBOX_DEV_VALIDCH(ch))
    {
        mbox_phy_bitset_ctrl(ch, FLUSH_BIT|D_FLUSH_BIT);
        mbox_phy_bitclear_ctrl(ch, WR_IEN_BIT|RD_IEN_BIT);
        mbox_dev_clear_irq(mboxInfo[ch]._rirq);
        mbox_dev_clear_irq(mboxInfo[ch]._wirq);
        mbox_phy_set_own_tmn_sts(ch, MBOX_DISABLE);

        for (idx = 0; idx < MBOX_MAX_MULTI_OPEN; idx++)
        {
            mbox_dev_close(&mboxInfo[ch]._dev_list[idx]);
        }

        if (mboxInfo[ch]._os_func.osdeinit != NULL)
        {
            if ((ret = mboxInfo[ch]._os_func.osdeinit((uint32 *) &mboxInfo[ch]._ch)) != MBOX_SUCCESS)
                MBOXL("[E] %s osdeinit fail ch[%d]\n", __func__, (int) ch);
        }
    
        if (mboxInfo[ch]._os_func.wsigdeinit != NULL)
        {
            if ((ret = mboxInfo[ch]._os_func.wsigdeinit((uint32 *) &mboxInfo[ch]._ch)) != MBOX_SUCCESS)
                MBOXL("[E] %s wsigdeinit fail ch[%d]\n", __func__, (int) ch);
        }

        mboxInfo[ch]._os_func.wlock    = NULL;
        mboxInfo[ch]._os_func.wunlock  = NULL;
        mboxInfo[ch]._os_func.rsiginit = NULL;
        mboxInfo[ch]._os_func.rsigdeinit = NULL;
        mboxInfo[ch]._os_func.rsignal  = NULL;
        mboxInfo[ch]._os_func.rsigwait = NULL;
        mboxInfo[ch]._os_func.wsiginit = NULL;
        mboxInfo[ch]._os_func.wsignal  = NULL;
        mboxInfo[ch]._os_func.wsigwait = NULL;
        mboxInfo[ch]._os_func.osdeinit = NULL;
        mboxInfo[ch]._os_func.wsigdeinit = NULL;
    }
    else
    {
        MBOXL("[E] %s : invalid param ch[%d]\n", __FUNCTION__, (int) ch);
        ret = MBOX_ERR_ARGUMENT;
    }

    return ret;
}

 /* ====================================================================== *
  * Function    : mbox_dev_ioctl                                           *
  * Return      : int32                                                    *
  * Parameters  : mbox_dvice_t *dev ()                                     *
  *               uint32 cmd ()                                            *
  *               uint32 *value ()                                         *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_ioctl(mbox_dvice_t *dev, int32 cmd, uint32 *value)
{
    int32 ret = MBOX_SUCCESS;

    if ((dev != NULL) &&
        (dev->ch > MBOX_CH_INVALID) && (dev->ch < MBOX_CH_MAX) &&
        (cmd > MBOX_IO_CMD_INVALID) && (cmd < MBOX_IO_CMD_MAX))
    {
        switch (cmd)
        {
            case MBOX_IO_CMD_SET_CTRL_REG:
                mbox_phy_bitset_ctrl(dev->ch, *value);
                break;
            case MBOX_IO_CMD_CLR_CTRL_REG:
                mbox_phy_bitclear_ctrl(dev->ch, *value);
                break;
            case MBOX_IO_CMD_GET_ILVL_BIT:
                *value = (uint32) mbox_phy_is_ilevel_set(dev->ch);
                break;
            case MBOX_IO_CMD_GET_INEN_BIT:
                *value = (uint32) mbox_phy_is_ien_set(dev->ch);
                break;
            case MBOX_IO_CMD_GET_WOEN_BIT:
                *value = (uint32) mbox_phy_is_oen_set(dev->ch);
                break;
            case MBOX_IO_CMD_GET_CFLS_BIT:
                *value = (uint32) mbox_phy_is_flushed_cmd(dev->ch);
                break;
            case MBOX_IO_CMD_GET_DFLS_BIT:
                *value = (uint32) mbox_phy_is_flushed_data(dev->ch);
                break;
            case MBOX_IO_CMD_GET_RCNT_CMD:
                *value = (uint32) mbox_phy_count_scmd(dev->ch);
                break;
            case MBOX_IO_CMD_GET_RFUL_CMD:
                *value = (uint32) mbox_phy_full_scmd(dev->ch);
                break;
            case MBOX_IO_CMD_GET_REMT_CMD:
                *value = (uint32) mbox_phy_empty_scmd(dev->ch);
                break;
            case MBOX_IO_CMD_GET_WCNT_CMD:
                *value = (uint32) mbox_phy_count_mcmd(dev->ch);
                break;
            case MBOX_IO_CMD_GET_WFUL_CMD:
                *value = (uint32) mbox_phy_full_mcmd(dev->ch);
                break;
            case MBOX_IO_CMD_GET_WEMT_CMD:
                *value = (uint32) mbox_phy_empty_mcmd(dev->ch); 
                break;
            case MBOX_IO_CMD_GET_RCNT_DAT:
                *value = (uint32) mbox_phy_count_sdata(dev->ch);
                break;
            case MBOX_IO_CMD_GET_RFUL_DAT:
                *value = (uint32) mbox_phy_full_sdata(dev->ch);
                break;
            case MBOX_IO_CMD_GET_REMT_DAT:
                *value = (uint32) mbox_phy_empty_sdata(dev->ch);
                break;
            case MBOX_IO_CMD_GET_WCNT_DAT:
                *value = (uint32) mbox_phy_count_mdata(dev->ch);
                break;
            case MBOX_IO_CMD_GET_WFUL_DAT:
                *value = (uint32) mbox_phy_full_mdata(dev->ch);
                break;
            case MBOX_IO_CMD_GET_WEMT_DAT:
                *value = (uint32) mbox_phy_empty_mdata(dev->ch);
                break; 
            case MBOX_IO_CMD_GET_OWN_STS:
                ret = mbox_phy_get_own_tmn_sts(dev->ch, value);
                break; 
            case MBOX_IO_CMD_GET_OPP_STS:
                ret = mbox_phy_get_opp_tmn_sts(dev->ch, value);
                break; 
            default:
                MBOXL("[E] %s : invalid ioctl cmd[%d]\n", __FUNCTION__, (int) cmd);
                // print err : invalid ioctl cmd
                break;
        }
    }
    else
    {
        MBOXL("[E] %s : invalid param dev[%p] ch[%d]\n", __FUNCTION__, dev, (int) dev->ch);
        ret = MBOX_ERR_ARGUMENT; 
    }

    return ret;
}

 /* ====================================================================== *
  * Function    : mbox_dev_memcpy                                          *
  * Return      : void                                                     *
  * Parameters  : uint32 *target ()                                        *
  *               uint32 *source ()                                        *
  *               uint32 len ()                                            *
  * Description :                                                          *
  * ====================================================================== */
void mbox_dev_memcpy(uint32 *target, uint32 *source, uint32 len)
{
    uint32 idx = 0;
    for (idx = 0; idx < len; idx++)
    {
        target[idx] = source[idx];
    }
}

 /* ====================================================================== *
  * Function    : mbox_dev_find                                            *
  * Return      : dev index or error no.                                   *
  * Parameters  : MBOX_CH ch ()                                            *
  *               mbox_msage_t *msg ()                                     *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_find(MBOX_CH ch, mbox_msage_t *msg)
{
    unsigned char key[MBOX_MAX_KEY_SIZE + 1] = {0, };
    key[0] = (msg->cmd[7] & 0x000000FF) >> 0;
    key[1] = (msg->cmd[7] & 0x0000FF00) >> 8;
    key[2] = (msg->cmd[7] & 0x00FF0000) >> 16;
    key[3] = (msg->cmd[7] & 0xFF000000) >> 24;
    key[4] = (msg->cmd[0] & 0x00FF0000) >> 16;
    key[5] = (msg->cmd[0] & 0xFF000000) >> 24;
    return mbox_dev_map_get(ch, (char *) key);
}

 /* ====================================================================== *
  * Function    : mbox_dev_new                                             *
  * Return      : new dev index or error no.                               *
  * Parameters  : MBOX_CH ch ()                                            *
  *               unsigned char *dev_name ()                               *
  * Description :                                                          *
  * ====================================================================== */
int32 mbox_dev_new(MBOX_CH ch, unsigned char *dev_name)
{
    int idx = 0;
    int32 ret = MBOX_DEV_ERR_FULL;
   
    if ((ret = mbox_dev_map_get(ch, (char *) dev_name)) < 0)
    {
        for (idx = 0; idx < MBOX_MAX_MULTI_OPEN; idx++)
        {
            if (mboxInfo[ch]._dev_list[idx].devId < 0)
            {
                ret = mbox_dev_map_put(ch, dev_name, idx);
                break;
            }
        }
    }

    return ret;
}

 /* ====================================================================== *
  * Open source : There are no restriction to use this logic according to  *
  *               https://github.com/petewarden/c_hashmap                  *
  * ====================================================================== */
int32 mbox_dev_map_get(MBOX_CH ch, char *dev_name)
{
    int32 ret = -1, index = -1;;
    unsigned long key = -1; 

    if (MBOX_DEV_VALIDCH(ch))
    {
        if (MBOX_DEV_NULLCHK(dev_name))
        {
            key = crc32((unsigned char *) dev_name, MBOX_MAX_KEY_SIZE);
            /* Robert Jenkins' 32 bit Mix Function */
            key += (key << 12); key ^= (key >> 22);
            key += (key << 4);  key ^= (key >> 9);
            key += (key << 10); key ^= (key >> 2);
            key += (key << 7);  key ^= (key >> 12);
            /* Knuth's Multiplicative Method */
            key = (key >> 3) * 2654435761;
            key = key % MBOX_MAX_MULTI_OPEN; 

            for (index = 0; index < MBOX_MAX_MULTI_OPEN; index++)
            {
                if ((devIdMap[ch][key].used == 1) &&
                    (dev_name[0] == devIdMap[ch][key].key[0]) &&
                    (dev_name[1] == devIdMap[ch][key].key[1]) &&
                    (dev_name[2] == devIdMap[ch][key].key[2]) &&
                    (dev_name[3] == devIdMap[ch][key].key[3]) &&
                    (dev_name[4] == devIdMap[ch][key].key[4]) &&
                    (dev_name[5] == devIdMap[ch][key].key[5]))
                {
                    ret = devIdMap[ch][key].value;
                    break;
                }
                else
                {
                    key = (key + 1) % MBOX_MAX_MULTI_OPEN;
                    ret = MBOX_DEV_ERR_KEY_NOTINUSED;
                }
            }
        }
        else
        {
            ret = MBOX_DEV_ERR_INVALID_NAME;
        }
    }
    else
    {
        ret = MBOX_DEV_ERR_INVALID_CH;
    }

    return ret;
}

 /* ====================================================================== *
  * Open source : There are no restriction to use this logic according to  *
  *               https://github.com/petewarden/c_hashmap                  *
  * ====================================================================== */
int32 mbox_dev_map_put(MBOX_CH ch, unsigned char *dev_name, int idx)
{
    int32 ret = -1, index = -1;;
    unsigned long key = -1; 

    if (MBOX_DEV_VALIDCH(ch))
    {
        if (MBOX_DEV_NULLCHK(dev_name))
        {
            key = crc32((unsigned char *) dev_name, MBOX_MAX_KEY_SIZE);
            /* Robert Jenkins' 32 bit Mix Function */
            key += (key << 12); key ^= (key >> 22);
            key += (key << 4);  key ^= (key >> 9);
            key += (key << 10); key ^= (key >> 2);
            key += (key << 7);  key ^= (key >> 12);
            /* Knuth's Multiplicative Method */
            key = (key >> 3) * 2654435761;
            key = key % MBOX_MAX_MULTI_OPEN; 
           
            for (index = 0; index < MBOX_MAX_MULTI_OPEN; index++)
            { 
                if (devIdMap[ch][key].used == 0)
                {
                    devIdMap[ch][key].used   = 1;
                    devIdMap[ch][key].value  = idx;
                    devIdMap[ch][key].key[0] = dev_name[0];
                    devIdMap[ch][key].key[1] = dev_name[1];
                    devIdMap[ch][key].key[2] = dev_name[2];
                    devIdMap[ch][key].key[3] = dev_name[3];
                    devIdMap[ch][key].key[4] = dev_name[4];
                    devIdMap[ch][key].key[5] = dev_name[5];
                    ret = devIdMap[ch][key].value;
                    break;
                }
                else
                {
                    key = (key + 1) % MBOX_MAX_MULTI_OPEN;
                    ret = MBOX_DEV_ERR_HASH_MAP_FULL;
                }
            }
        }
        else
        {
            ret = MBOX_DEV_ERR_INVALID_NAME;
        }
    }
    else
    {
        ret = MBOX_DEV_ERR_INVALID_CH; 
    }

    return ret;
}
 
/* ====================================================================== *
 * Open source : There are no restriction to use this logic according to  *
 *               https://github.com/petewarden/c_hashmap                  *
 * ====================================================================== */
int32 mbox_dev_map_del(MBOX_CH ch, unsigned char *dev_name)
{    
    int32 ret = -1, index = -1;;
    unsigned long key = -1; 

    if (MBOX_DEV_VALIDCH(ch))
    {
        if (MBOX_DEV_NULLCHK(dev_name))
        {
            key = crc32((unsigned char *) dev_name, MBOX_MAX_KEY_SIZE);
            /* Robert Jenkins' 32 bit Mix Function */
            key += (key << 12); key ^= (key >> 22);
            key += (key << 4);  key ^= (key >> 9);
            key += (key << 10); key ^= (key >> 2);
            key += (key << 7);  key ^= (key >> 12);
            /* Knuth's Multiplicative Method */
            key = (key >> 3) * 2654435761;
            key = key % MBOX_MAX_MULTI_OPEN; 

            for (index = 0; index < MBOX_MAX_MULTI_OPEN; index++)
            {
                if ((devIdMap[ch][key].used == 1) &&
                    (dev_name[0] == devIdMap[ch][key].key[0]) &&
                    (dev_name[1] == devIdMap[ch][key].key[1]) &&
                    (dev_name[2] == devIdMap[ch][key].key[2]) &&
                    (dev_name[3] == devIdMap[ch][key].key[3]) &&
                    (dev_name[4] == devIdMap[ch][key].key[4]) &&
                    (dev_name[5] == devIdMap[ch][key].key[5]))
                {
                    devIdMap[ch][key].used   = 0;
                    devIdMap[ch][key].value  = -1;
                    devIdMap[ch][key].key[0] = 0;
                    devIdMap[ch][key].key[1] = 0;
                    devIdMap[ch][key].key[2] = 0;
                    devIdMap[ch][key].key[3] = 0;
                    devIdMap[ch][key].key[4] = 0;
                    devIdMap[ch][key].key[5] = 0;
                    ret = MBOX_DEV_ERR_NONE;
                    break;
                }
                else
                {
                    key = (key + 1) % MBOX_MAX_MULTI_OPEN;
                    ret = MBOX_DEV_ERR_KEY_NOTINUSED;
                }
            }
        }
        else
        {
            ret = MBOX_DEV_ERR_INVALID_NAME;
        }
    }
    else
    {
        ret = MBOX_DEV_ERR_INVALID_CH;
    }

    return ret;
}

/* ====================================================================== *
 * Open source : There are no restriction to use this logic according to  *
 *               https://github.com/petewarden/c_hashmap                  *
 * ====================================================================== */
unsigned long crc32(const unsigned char *s, unsigned int len)
{
    unsigned int i;
    unsigned long crc32val = 0;

    for (i = 0;  i < len;  i ++)
    {
        crc32val = crc32_tab[(crc32val ^ s[i]) & 0xff] ^ (crc32val >> 8);
    }

    return crc32val;
}

#if 1 //fwug
/* ====================================================================== *
  * Function    : mbox_dev_enable_test                                     *
  * Return      : void                                                     *
  * Parameters  :                                                          *
  * Description :                                                          *
  * ====================================================================== */
void mbox_dev_enable_test(MBOX_CH ch)
{
    mbox_phy_bitset_ctrl(ch, TEST_BIT);
}

 /* ====================================================================== *
  * Function    : mbox_dev_disable_test                                    *
  * Return      : void                                                     *
  * Parameters  :                                                          *
  * Description :                                                          *
  * ====================================================================== */
void mbox_dev_disable_test(MBOX_CH ch)
{
    mbox_phy_bitclear_ctrl(ch, TEST_BIT);
}
#endif
