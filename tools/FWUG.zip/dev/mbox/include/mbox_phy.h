/****************************************************************************************
 *   FileName    : mbox_phy.h
 *   Description :
 ****************************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited
to re-distribution in source or binary form is strictly prohibited.
This source code is provided ¡°AS IS¡± and nothing contained in this source code
shall constitute any express or implied warranty of any kind, including without limitation,
any warranty of merchantability, fitness for a particular purpose or non-infringement of any patent,
copyright or other third party intellectual property right.
No warranty is made, express or implied, regarding the information¡¯s accuracy,
completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from,
out of or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************************/
#ifndef __MBOX_H__
#define __MBOX_H__

#ifndef BITSET
#define BITSET(X, MASK)             ((X) |= (uint32)(MASK))
#endif
#ifndef BITSCLR
#define BITSCLR(X, SMASK, CMASK)    ((X) = ((((uint32)(X)) | ((uint32)(SMASK))) & ~((uint32)(CMASK))) )
#endif
#ifndef BITCSET
#define BITCSET(X, CMASK, SMASK)    ((X) = ((((uint32)(X)) & ~((uint32)(CMASK))) | ((uint32)(SMASK))) )
#endif
#ifndef BITCLR
#define BITCLR(X, MASK)             ((X) &= ~((uint32)(MASK)) )
#endif

#define MBOX_BIT(N)                 (0x01 << N)
#define MBOX_BITS02                 (0x03)
#define MBOX_BITS04                 (0x0F)
#define MBOX_BITS16                 (0xFFFF)
#define MBOX_ENABLE                 (0x00000001)
#define MBOX_DISABLE                (0x00000000)
 
#define MBOX_CMD_FIFO_SIZE       (8)
#define MBOX_DATA_FIFO_SIZE      (128)
#define MBOX_MAX_CMD_SIZE        (MBOX_CMD_FIFO_SIZE * 4)
#define MBOX_MAX_DATA_SIZE       (MBOX_DATA_FIFO_SIZE * 4)
#define MBOX_MAX_MULTI_OPEN      (1)
#define MBOX_MAX_QUEUE_SIZE      (2)
#define MBOX_MAX_KEY_SIZE        (7)
#define MBOX_WORD_SIZE           (4)
#define MBOX_HALF_SIZE           (2)

/*******************************************************************************
*    MailBox Error Define
********************************************************************************/
#define MBOX_SUCCESS             ( 0)
#define MBOX_ERR_COMMON          (-1)
#define MBOX_ERR_BUSY            (-2)
#define MBOX_ERR_NOT_INITIALIZE  (-3)
#define MBOX_ERR_TIMEOUT         (-4)
#define MBOX_ERR_WRITE           (-5)
#define MBOX_ERR_READ            (-6)
#define MBOX_ERR_ARGUMENT        (-7)
#define MBOX_ERR_AGAIN           (-8)
#define MBOX_ERR_QUEUE_FULL      (-9)
#define MBOX_ERR_QUEUE_EMPTY     (-10)
#define MBOX_ERR_NO_SUCH_DEV     (-11)
#define MBOX_ERR_FIFO_FULL       (-12)
#define MBOX_ERR_FIFO_EMPTY      (-13)
#define MBOX_ERR_FIFO_SIZE       (-14)
#define MBOX_ERR_MULTI_OPEN      (-15)
#define MBOX_ERR_DEV_NOT_OPENED  (-16)
#define MBOX_ERR_DEV_NOT_FOUND   (-17)
#define MBOX_ERR_OS_INIT         (-18)
#define MBOX_ERR_SIG_INIT        (-19)
#define MBOX_ERR_OPP_INIT        (-20)
#define MBOX_ERR_IOCTL           (-21)


/*******************************************************************************
*    MailBox Register Base Address Define
********************************************************************************/
#define HwMBox0_CA53_S_BASE     (0x1BA20000) /* CA53 -> CR5 */
#define HwMBox0_CR5_S_BASE      (0x1B820000) /* CR5 -> CA53 */

#define HwMBox0_CA53_NS_BASE    (0x1BA30000) /* CA53 -> CR5 */
#define HwMBox0_CR5_NS_BASE     (0x1B830000) /* CR5 -> CA53 */

#define HwMBox1_CA7_S_BASE      (0x1BA00000) /* CA7 -> CR5 */
#define HwMBox1_CR5_S_BASE      (0x1B800000) /* CR5 -> CA7 */

#define HwMBox1_CA7_NS_BASE     (0x1BA10000) /* CA7 -> CR5 */
#define HwMBox1_CR5_NS_BASE     (0x1B810000) /* CR5 -> CA7 */

#define HwMBox2_CM4_NS_BASE     (0x1BA40000) /* CM4 -> CR5 */
#define HwMBox2_CR5_NS_BASE     (0x1B840000) /* CR5 -> CM4 */


/*******************************************************************************
*    MailBox CTR Register Field Define
********************************************************************************/
#define D_FLUSH_BIT     0x00000080
#define FLUSH_BIT       0x00000040
#define OEN_BIT         0x00000020
#define RD_IEN_BIT      0x00000010
#define WR_IEN_BIT      0x00100000
#define WR_ICLR_BIT     0x00200000
#define TEST_BIT        0x80000000

#define INT_LEVEL_1     0x0
#define INT_LEVEL_2     0x1
#define INT_LEVEL_4     0x2
#define INT_LEVEL_8     0x3

/*******************************************************************************
*    MailBox Register Define (Base Addr = 0x1BA00000[main], 0x1B800000[micom])
********************************************************************************/
typedef struct {
    uint32 DATA             :32;
} MBOX_DATA_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_DATA_IDX_TYPE      bREG;
}   MBOX_CTL_xxx_TYPE;

typedef struct {
    uint32 MEMP             :1;
    uint32 MFUL             :1;
    uint32                  :2;
    uint32 MCOUNT           :4;
    uint32                  :8;
    uint32 SEMP             :1;
    uint32 SFUL             :1;
    uint32                  :2;
    uint32 SCOUNT           :4;
    uint32                  :8;
}   MBOX_STR_IDX_TYPE;

typedef struct {
    uint32 LEVEL            :2;
    uint32                  :2;
    uint32 IEN              :1;
    uint32 OEN              :1;
    uint32 FLUSH            :1;
    uint32 D_FLUSH          :1;
    uint32                  :12;
    uint32 WIEN             :1;
    uint32 WCLR             :1;
    uint32                  :10;
}   MBOX_CTL_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_STR_IDX_TYPE       bREG;
}   MBOX_STR_TYPE;

typedef struct {
    uint32 MCOUNT           :16;
    uint32                  :14;
    uint32 MFUL             :1;
    uint32 MEMP             :1;
}   MBOX_DT_STR_IDX_TYPE;

typedef struct {
    uint32 SCOUNT           :16;
    uint32                  :14;
    uint32 SFUL             :1;
    uint32 SEMP             :1;
}   MBOX_DR_STR_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_DT_STR_IDX_TYPE    bREG;
}   MBOX_DT_STR_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_DR_STR_IDX_TYPE    bREG;
}   MBOX_DR_STR_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_CTL_IDX_TYPE       bREG;
}   MBOX_CTL_016_TYPE;

typedef struct {
    uint32 TXD              :32;
}   MBOX_TXD_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_TXD_IDX_TYPE       bREG;
}   MBOX_CTL_TXD_TYPE;

typedef struct {
    uint32 RXD              :32;
}   MBOX_RXD_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_RXD_IDX_TYPE       bREG;
}   MBOX_CTL_RXD_TYPE;

typedef union {
    uint32 LEVEL            :2;
    uint32                  :2;
    uint32 IEN              :1;
    uint32 OEN              :1;
    uint32 FLUSH            :1;
    uint32 D_FLUSH          :1;
    uint32                  :12;
    uint32 WIEN             :1;
    uint32 WCLR             :1;
    uint32                  :10;
} MBOX_CTL_SET_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_CTL_SET_IDX_TYPE  bREG;
}   MBOX_CTL_SET_TYPE;

typedef union {
    uint32 LEVEL            :2;
    uint32                  :2;
    uint32 IEN              :1;
    uint32 OEN              :1;
    uint32 FLUSH            :1;
    uint32 D_FLUSH          :1;
    uint32                  :12;
    uint32 WIEN             :1;
    uint32 WCLR             :1;
    uint32                  :10;
}   MBOX_CTL_CLR_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_CTL_CLR_IDX_TYPE  bREG;
}   MBOX_CTL_CLR_TYPE;

typedef union {
    uint32 OWNTSTS          :1;
    uint32                  :15;
    uint32 OPPTSTS          :1;
    uint32                  :15;
}   MBOX_STS_IDX_TYPE;

typedef union {
    uint32                  nREG;
    MBOX_STS_IDX_TYPE       bREG;
}   MBOX_STS_TYPE;

typedef struct _MAILBOX {
    MBOX_CTL_TXD_TYPE       uMBOX_TX0;          // 0x0000
    MBOX_CTL_TXD_TYPE       uMBOX_TX1;          // 0x0004
    MBOX_CTL_TXD_TYPE       uMBOX_TX2;          // 0x0008
    MBOX_CTL_TXD_TYPE       uMBOX_TX3;          // 0x000C
    MBOX_CTL_TXD_TYPE       uMBOX_TX4;          // 0x0010
    MBOX_CTL_TXD_TYPE       uMBOX_TX5;          // 0x0014
    MBOX_CTL_TXD_TYPE       uMBOX_TX6;          // 0x0018
    MBOX_CTL_TXD_TYPE       uMBOX_TX7;          // 0x001C
    MBOX_CTL_RXD_TYPE       uMBOX_RX0;          // 0x0020
    MBOX_CTL_RXD_TYPE       uMBOX_RX1;          // 0x0024
    MBOX_CTL_RXD_TYPE       uMBOX_RX2;          // 0x0028
    MBOX_CTL_RXD_TYPE       uMBOX_RX3;          // 0x002C
    MBOX_CTL_RXD_TYPE       uMBOX_RX4;          // 0x0030
    MBOX_CTL_RXD_TYPE       uMBOX_RX5;          // 0x0034
    MBOX_CTL_RXD_TYPE       uMBOX_RX6;          // 0x0038
    MBOX_CTL_RXD_TYPE       uMBOX_RX7;          // 0x003C
    MBOX_CTL_016_TYPE       uMBOX_CTL_016;      // 0x0040
    MBOX_STR_TYPE           uMBOX_STR;          // 0x0044
    MBOX_CTL_xxx_TYPE       uMBOX_DUMMY_018;    // 0x0048
    MBOX_CTL_xxx_TYPE       uMBOX_DUMMY_019;    // 0x004C
    MBOX_DT_STR_TYPE        uMBOX_TXFIFO_STR;   // 0x0050
    MBOX_DR_STR_TYPE        uMBOX_RXFIFO_STR;   // 0x0054
    MBOX_CTL_xxx_TYPE       uMBOX_DUMMY_022;    // 0x0058
    MBOX_CTL_xxx_TYPE       uMBOX_DUMMY_023;    // 0x005C
    MBOX_CTL_TXD_TYPE       uMBOX_TXFIFO;       // 0x0060
    MBOX_CTL_xxx_TYPE       uMBOX_DUMMY_025;    // 0x0064
    MBOX_CTL_xxx_TYPE       uMBOX_DUMMY_026;    // 0x0068
    MBOX_CTL_xxx_TYPE       uMBOX_DUMMY_027;    // 0x006C
    MBOX_CTL_RXD_TYPE       uMBOX_RXFIFO;       // 0x0070
    MBOX_CTL_SET_TYPE       uMBOX_CTL_SET;      // 0x0074
    MBOX_CTL_CLR_TYPE       uMBOX_CTL_CLR;      // 0x0078
    MBOX_STS_TYPE           uMBOX_STS;          // 0x007C
} MAILBOX, *PMAILBOX;

typedef enum {
    MBOX_CH_INVALID = -1,
    MBOX_CH_CA53,
    MBOX_CH_CA53_NS,
    MBOX_CH_CA07,
    MBOX_CH_CA07_NS,
    MBOX_CH_CM04_NS,
    MBOX_CH_MAX,                                                       
} MBOX_CH;

typedef struct {
    uint32                  dlen;
    uint32                  cmd[MBOX_CMD_FIFO_SIZE];
    uint32                  data[MBOX_DATA_FIFO_SIZE];
} mbox_msage_t;

typedef struct {
    int32                   front;
    int32                   rear;
    mbox_msage_t            data[MBOX_MAX_QUEUE_SIZE];                   
} mbox_queue_t;

typedef struct {
    int32                   ch;
    int32                   devId;
    uint8                   flag;
    uint32                  sigId;
    char                    dev_name[MBOX_MAX_KEY_SIZE];
    mbox_queue_t           *queue;
} mbox_dvice_t;

typedef int32 (*finit_t) (uint32 *id);
typedef int32 (*func_t) (uint32 id);

typedef struct {
    finit_t                 osinit;
    finit_t                 osdeinit;
    func_t                  wlock;
    func_t                  wunlock;
    finit_t                 rsiginit;
    finit_t                 rsigdeinit;
    func_t                  rsignal;
    func_t                  rsigwait;
    finit_t                 wsiginit;
    finit_t                 wsigdeinit;
    func_t                  wsignal;
    func_t                  wsigclr;
    func_t                  wsigwait;
} mbox_callback_t;

typedef struct _mbox_info {
    volatile PMAILBOX       _pMyMBox;
    uint32                  _ch;
    uint32                  _rirq;
    uint32                  _wirq;
    uint32                  _mocnt;
    uint32                  _lock;
    uint32                  _sigId;
    mbox_msage_t            _msg;
    mbox_dvice_t           *_dev_list;
    mbox_callback_t         _os_func;
} mbox_pinfo_t;

/* ======================== PREPARE PHY ========================= *
 * ============================================================== */
int32 mbox_phy_ready(MBOX_CH ch, uint8 mopen);

/* ===================== Control Register ======================= *
 * ============================================================== */
void mbox_phy_bitset_ctrl(MBOX_CH ch, uint32 value);
void mbox_phy_bitclear_ctrl(MBOX_CH ch, uint32 value);
uint8 mbox_phy_is_ilevel_set(MBOX_CH ch);
uint8 mbox_phy_is_ien_set(MBOX_CH ch);
uint8 mbox_phy_is_oen_set(MBOX_CH ch);
uint8 mbox_phy_is_flushed_cmd(MBOX_CH ch);
uint8 mbox_phy_is_flushed_data(MBOX_CH ch);

/* ================ Command FIFO Status Register ================ *
 * ============================================================== */
uint8 mbox_phy_count_scmd(MBOX_CH ch);
uint8 mbox_phy_full_scmd(MBOX_CH ch);
uint8 mbox_phy_empty_scmd(MBOX_CH ch);
uint8 mbox_phy_count_mcmd(MBOX_CH ch);
uint8 mbox_phy_full_mcmd(MBOX_CH ch);
uint8 mbox_phy_empty_mcmd(MBOX_CH ch);

/* ============== Transmit Data FIFO Status Register ============ *
 * ============================================================== */
uint8 mbox_phy_empty_mdata(MBOX_CH ch);
uint8 mbox_phy_full_mdata(MBOX_CH ch);
uint16 mbox_phy_count_mdata(MBOX_CH ch);

/* =============== Receive Data FIFO Status Register ============ *
 * ============================================================== */
uint8 mbox_phy_empty_sdata(MBOX_CH ch);
uint8 mbox_phy_full_sdata(MBOX_CH ch);
uint16 mbox_phy_count_sdata(MBOX_CH ch);

/* =============== Transmit Register for Command FIFO =========== *
 * ============================================================== */
int32 mbox_phy_write_cmd(MBOX_CH ch, uint32 *cmd);

/* =============== Receive Register for Command FIFO ============ *
 * ============================================================== */
int32 mbox_phy_read_cmd(MBOX_CH ch);

/* =============== Transmit Register for Data FIFO ============== *
 * ============================================================== */
int32 mbox_phy_write_data(MBOX_CH ch, uint32 *data, uint32 len);

/* ================ Receive Register for Data FIFO ============== *
 * ============================================================== */
int32 mbox_phy_read_data(MBOX_CH ch);

/* ==================== Terminal Status Register ================ *
 * ============================================================== */
int32 mbox_phy_set_own_tmn_sts(MBOX_CH ch, uint32 value);
int32 mbox_phy_get_own_tmn_sts(MBOX_CH ch, uint32 *value);
int32 mbox_phy_get_opp_tmn_sts(MBOX_CH ch, uint32 *value);
#endif
