/****************************************************************************************
 *   FileName    : mbox_dev.h
 *   Description :
 ****************************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited
to re-distribution in source or binary form is strictly prohibited.
This source code is provided ¡°AS IS¡± and nothing contained in this source code
shall constitute any express or implied warranty of any kind, including without limitation,
any warranty of merchantability, fitness for a particular purpose or non-infringement of any patent,
copyright or other third party intellectual property right.
No warranty is made, express or implied, regarding the information¡¯s accuracy,
completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from,
out of or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************************/
#define MBOX_DEV_ERR_NONE               0
#define MBOX_DEV_ERR_FULL              -1
#define MBOX_DEV_ERR_EXIST             -2
#define MBOX_DEV_ERR_INVALID_CH        -3
#define MBOX_DEV_ERR_HASH_MAP_FULL     -4
#define MBOX_DEV_ERR_INVALID_NAME      -5
#define MBOX_DEV_ERR_KEY_NOTINUSED     -6
#define MBOX_DEV_ERR_DEV_NULL          -7

#define MBOX_IO_CMD_INVALID            -1
#define MBOX_IO_CMD_SET_CTRL_REG        0
#define MBOX_IO_CMD_CLR_CTRL_REG        1
#define MBOX_IO_CMD_GET_ILVL_BIT        2 
#define MBOX_IO_CMD_GET_INEN_BIT        3 
#define MBOX_IO_CMD_GET_WOEN_BIT        4 
#define MBOX_IO_CMD_GET_CFLS_BIT        5 
#define MBOX_IO_CMD_GET_DFLS_BIT        6 
#define MBOX_IO_CMD_GET_RCNT_CMD        7 
#define MBOX_IO_CMD_GET_RFUL_CMD        8 
#define MBOX_IO_CMD_GET_REMT_CMD        9 
#define MBOX_IO_CMD_GET_WCNT_CMD        10 
#define MBOX_IO_CMD_GET_WFUL_CMD        11 
#define MBOX_IO_CMD_GET_WEMT_CMD        12 
#define MBOX_IO_CMD_GET_RCNT_DAT        13 
#define MBOX_IO_CMD_GET_RFUL_DAT        14 
#define MBOX_IO_CMD_GET_REMT_DAT        15 
#define MBOX_IO_CMD_GET_WCNT_DAT        16 
#define MBOX_IO_CMD_GET_WFUL_DAT        17 
#define MBOX_IO_CMD_GET_WEMT_DAT        18 
#define MBOX_IO_CMD_GET_OWN_STS         19
#define MBOX_IO_CMD_GET_OPP_STS         20 
#define MBOX_IO_CMD_MAX                 21 

#define MBOX_CTRL_IEN                   0x00000010
#define MBOX_CTRL_OEN                   0x00000020
#define MBOX_CTRL_CMD_FLUSH             0x00000040
#define MBOX_CTRL_DAT_FLUSH             0x00000080

#define MBOX_RD_BLOCK                   0x0001
#define MBOX_WR_BLOCK                   0x0002

#define MBOX_DEV_NULLCHK(D)             (D != NULL)
#define MBOX_DEV_VALIDID(D)             (D >= 0)
#define MBOX_DEV_VALIDCH(D)             (D > MBOX_CH_INVALID) && (D < MBOX_CH_MAX)
#define MBOX_DEV_VALIDDL(D)             (D <= MBOX_DATA_FIFO_SIZE) && (D > 0)
#define MBOX_DEV_VALIDCL(D)             (D <= MBOX_CMD_FIFO_SIZE) && (D > 0)

#define dcnt(c)                         mbox_phy_read_data(c)
#define ccnt(c)                         mbox_phy_read_cmd(c)

typedef void (*mbox_isr_t) (void *);

typedef struct
{
#if 1 //fwug
	int_handler      _recv;
    int_handler      _write;
#else
    mbox_isr_t      _recv;
    mbox_isr_t      _write;
#endif
} mbox_isr_func_t;
                                
typedef struct 
{
    char key[MBOX_MAX_KEY_SIZE];
    int32 value;
    int32 used;
} hashmap_t;

extern mbox_pinfo_t mboxInfo[MBOX_CH_MAX];

int32 mbox_dev_init(MBOX_CH ch, uint32 ilv, uint8 opn, mbox_callback_t *func);
mbox_dvice_t *mbox_dev_open(MBOX_CH ch, char *devName, uint8 flag);
int32 mbox_dev_send(mbox_dvice_t *dev, uint32 *cmd, uint32 *data, uint32 len);
int32 mbox_dev_send_cmd(mbox_dvice_t *dev, uint32 *cmd);
int32 mbox_dev_send_data(mbox_dvice_t *dev, uint32 *data, uint32 len);
int32 mbox_dev_recv(mbox_dvice_t *dev, uint32 *cmd, uint32 *data);
int32 mbox_dev_recv_cmd(mbox_dvice_t *dev, uint32 *cmd);
int32 mbox_dev_recv_data(mbox_dvice_t *dev, uint32 *data);
void mbox_dev_isr_received_a53_secure(void *arg);
void mbox_dev_isr_write_confirm_a53_secure(void *arg);
void mbox_dev_isr_received_a53_nonsecure(void *arg);
void mbox_dev_isr_write_confirm_a53_nonsecure(void *arg);
void mbox_dev_isr_received_a07_secure(void *arg);
void mbox_dev_isr_write_confirm_a07_secure(void *arg);
void mbox_dev_isr_received_a07_nonsecure(void *arg);
void mbox_dev_isr_write_confirm_a07_nonsecure(void *arg);
void mbox_dev_isr_received_m04_nonsecure(void *arg);
void mbox_dev_isr_write_confirm_m04_nonsecure(void *arg);
int32 mbox_dev_deploy_swbuf(MBOX_CH ch, int32 clen);
int32 mbox_dev_close(mbox_dvice_t *dev);
int32 mbox_dev_deinit(MBOX_CH ch);
void mbox_dev_memcpy(uint32 *target, uint32 *source, uint32 len);
int32 mbox_dev_qput(MBOX_CH ch, int32 devId, mbox_queue_t *queue, int32 length);
int32 mbox_dev_qget(MBOX_CH ch, int32 devId, mbox_queue_t *queue, uint32 *cmd, uint32 *data);
int32 mbox_dev_ioctl(mbox_dvice_t *dev, int32 cmd, uint32 *value);
int32 mbox_dev_find(MBOX_CH ch, mbox_msage_t *msg); 
int32 mbox_dev_new(MBOX_CH ch, unsigned char *dev_name);
int32 mbox_dev_map_get(MBOX_CH ch, char *dev_name);
int32 mbox_dev_map_put(MBOX_CH ch, unsigned char *dev_name, int idx);
int32 mbox_dev_map_del(MBOX_CH ch, unsigned char *dev_name);
unsigned long crc32(const unsigned char *s, unsigned int len);
void mbox_dev_enable_test(MBOX_CH ch);
void mbox_dev_disable_test(MBOX_CH ch);
