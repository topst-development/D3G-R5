/****************************************************************************************
 *   FileName    : mbox_phy.c
 *   Description :
 ****************************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited
to re-distribution in source or binary form is strictly prohibited.
This source code is provided ¡°AS IS¡± and nothing contained in this source code
shall constitute any express or implied warranty of any kind, including without limitation,
any warranty of merchantability, fitness for a particular purpose or non-infringement of any patent,
copyright or other third party intellectual property right.
No warranty is made, express or implied, regarding the information¡¯s accuracy,
completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from,
out of or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************************/
#if 1
#include <debug.h>
#include <platform/interrupts.h>
#include <platform/irqs.h>
#include <platform/iomap.h>
#include <sys/types.h>
#include <kernel/thread.h>

#include <reg.h>
#include <mbox_phy.h>
#else
#include <types.h>
#include "bsp_int.h"
#include "mbox_phy.h"
#endif

uint8 opened = 0;

mbox_pinfo_t mboxInfo[MBOX_CH_MAX] =
{
    {(void*) HwMBox0_CR5_S_BASE,  MBOX_CH_CA53,    MICOM_IRQ_SMBOX1_WRITE,  MICOM_IRQ_SMBOX1_READ,  0, 0, 0, {0, }, NULL, {0, }},
    {(void*) HwMBox0_CR5_NS_BASE, MBOX_CH_CA53_NS, MICOM_IRQ_NSMBOX1_WRITE, MICOM_IRQ_NSMBOX1_READ, 0, 0, 0, {0, }, NULL, {0, }},
    {(void*) HwMBox1_CR5_S_BASE,  MBOX_CH_CA07,    MICOM_IRQ_SMBOX0_WRITE,  MICOM_IRQ_SMBOX0_READ,  0, 0, 0, {0, }, NULL, {0, }},
    {(void*) HwMBox1_CR5_NS_BASE, MBOX_CH_CA07_NS, MICOM_IRQ_NSMBOX0_WRITE, MICOM_IRQ_NSMBOX0_READ, 0, 0, 0, {0, }, NULL, {0, }},
    {(void*) HwMBox2_CR5_NS_BASE, MBOX_CH_CM04_NS, MICOM_IRQ_MBOX2_WRITE,   MICOM_IRQ_MBOX2_READ,   0, 0, 0, {0, }, NULL, {0, }},
};

mbox_queue_t  queue[MBOX_CH_MAX][MBOX_MAX_MULTI_OPEN] = {0, };
mbox_dvice_t  dlist[MBOX_CH_MAX][MBOX_MAX_MULTI_OPEN] = {0, };

int32 mbox_phy_ready(MBOX_CH ch, uint8 mopen)
{
    int32 idx = 0;
    uint32 ret = MBOX_SUCCESS;

    if ((ch >= 0) && (ch < MBOX_CH_MAX))
    {
        if ((opened + mopen) <= (MBOX_MAX_MULTI_OPEN * MBOX_CH_MAX)
            && (mopen > 0) && (mopen <= MBOX_MAX_MULTI_OPEN))
        {
            mboxInfo[ch]._mocnt = mopen;
            mboxInfo[ch]._dev_list = &dlist[ch][0];
            for (idx = 0; idx < mopen; idx++)
            {
                mboxInfo[ch]._dev_list[idx].ch    = -1;
                mboxInfo[ch]._dev_list[idx].devId = -1;
                mboxInfo[ch]._dev_list[idx].flag  =  0;
                mboxInfo[ch]._dev_list[idx].queue = &queue[ch][idx];
            }

            opened += mopen;
        }
        else
        {
            ret = MBOX_ERR_MULTI_OPEN;
        }
    }
    else
    {
        ret = MBOX_ERR_ARGUMENT;
    }

    return ret;
}


/* ===================== Control Register ======================= *
 * TEST (31) : 
 * DF_FLUSH (7) :
 * CF_FLUSH (6) :
 * OEN (5) :
 * IEN (4) :
 * ILEVEL (1:0) :
 * ============================================================== */
void mbox_phy_bitset_ctrl(MBOX_CH ch, uint32 value)
{
	BITCLR(mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.nREG, value);
    BITSET(mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.nREG, value);
}

void mbox_phy_bitclear_ctrl(MBOX_CH ch, uint32 value)
{
	BITCLR(mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.nREG, value);
}

uint8 mbox_phy_is_ilevel_set(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.bREG.LEVEL & MBOX_BITS02);
}

uint8 mbox_phy_is_ien_set(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.bREG.IEN & MBOX_BIT(0));
}

uint8 mbox_phy_is_oen_set(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.bREG.OEN & MBOX_BIT(0));
}

uint8 mbox_phy_is_flushed_cmd(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.bREG.FLUSH & MBOX_BIT(0));
}

uint8 mbox_phy_is_flushed_data(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_CTL_016.bREG.D_FLUSH & MBOX_BIT(0));
}

/* ================ Command FIFO Status Register ================ *
 * SCOUNT (23:20) :
 * SFUL (17) :
 * SEMP (16) :
 * MCOUNT (7:4) :
 * MFUL (1) :
 * MEMP (0) :
 * ============================================================== */
uint8 mbox_phy_count_scmd(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_STR.bREG.SCOUNT & MBOX_BITS04);
}

uint8 mbox_phy_full_scmd(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_STR.bREG.SFUL & MBOX_BIT(0));
}

uint8 mbox_phy_empty_scmd(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_STR.bREG.SEMP & MBOX_BIT(0));
}

uint8 mbox_phy_count_mcmd(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_STR.bREG.MCOUNT & MBOX_BITS04);
}

uint8 mbox_phy_full_mcmd(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_STR.bREG.MFUL & MBOX_BIT(0));
}

uint8 mbox_phy_empty_mcmd(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_STR.bREG.MEMP & MBOX_BIT(0));
}

/* ============== Transmit Data FIFO Status Register ============ *
 * MEMP (31) :
 * MFUL (30) :
 * MCOUNT (15:0) :
 * ============================================================== */
uint8 mbox_phy_empty_mdata(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_TXFIFO_STR.bREG.MEMP & MBOX_BIT(0));
}

uint8 mbox_phy_full_mdata(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_TXFIFO_STR.bREG.MFUL & MBOX_BIT(0));
}

uint16 mbox_phy_count_mdata(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_TXFIFO_STR.bREG.MCOUNT & MBOX_BITS16);
}

/* =============== Receive Data FIFO Status Register ============ *
 * SEMP (31) :
 * SFUL (30) :
 * SCOUNT (15:0) :
 * ============================================================== */
uint8 mbox_phy_empty_sdata(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_RXFIFO_STR.bREG.SEMP & MBOX_BIT(0));
}

uint8 mbox_phy_full_sdata(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_RXFIFO_STR.bREG.SFUL & MBOX_BIT(0));
}

uint16 mbox_phy_count_sdata(MBOX_CH ch)
{
    return (mboxInfo[ch]._pMyMBox->uMBOX_RXFIFO_STR.bREG.SCOUNT & MBOX_BITS16);
}

/* =============== Transmit Register for Command FIFO =========== *
 * TXD (31:0) :
 * ============================================================== */
int32 mbox_phy_write_cmd(MBOX_CH ch, uint32 *cmd)
{
	int32 ret = MBOX_SUCCESS;

    if(mboxInfo[ch]._pMyMBox != NULL)
    {
        if (cmd != NULL)
        { 
            mboxInfo[ch]._pMyMBox->uMBOX_TX0.nREG = cmd[0];
            mboxInfo[ch]._pMyMBox->uMBOX_TX1.nREG = cmd[1];
		    mboxInfo[ch]._pMyMBox->uMBOX_TX2.nREG = cmd[2];
		    mboxInfo[ch]._pMyMBox->uMBOX_TX3.nREG = cmd[3];
		    mboxInfo[ch]._pMyMBox->uMBOX_TX4.nREG = cmd[4];
		    mboxInfo[ch]._pMyMBox->uMBOX_TX5.nREG = cmd[5];
		    mboxInfo[ch]._pMyMBox->uMBOX_TX6.nREG = cmd[6];
		    mboxInfo[ch]._pMyMBox->uMBOX_TX7.nREG = cmd[7];
        }
        else    
        {
            ret = MBOX_ERR_ARGUMENT;
        }
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
    }

	return ret;
}

/* =============== Receive Register for Command FIFO ============ *
 * RXD (31:0) :
 * ============================================================== */
int32 mbox_phy_read_cmd(MBOX_CH ch)
{
    uint16 scount;
	int32 ret = MBOX_SUCCESS;

    if(mboxInfo[ch]._pMyMBox != NULL)
    {
        if ((scount = mbox_phy_count_scmd(ch)) > 0)
        {
            mboxInfo[ch]._msg.cmd[0] = mboxInfo[ch]._pMyMBox->uMBOX_RX0.nREG;
            mboxInfo[ch]._msg.cmd[1] = mboxInfo[ch]._pMyMBox->uMBOX_RX1.nREG;
		    mboxInfo[ch]._msg.cmd[2] = mboxInfo[ch]._pMyMBox->uMBOX_RX2.nREG;
		    mboxInfo[ch]._msg.cmd[3] = mboxInfo[ch]._pMyMBox->uMBOX_RX3.nREG;
		    mboxInfo[ch]._msg.cmd[4] = mboxInfo[ch]._pMyMBox->uMBOX_RX4.nREG;
		    mboxInfo[ch]._msg.cmd[5] = mboxInfo[ch]._pMyMBox->uMBOX_RX5.nREG;
		    mboxInfo[ch]._msg.cmd[6] = mboxInfo[ch]._pMyMBox->uMBOX_RX6.nREG;
		    mboxInfo[ch]._msg.cmd[7] = mboxInfo[ch]._pMyMBox->uMBOX_RX7.nREG;

            ret = scount;
        }
        else
        {
            ret = MBOX_ERR_READ;
        }
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
    }

	return ret;

}

/* =============== Transmit Register for Data FIFO ============== *
 * TXD (31:0) :
 * ============================================================== */
int32 mbox_phy_write_data(MBOX_CH ch, uint32 *data, uint32 len)
{
    uint32 i;
	int32 ret = MBOX_SUCCESS;

    if(mboxInfo[ch]._pMyMBox != NULL)
    {
        if ((data != NULL) && (len <= MBOX_MAX_DATA_SIZE))
        {
    	    for (i = 0; i < len; i++)
    	    {
    	    	mboxInfo[ch]._pMyMBox->uMBOX_TXFIFO.nREG = data[i];
    	    }
        }
        else
        {
            ret = MBOX_ERR_ARGUMENT;
        }
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
    }

	return ret;
}

/* ================ Receive Register for Data FIFO ============== *
 * RXD (31:0) :
 * ============================================================== */
int32 mbox_phy_read_data(MBOX_CH ch)
{    
    uint16 i, scount;
	int32 ret = MBOX_SUCCESS;

    if(mboxInfo[ch]._pMyMBox != NULL)
    {
        scount = mbox_phy_count_sdata(ch);
        if ((scount > 0) && (scount <= MBOX_DATA_FIFO_SIZE))
        {
    	    for (i = 0; i < scount; i++)
    	    {
                mboxInfo[ch]._msg.data[i] = mboxInfo[ch]._pMyMBox->uMBOX_RXFIFO.nREG;
    	    }

            ret = scount;
        }
        else
        {
            ret = MBOX_ERR_READ;
        }
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
    }

	return ret;
}

/* ==================== Terminal Status Register ================ *
 * OWN_TMN_STS (16:16) :
 * ============================================================== */
int32 mbox_phy_set_own_tmn_sts(MBOX_CH ch, uint32 value)
{
    int32 ret = MBOX_SUCCESS;

    if(mboxInfo[ch]._pMyMBox != NULL)
    {
        mboxInfo[ch]._pMyMBox->uMBOX_STS.bREG.OWNTSTS = (value & MBOX_BIT(0));
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
    }

    return ret;
}

int32 mbox_phy_get_own_tmn_sts(MBOX_CH ch, uint32 *value)
{
    int32 ret = MBOX_SUCCESS;

    if(mboxInfo[ch]._pMyMBox != NULL)
    {
        *value = (mboxInfo[ch]._pMyMBox->uMBOX_STS.bREG.OWNTSTS & MBOX_BIT(0));
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
    }

    return ret;
}

/* ==================== Terminal Status Register ================ *
 * OPP_TMN_STS (16:16) :
 * ============================================================== */
int32 mbox_phy_get_opp_tmn_sts(MBOX_CH ch, uint32 *value)
{
    int32 ret = MBOX_SUCCESS;

    if(mboxInfo[ch]._pMyMBox != NULL)
    {
        *value = (mboxInfo[ch]._pMyMBox->uMBOX_STS.bREG.OPPTSTS & MBOX_BIT(0));
    }
    else
    {
        ret = MBOX_ERR_NOT_INITIALIZE;
    }

    return ret;
}
