LOCAL_DIR := $(GET_LOCAL_DIR)

INCLUDES += -I$(LOCAL_DIR)/include

OBJS+= \
	$(LOCAL_DIR)/mbox_phy.o \
	$(LOCAL_DIR)/mbox_cfg.o \
	$(LOCAL_DIR)/mbox_dev.o
