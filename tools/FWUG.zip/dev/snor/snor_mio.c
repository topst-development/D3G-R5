/****************************************************************************
 *   FileName    : snor_mio.c
 *   Description : Serial Flash Multi I/O Driver
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include <debug.h>
#include <platform/reg_physical.h>
#include <reg.h>
#include <dev/gpio.h>
#include <platform/gpio.h>
#include <platform/tcc_ckc.h>
#include <clock.h>
#include <malloc.h>
#include "snor_mio.h"
#include "snor_mio_gdma.h"
#include "snor_mio_gpio.h"
#define SNOR_MIO_DEBUG(f, a...)   	dprintf(1, f, ##a)
#define SNOR_MIO_CT_DEBUG(f, a...)	dprintf(1, f, ##a)
#define SNOR_MIO_TRACE(f, a...)		//dprintf(1, "\x1b[1;33m[%s:%d]\x1b[0m\n", __func__, __LINE__)

//#define SNOR_MIO_GDMA			1
#define HwPL080_BASE        0x1B600000
#define HwPL080         ((volatile DMA_sPort *)HwPL080_BASE)


extern int memcmp(const void *cs, const void *ct, size_t count);
extern void *memcpy(void *dest, const void *src, size_t count);
extern void *memset(void *s, int c, size_t count);
extern int getc(char *c);
extern void free(void *ptr);
extern void *dma_alloc(unsigned int alignment, size_t size);
extern 	void mdelay(unsigned msecs);
extern void arch_invalidate_cache_range(addr_t start, size_t len);
extern time_t current_time(void);

void SNOR_MIO_IO_TEST(void);
static int SNOR_MIO_ISSI_DefaultConfig(void);
static int SNOR_MIO_MXIC_DefaultConfig(void);
static int SNOR_MIO_WINBOND_DefaultConfig(void);
static int SNOR_MIO_CYPRESS_DefaultConfig(void);
static int SNOR_MIO_XMC_DefaultConfig(void);
static void SNOR_MIO_4B_Disable(void);
static void SNOR_MIO_Window_Margin_TEST(unsigned int *);
static int SNOR_MIO_IO_Clock_Training(void);

struct SNOR_MIO_DRV	snor_mio_drv;
//PGPIO pGPIO			= ((PGPIO)HwGPIO_BASE);

/************************************************************************************************************

                                        Serial Nor Flash Product Table

************************************************************************************************************/
struct SNOR_MIO_PRODUCT_INFO gSNOR_MIO_ProductTable[] =
{
	/*
	|Seral Flash				|MID	|DID	|Sector |Read CMD			|F_Read 		|Write CMD	|Flag			|
	|NAME						|		|		|Count	|					|				|			|				|
	*/
	{"MXIC-MX25L1633E",			0xC2,	0x2415, 32, 	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// MXIC, 2MB
	{"MXIC-MX25L3233F",			0xC2,	0x2016, 64, 	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// MXIC, 4MB
	{"MXIC-MX25L6435E",			0xC2,	0x2017, 128,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// MXIC, 8MB
	{"MXIC-MX25L12835F",		0xC2,	0x2018, 256,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// MXIC, 16MB
	{"MXIC-MX25L25645G",		0xC2,	0x2019, 512,	CMD_FAST_READ4B,	CMD_4READ4B,	CMD_PP4B,	ADDR_4B|SECT_4K },	// MXIC, 32MB
	{"MXIC-MX25L51245G",		0xC2,	0x201A, 1024,	CMD_FAST_READ4B,	CMD_4READ4B,	CMD_PP4B,	ADDR_4B|SECT_4K },	// MXIC, 64MB
	{"MXIC-MX25LM51245G",		0xC2,	0x853A, 1024,	CMD_FAST_READ4B,	CMD_8READ,		CMD_PP4B,	ADDR_4B|SECT_4K },	// MXIC, 64MB

	{"WINBOND-W25X20CL",		0xEF,	0x3012, 4, 		CMD_FAST_READ,		CMD_DREAD,		CMD_PP, 	SECT_4K 		},	// WINBOND, 256Kbyte
	{"WINBOND-W25X40CL",		0xEF,	0x3013, 8,	 	CMD_FAST_READ,		CMD_DREAD,		CMD_PP, 	SECT_4K 		},	// WINBOND, 512Kbyte
	{"WINBOND-W25Q80JV",		0xEF,	0x4014, 16, 	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// WINBOND, 1MB
	{"WINBOND-W25Q16JV",		0xEF,	0x4015, 32,		CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// WINBOND, 2MB
	{"WINBOND-W25Q32JV",		0xEF,	0x4016, 64,		CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// WINBOND, 4MB
	{"WINBOND-W25Q64JV",		0xEF,	0x4017, 128,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// WINBOND, 8MB
	{"WINBOND-W25Q128JV",		0xEF,	0x4018, 256,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// WINBOND, 16MB
	{"WINBOND-W25Q256JV",		0xEF,	0x4019, 512,	CMD_FAST_READ4B,	CMD_4READ4B,	CMD_PP4B, 	ADDR_4B|SECT_4K },	// WINBOND, 32MB
	{"WINBOND-W25Q256JV-IM",	0xEF,	0x7019, 512,	CMD_FAST_READ4B,	CMD_4READ4B,	CMD_PP4B, 	ADDR_4B|SECT_4K },	// WINBOND, 32MB

	{"MICRON-MT25QL128ABA",		0x20,	0xBA18, 256,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// MICRON, 16MB
	{"MICRON-MT25QL256ABA",		0x20,	0xBA19, 512,	CMD_FAST_READ4B,	CMD_4READ4B,	CMD_PP4B, 	ADDR_4B|SECT_4K },	// MICRON, 32MB
	{"MICRON-MT25QL512ABB",		0x20,	0xBA20, 1024,	CMD_FAST_READ4B,	CMD_4DTRD4B,	CMD_PP4B,	ADDR_4B|SECT_4K },	// MICRON, 64MB

	{"CYPRESS-S25FL116K",		0x01,	0x4015, 32,		CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// CYPRESS, 2MB
	{"CYPRESS-S25FL132K",		0x01,	0x4016, 64,		CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// CYPRESS, 4MB
	{"CYPRESS-S25FL164K",		0x01,	0x4017, 128,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// CYPRESS, 8MB
	{"CYPRESS-S25FL064L",		0x01,	0x6017, 128,	CMD_READ,			CMD_4READ,		CMD_PP, 	SECT_4K 		},	// CYPRESS, 8MB
#if 0
	{"CYPRESS-S25FL064P",		0x01,	0x0216, 128,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// CYPRESS, 8MB
	{"CYPRESS-S25FL128S",		0x01,	0x2018, 256,	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// CYPRESS, 16MB
	{"CYPRESS-S25FL256S",		0x01,	0x0219, 512,	CMD_FAST_READ4B,	CMD_4DTRD4B,	CMD_PP4B,	ADDR_4B|SECT_4K },	// CYPRESS, 32MB
#endif
	{"XMC-XM25QH64A",			0x20,	0x7017, 128,	CMD_FAST_READ,		CMD_4READ,		CMD_PP,		SECT_4K			},	// XMC, 8MB
#if 0
	{"ISSI-IS25LP032",			0x9D,	0x6016, 64, 	CMD_FAST_READ,		CMD_4READ,		CMD_PP, 	SECT_4K 		},	// ISSI, 4MB
#endif
	{"ISSI-IS25LP256",			0x9D,	0x6019, 512, 	CMD_FAST_READ,		CMD_4READ4B,	CMD_PP4B, 	ADDR_4B|SECT_4K	},	// ISSI, 4MB

	{"GIGADEVICE-GD25Q16C",		0xC8,	0x4015, 32,		CMD_FAST_READ,		CMD_4READ,		CMD_PP,		SECT_4K			},	// GD, 2MB
	{"GIGADEVICE-GD25Q32C",		0xC8,	0x4016, 64,		CMD_FAST_READ,		CMD_4READ,		CMD_PP,		SECT_4K			},	// GD, 4MB
	{"GIGADEVICE-GD25Q64C",		0xC8,	0x4017, 128,	CMD_FAST_READ,		CMD_4READ,		CMD_PP,		SECT_4K			},	// GD, 8MB
	{"GIGADEVICE-GD25Q127C",	0xC8,	0x4018, 256,	CMD_FAST_READ,		CMD_4READ,		CMD_PP,		SECT_4K			},	// GD, 16MB
};

unsigned int SNOR_MIO_GetTotalSize(void)
{
	return (snor_mio_drv.size);
}

static void SNOR_MIO_PortConfig(void)
{

	// GPIO_H [0, 1, 2, 3, 4, 5, 6, 7]
	HwGPIO->pGPH.uFNC[0] = 0x10111111;
	// GPIO_H [8, 9, 10, 11]
	HwGPIO->pGPH.uFNC[1] = 0x00000011;
	HwGPIO->pGPH.uIEN	 = 0xFFFFFFFF;
	HwGPIO->pGPH.uPE	   = 0x000004FF;
	HwGPIO->pGPH.uPS	   = 0x000004FF;

}

static void SNOR_MIO_ReadID(unsigned char *pMID, unsigned short *pDevID)
{
	unsigned int	data;
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.rdid.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	data = (unsigned int)GET_CODE_TABLE(snor_mio_drv.sfmc_buf.offset);

	*pMID 	= ((data & 0xFF000000) >> 24);
	*pDevID = ((data & 0x00FFFF00) >> 8);

	SNOR_MIO_DEBUG("Read ID: 0x%X, MID:0x%02X, DevID:0x%04X\n", data, *pMID, *pDevID);
}

static void SNOR_MIO_4B_Enable(void)
{
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.en4b.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
}

static int SNOR_MIO_CheckMemoryType(void)
{
	unsigned char MID;
	unsigned short DID;
	int i;

	SNOR_MIO_TRACE();

	SNOR_MIO_ReadID(&MID,&DID);
	printf("SNOR MID: 0x%x, DID: 0x%x\n", MID, DID);

	for ( i=0 ; i<(int)(sizeof(gSNOR_MIO_ProductTable)/sizeof(gSNOR_MIO_ProductTable[0])); i++)
	{
		if (gSNOR_MIO_ProductTable[i].ManufID == MID && gSNOR_MIO_ProductTable[i].DevID == DID)
		{
			snor_mio_drv.name = gSNOR_MIO_ProductTable[i].name;
			snor_mio_drv.ManufID = MID;
			snor_mio_drv.DevID = DID;
			snor_mio_drv.page_size = 256;
			snor_mio_drv.sector_size = (64*1024);
			snor_mio_drv.sector_count = gSNOR_MIO_ProductTable[i].TotalSector;
			snor_mio_drv.size = gSNOR_MIO_ProductTable[i].TotalSector * snor_mio_drv.sector_size;
			printf("SNOR Part name: %s\n", snor_mio_drv.name);
			printf("SNOR sector count: %d\n", snor_mio_drv.sector_count);
			printf("SNOR total size: %d MB\n", (snor_mio_drv.size >> 20));

			snor_mio_drv.flags = gSNOR_MIO_ProductTable[i].flags;

			/* Set Erase sector Size and Command */
			if ( snor_mio_drv.flags& SECT_4K) {
				snor_mio_drv.erase_cmd = CMD_ERASE_4K;
				snor_mio_drv.erase_size = 4 * 1024;
			} else if (snor_mio_drv.flags & SECT_32K) {
				snor_mio_drv.erase_cmd = CMD_ERASE_32K;
				snor_mio_drv.erase_size = 32 * 1024;
			} else {
				if ( snor_mio_drv.flags & ADDR_4B)
					snor_mio_drv.erase_cmd = CMD_ERASE_64K_4B;
				else
				    snor_mio_drv.erase_cmd = CMD_ERASE_64K;
				snor_mio_drv.erase_size = snor_mio_drv.sector_size;
			}

			/* Set Read Command*/
			snor_mio_drv.cmd_read		= gSNOR_MIO_ProductTable[i].cmd_read;
			snor_mio_drv.cmd_read_fast 	= gSNOR_MIO_ProductTable[i].cmd_read_fast;

			SNOR_MIO_DEBUG("SNOR Read CMD: 0x%04X, Raad Fast CMD: 0x%04X\n", snor_mio_drv.cmd_read, snor_mio_drv.cmd_read_fast);

			/* default Write Command */
			snor_mio_drv.cmd_write = gSNOR_MIO_ProductTable[i].cmd_write;

			SNOR_MIO_DEBUG("SNOR Write CMD: 0x%02X\n", snor_mio_drv.cmd_write);

			snor_mio_drv.current_io_mode = IO_NUM_SINGLE;

			return TRUE;
		}
	}

	return FALSE;
}

static unsigned int SNOR_MIO_Get_Code_Offset(tCODE_TABLE_INFO *code)
{
	SNOR_MIO_TRACE();
	return (code->offset + code->size);
}

unsigned int SNOR_MIO_Make_cmd_readid(void)
{
	unsigned int	i;
	unsigned int 	code[5];
	unsigned int	code_offset;

	SNOR_MIO_TRACE();

	//-------------------------------------------
	// Buffer & Address variable definess
	//-------------------------------------------
	snor_mio_drv.sfmc_buf.offset 	= 0;
	snor_mio_drv.sfmc_buf.size 	= (SFMC_BUF_SIZE >> 2);

	snor_mio_drv.sfmc_addr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.sfmc_buf); //offset: 0x40
	snor_mio_drv.sfmc_addr.size 	= 1;

	//-------------------------------------------
	// READ ID
	//-------------------------------------------
	snor_mio_drv.rdid.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.sfmc_addr);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_READ_ID, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdid.size = 3;

	SNOR_MIO_CT_DEBUG("[READ ID]\n");
	for ( i = 0; i < snor_mio_drv.rdid.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdid.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdid.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdid.offset + i)));
	}

	code_offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdid);

	return code_offset;
}

static unsigned int SNOR_MIO_Make_XMC_CMD(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int 	code[5];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// READ Status register (RDSR)
	//-------------------------------------------
	snor_mio_drv.rdsr.offset 	= code_offset;
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_READ_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr.offset + i)));
	}

	//-------------------------------------------
	// READ Status 2 register (RDSR1)
	//-------------------------------------------
	snor_mio_drv.rdsr1.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x09, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr1.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS1 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr1.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr1.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr1.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr1.offset + i)));
	}

	//-------------------------------------------
	// READ Status 3 register (RDSR2)
	//-------------------------------------------
	snor_mio_drv.rdsr2.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr1);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x95, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr2.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS2 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr2.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr2.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr2.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr2.offset + i)));
	}

	//-------------------------------------------
	// Write Status register (WRSR)
	//-------------------------------------------
	snor_mio_drv.wrsr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr2);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_WRITE_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x00, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[2]);
	snor_mio_drv.wrsr.size = 3;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr.offset + i)));
	}

	/* Read Status 2 register is RO type */

	//-------------------------------------------
	// Write Status register (WRSR2)
	//-------------------------------------------
	snor_mio_drv.wrsr2.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xC0, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x00, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[2]);
	snor_mio_drv.wrsr2.size = 3;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS2 REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr2.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr2.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr2.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr2.offset + i)));
	}

	//-------------------------------------------
	// Write Enable
	//-------------------------------------------
	snor_mio_drv.write_enable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr2);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x06, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_enable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE ENABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_enable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_enable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_enable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_enable.offset + i)));
	}

	//-------------------------------------------
	// Write disable
	//-------------------------------------------
	snor_mio_drv.write_disable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_enable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x04, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_disable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE DISABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_disable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_disable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_disable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_disable.offset + i)));
	}

	//-------------------------------------------
	// enter 4byte mode
	//-------------------------------------------
	snor_mio_drv.en4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_disable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xB7, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.en4b.size = 2;

	SNOR_MIO_CT_DEBUG("[ENTER 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.en4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.en4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.en4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.en4b.offset + i)));
	}

	//-------------------------------------------
	// exit 4byte mode
	//-------------------------------------------
	snor_mio_drv.ex4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.en4b);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xE9, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.ex4b.size = 2;

	SNOR_MIO_CT_DEBUG("[EXIT 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.ex4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ex4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ex4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ex4b.offset + i)));
	}

	//-------------------------------------------
	// EAR Write
	//-------------------------------------------
	snor_mio_drv.ear_mode.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ex4b);
	code[0] = 0x40002040;
//	MK_WRITE_DATA(code[1], SFMC_BUF_SIZE, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[1]);
	snor_mio_drv.ear_mode.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE EAR]\n");
	for ( i = 0; i < snor_mio_drv.ear_mode.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ear_mode.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i)));
	}

	code_offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ear_mode);

	return code_offset;
}

static unsigned int SNOR_MIO_Make_CYPRESS_CMD(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int 	code[5];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// READ Status-1 register (RDSR1)
	//-------------------------------------------
	snor_mio_drv.rdsr.offset 	= code_offset;
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_READ_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS1 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr.offset + i)));
	}

	//-------------------------------------------
	// READ CONFIG-1 register (RDCR1)
	//-------------------------------------------
	snor_mio_drv.rdcr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x35, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdcr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ CONFIG1 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdcr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdcr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdcr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdcr.offset + i)));
	}

	//-------------------------------------------
	// READ CONFIG-2 register (RDCR2)
	//-------------------------------------------
	snor_mio_drv.rdcr1.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdcr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x15, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdcr1.size = 3;

	SNOR_MIO_CT_DEBUG("[READ CONFIG2 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdcr1.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdcr1.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdcr1.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdcr1.offset + i)));
	}

	//-------------------------------------------
	// READ CONFIG-3 register (RDCR3)
	//-------------------------------------------
	snor_mio_drv.rdcr2.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdcr1);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x33, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdcr2.size = 3;

	SNOR_MIO_CT_DEBUG("[READ CONFIG3 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdcr2.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdcr2.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdcr2.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdcr2.offset + i)));
	}

	//-------------------------------------------
	// Write Status register (WRSR)
	//-------------------------------------------
	snor_mio_drv.wrsr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdcr2);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_WRITE_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x0002, 2, LA_KEEP_CS, IO_NUM_SINGLE);	// Status-1:0x00, Config-1:0x02(QE)
	MK_WRITE_CMD(code[2], D_DTR_DISABLE, 0x6078, 2, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Config-2:0x60, Config-3:0x78(4 Dummy)
	MK_STOP_CMD(code[3]);
	snor_mio_drv.wrsr.size = 4;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr.offset + i)));
	}

	//-------------------------------------------
	// Write Enable
	//-------------------------------------------
	snor_mio_drv.write_enable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x06, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_enable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE ENABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_enable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_enable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_enable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_enable.offset + i)));
	}

	//-------------------------------------------
	// Write disable
	//-------------------------------------------
	snor_mio_drv.write_disable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_enable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x04, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_disable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE DISABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_disable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_disable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_disable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_disable.offset + i)));
	}

	//-------------------------------------------
	// enter 4byte mode
	//-------------------------------------------
	snor_mio_drv.en4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_disable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xB7, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.en4b.size = 2;

	SNOR_MIO_CT_DEBUG("[ENTER 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.en4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.en4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.en4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.en4b.offset + i)));
	}

	//-------------------------------------------
	// exit 4byte mode
	//-------------------------------------------
	snor_mio_drv.ex4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.en4b);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xE9, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.ex4b.size = 2;

	SNOR_MIO_CT_DEBUG("[EXIT 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.ex4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ex4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ex4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ex4b.offset + i)));
	}

	//-------------------------------------------
	// EAR Write
	//-------------------------------------------
	snor_mio_drv.ear_mode.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ex4b);
	code[0] = 0x40002040;
//	MK_WRITE_DATA(code[1], SFMC_BUF_SIZE, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[1]);
	snor_mio_drv.ear_mode.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE EAR]\n");
	for ( i = 0; i < snor_mio_drv.ear_mode.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ear_mode.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i)));
	}

	code_offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ear_mode);

	return code_offset;
}

static unsigned int SNOR_MIO_Make_WINBOND_CMD(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int 	code[5];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// READ Status register (RDSR)
	//-------------------------------------------
	snor_mio_drv.rdsr.offset 	= code_offset;
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_READ_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr.offset + i)));
	}

	//-------------------------------------------
	// READ CONFIG register (RDSR1)
	//-------------------------------------------
	snor_mio_drv.rdsr1.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x35, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr1.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS1 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr1.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr1.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr1.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr1.offset + i)));
	}

	//-------------------------------------------
	// READ CONFIG register (RDSR2)
	//-------------------------------------------
	snor_mio_drv.rdsr2.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr1);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x15, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr2.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS2 REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr2.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr2.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr2.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr2.offset + i)));
	}

	//-------------------------------------------
	// Write Status register (WRSR)
	//-------------------------------------------
	snor_mio_drv.wrsr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr2);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_WRITE_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x00, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[2]);
	snor_mio_drv.wrsr.size = 3;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr.offset + i)));
	}

	//-------------------------------------------
	// Write Status register (WRSR1)
	//-------------------------------------------
	snor_mio_drv.wrsr1.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x31, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x02, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Status Reg Default value: 0x02(Enable QE bit)
	MK_STOP_CMD(code[2]);
	snor_mio_drv.wrsr1.size = 3;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS1 REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr1.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr1.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr1.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr1.offset + i)));
	}

	//-------------------------------------------
	// Write Status register (WRSR2)
	//-------------------------------------------
	snor_mio_drv.wrsr2.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr1);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x11, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x60, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[2]);
	snor_mio_drv.wrsr2.size = 3;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS2 REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr2.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr2.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr2.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr2.offset + i)));
	}

	//-------------------------------------------
	// Write Enable
	//-------------------------------------------
	snor_mio_drv.write_enable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr2);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x06, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_enable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE ENABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_enable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_enable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_enable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_enable.offset + i)));
	}

	//-------------------------------------------
	// Write disable
	//-------------------------------------------
	snor_mio_drv.write_disable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_enable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x04, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_disable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE DISABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_disable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_disable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_disable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_disable.offset + i)));
	}

	//-------------------------------------------
	// enter 4byte mode
	//-------------------------------------------
	snor_mio_drv.en4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_disable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xB7, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.en4b.size = 2;

	SNOR_MIO_CT_DEBUG("[ENTER 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.en4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.en4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.en4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.en4b.offset + i)));
	}

	//-------------------------------------------
	// exit 4byte mode
	//-------------------------------------------
	snor_mio_drv.ex4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.en4b);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xE9, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.ex4b.size = 2;

	SNOR_MIO_CT_DEBUG("[EXIT 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.ex4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ex4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ex4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ex4b.offset + i)));
	}

	//-------------------------------------------
	// EAR Write
	//-------------------------------------------
	snor_mio_drv.ear_mode.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ex4b);
	code[0] = 0x40002040;
//	MK_WRITE_DATA(code[1], SFMC_BUF_SIZE, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[1]);
	snor_mio_drv.ear_mode.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE EAR]\n");
	for ( i = 0; i < snor_mio_drv.ear_mode.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ear_mode.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i)));
	}

	code_offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ear_mode);

	return code_offset;
}

static unsigned int SNOR_MIO_Make_ISSI_CMD(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int 	code[6];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// READ Status register (RDSR)
	//-------------------------------------------
	snor_mio_drv.rdsr.offset 	= code_offset;
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_READ_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr.offset + i)));
	}

	//-------------------------------------------
	// READ AUTOBOOT register (RDAB)
	//-------------------------------------------
	snor_mio_drv.rdcr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x14, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdcr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ AUTOBOOT REG]\n");
	for ( i = 0; i < snor_mio_drv.rdcr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdcr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdcr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdcr.offset + i)));
	}

	//-------------------------------------------
	// Write Status register (WRSR)
	//-------------------------------------------
	snor_mio_drv.wrsr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdcr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_WRITE_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);
//	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x40E0, 2, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Status Reg: 0x40, Configure Reg: 0x00
    if ( snor_mio_drv.flags & ADDR_4B) {
	    MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x0000, 2, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Status Reg: 0x40, Configure Reg: 0x00
    } else {
	    MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x00, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Status Reg: 0x40, Configure Reg: 0x00
    }
	MK_STOP_CMD(code[2]);
	snor_mio_drv.wrsr.size = 3;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr.offset + i)));
	}

	//-------------------------------------------
	// Write AUTOBOOT register (WRAB)
	//-------------------------------------------
	snor_mio_drv.wrab.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x15, 1, LA_KEEP_CS, IO_NUM_SINGLE);
    if ( snor_mio_drv.flags & ADDR_4B) {
	    MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x0000, 2, LA_KEEP_CS, IO_NUM_SINGLE);
		MK_WRITE_CMD(code[2], D_DTR_DISABLE, 0x0000, 2, LA_DEASSERT_CS, IO_NUM_SINGLE);
		MK_STOP_CMD(code[3]);
		snor_mio_drv.wrab.size = 4;
    } else {
	    MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x00, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	    MK_WRITE_CMD(code[2], D_DTR_DISABLE, 0x00, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	    MK_WRITE_CMD(code[3], D_DTR_DISABLE, 0x00, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	    MK_WRITE_CMD(code[4], D_DTR_DISABLE, 0x00, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
		MK_STOP_CMD(code[5]);
		snor_mio_drv.wrab.size = 6;
    }

	SNOR_MIO_CT_DEBUG("[WRITE AUTOBOOT REG]\n");
	for ( i = 0; i < snor_mio_drv.wrab.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrab.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrab.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrab.offset + i)));
	}

	//-------------------------------------------
	// Write Enable
	//-------------------------------------------
	snor_mio_drv.write_enable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrab);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x06, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_enable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE ENABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_enable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_enable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_enable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_enable.offset + i)));
	}

	//-------------------------------------------
	// Write disable
	//-------------------------------------------
	snor_mio_drv.write_disable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_enable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x04, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_disable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE DISABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_disable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_disable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_disable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_disable.offset + i)));
	}

	//-------------------------------------------
	// enter 4byte mode
	//-------------------------------------------
	snor_mio_drv.en4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_disable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xB7, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.en4b.size = 2;

	SNOR_MIO_CT_DEBUG("[ENTER 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.en4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.en4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.en4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.en4b.offset + i)));
	}

	//-------------------------------------------
	// exit 4byte mode
	//-------------------------------------------
	snor_mio_drv.ex4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.en4b);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x29, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.ex4b.size = 2;

	SNOR_MIO_CT_DEBUG("[EXIT 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.ex4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ex4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ex4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ex4b.offset + i)));
	}

	//-------------------------------------------
	// EAR Write
	//-------------------------------------------
	snor_mio_drv.ear_mode.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ex4b);
	code[0] = 0x40002040;
//	MK_WRITE_DATA(code[1], SFMC_BUF_SIZE, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[1]);
	snor_mio_drv.ear_mode.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE EAR]\n");
	for ( i = 0; i < snor_mio_drv.ear_mode.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ear_mode.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i)));
	}

	code_offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ear_mode);

	return code_offset;
}

static unsigned int SNOR_MIO_Make_MXIC_CMD(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int 	code[5];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// READ Status register (RDSR)
	//-------------------------------------------
	snor_mio_drv.rdsr.offset 	= code_offset;
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_READ_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdsr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.rdsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdsr.offset + i)));
	}

	//-------------------------------------------
	// READ CONFIG register (RDCR)
	//-------------------------------------------
	snor_mio_drv.rdcr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdsr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_READ_CONFIG, 1, LA_KEEP_CS, IO_NUM_SINGLE);

	MK_READ_DATA(code[1], 4, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[2]);
	snor_mio_drv.rdcr.size = 3;

	SNOR_MIO_CT_DEBUG("[READ CONFIG REG]\n");
	for ( i = 0; i < snor_mio_drv.rdcr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.rdcr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.rdcr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.rdcr.offset + i)));
	}

	//-------------------------------------------
	// Write Status register (WRSR)
	//-------------------------------------------
	snor_mio_drv.wrsr.offset 	= SNOR_MIO_Get_Code_Offset(&snor_mio_drv.rdcr);
	MK_WRITE_CMD(code[0], D_DTR_DISABLE, CMD_WRITE_STATUS, 1, LA_KEEP_CS, IO_NUM_SINGLE);
//	MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x40E0, 2, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Status Reg: 0x40, Configure Reg: 0x00
    if ( snor_mio_drv.flags & ADDR_4B) {
	    MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x4000, 2, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Status Reg: 0x40, Configure Reg: 0x00
    } else {
	    MK_WRITE_CMD(code[1], D_DTR_DISABLE, 0x40, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);	// Status Reg: 0x40, Configure Reg: 0x00
    }
	MK_STOP_CMD(code[2]);
	snor_mio_drv.wrsr.size = 3;

	SNOR_MIO_CT_DEBUG("[WRITE STATUS REG]\n");
	for ( i = 0; i < snor_mio_drv.wrsr.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.wrsr.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.wrsr.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.wrsr.offset + i)));
	}

	//-------------------------------------------
	// Write Enable
	//-------------------------------------------
	snor_mio_drv.write_enable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.wrsr);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x06, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_enable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE ENABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_enable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_enable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_enable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_enable.offset + i)));
	}

	//-------------------------------------------
	// Write disable
	//-------------------------------------------
	snor_mio_drv.write_disable.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_enable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0x04, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.write_disable.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE DISABLE]\n");
	for ( i = 0; i < snor_mio_drv.write_disable.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write_disable.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write_disable.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write_disable.offset + i)));
	}

	//-------------------------------------------
	// enter 4byte mode
	//-------------------------------------------
	snor_mio_drv.en4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.write_disable);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xB7, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.en4b.size = 2;

	SNOR_MIO_CT_DEBUG("[ENTER 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.en4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.en4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.en4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.en4b.offset + i)));
	}

	//-------------------------------------------
	// exit 4byte mode
	//-------------------------------------------
	snor_mio_drv.ex4b.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.en4b);

	MK_WRITE_CMD(code[0], D_DTR_DISABLE, 0xE9, 1, LA_DEASSERT_CS, IO_NUM_SINGLE);
	MK_STOP_CMD(code[1]);
	snor_mio_drv.ex4b.size = 2;

	SNOR_MIO_CT_DEBUG("[EXIT 4byte mode]\n");
	for ( i = 0; i < snor_mio_drv.ex4b.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ex4b.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
								 	(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ex4b.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ex4b.offset + i)));
	}

	//-------------------------------------------
	// EAR Write
	//-------------------------------------------
	snor_mio_drv.ear_mode.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ex4b);
	code[0] = 0x40002040;
//	MK_WRITE_DATA(code[1], SFMC_BUF_SIZE, (snor_mio_drv.sfmc_buf.offset << 2), IO_NUM_SINGLE);

	MK_STOP_CMD(code[1]);
	snor_mio_drv.ear_mode.size = 2;

	SNOR_MIO_CT_DEBUG("[WRITE EAR]\n");
	for ( i = 0; i < snor_mio_drv.ear_mode.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.ear_mode.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.ear_mode.offset + i)));
	}

	code_offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.ear_mode);

	return code_offset;
}

unsigned int SNOR_MIO_Make_cmd_lock(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int	code_count;
	unsigned int	addr_io, cmd_io;
	unsigned int 	code[10];
	SNOR_MIO_TRACE();

	snor_mio_drv.individual_lock.offset = code_offset;
	code_count = 0;

	cmd_io 	= IO_NUM_SINGLE;
	addr_io = IO_NUM_SINGLE;

	MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, 0x36, 1, LA_KEEP_CS, cmd_io);
	++code_count;
	MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, 0x00, 3, LA_DEASSERT_CS, addr_io);
	++code_count;
	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.individual_lock.size = code_count;

	SNOR_MIO_CT_DEBUG("[INDIVIDUAL BLOCK/SECTOR LOCK]\n");
	for ( i = 0; i < snor_mio_drv.individual_lock.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.individual_lock.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.individual_lock.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.individual_lock.offset + i)));
	}

	code_offset = snor_mio_drv.individual_lock.offset + snor_mio_drv.individual_lock.size;

	return code_offset;
}

unsigned int SNOR_MIO_Make_cmd_unlock(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int	code_count;
	unsigned int	addr_io, cmd_io;
	unsigned int 	code[10];
	SNOR_MIO_TRACE();

	snor_mio_drv.individual_unlock.offset = code_offset;
	code_count = 0;

	cmd_io 	= IO_NUM_SINGLE;
	addr_io = IO_NUM_SINGLE;

	MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, 0x39, 1, LA_KEEP_CS, cmd_io);
	++code_count;
	MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, 0x00, 3, LA_DEASSERT_CS, addr_io);
	++code_count;
	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.individual_unlock.size = code_count;

	SNOR_MIO_CT_DEBUG("[INDIVIDUAL BLOCK/SECTOR UNLOCK]\n");
	for ( i = 0; i < snor_mio_drv.individual_unlock.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.individual_unlock.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.individual_unlock.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.individual_unlock.offset + i)));
	}

	code_offset = snor_mio_drv.individual_unlock.offset + snor_mio_drv.individual_unlock.size;

	return code_offset;
}

unsigned int SNOR_MIO_Make_cmd_erase(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int	code_count;
	unsigned int	addr_io, cmd_io;
	unsigned int 	code[10];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// Chip Erase (CE) cmd: 0xC7
	//-------------------------------------------
	snor_mio_drv.chip_erase.offset = code_offset;
	code_count = 0;

	if (snor_mio_drv.flags & WR_QPP) {
		cmd_io 	= IO_NUM_QUAD;
		addr_io	= IO_NUM_QUAD;
	} else {
		cmd_io 	= IO_NUM_SINGLE;
		addr_io = IO_NUM_SINGLE;
	}

	MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, CMD_ERASE_CHIP, 1, LA_DEASSERT_CS, cmd_io);
	++code_count;
	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.chip_erase.size = code_count;

	SNOR_MIO_CT_DEBUG("[CHIP ERASE]\n");
	for ( i = 0; i < snor_mio_drv.chip_erase.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.chip_erase.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.chip_erase.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.chip_erase.offset + i)));
	}

	//-------------------------------------------
	// Sector Erase (SE) cmd: 0x20 / 4k-byte
	//-------------------------------------------
	snor_mio_drv.sec_erase.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.chip_erase);
	code_count = 0;

	if (snor_mio_drv.flags & WR_QPP) {
		cmd_io 	= IO_NUM_QUAD;
		addr_io	= IO_NUM_QUAD;
	} else {
		cmd_io 	= IO_NUM_SINGLE;
		addr_io = IO_NUM_SINGLE;
	}

	if ( snor_mio_drv.flags & ADDR_4B) {
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, CMD_ERASE_4K_4B, 1, LA_KEEP_CS, cmd_io);
		++code_count;
		MK_WRITE_DATA(code[code_count], 4, (snor_mio_drv.sfmc_addr.offset), addr_io);
	} else {
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, CMD_ERASE_4K, 1, LA_KEEP_CS, cmd_io);
		++code_count;
		//MK_WRITE_DATA_3B(code[code_count], 3, (snor_mio_drv.sfmc_addr.offset), addr_io);
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, 0x00, 3, LA_DEASSERT_CS, addr_io);
	}
	++code_count;
	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.sec_erase.size = code_count;

	SNOR_MIO_CT_DEBUG("[SECTOR ERASE]\n");
	for ( i = 0; i < snor_mio_drv.sec_erase.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.sec_erase.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.sec_erase.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.sec_erase.offset + i)));
	}

	//-------------------------------------------
	// Block Erase (BE) cmd: 0xd8 / 64k-byte
	//-------------------------------------------
	snor_mio_drv.blk_erase.offset = SNOR_MIO_Get_Code_Offset(&snor_mio_drv.sec_erase);
	code_count = 0;

	if (snor_mio_drv.flags & WR_QPP) {
		cmd_io = IO_NUM_QUAD;
		addr_io= IO_NUM_QUAD;
	} else {
		cmd_io = IO_NUM_SINGLE;
		addr_io = IO_NUM_SINGLE;
	}

	if ( snor_mio_drv.flags & ADDR_4B) {
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, CMD_ERASE_64K_4B, 1, LA_KEEP_CS, cmd_io);
		++code_count;
		MK_WRITE_DATA(code[code_count], 4, (snor_mio_drv.sfmc_addr.offset), addr_io);
	}else{
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, CMD_ERASE_64K, 1, LA_KEEP_CS, cmd_io);
	    ++code_count;
		//MK_WRITE_DATA_3B(code[code_count], 3, (snor_mio_drv.sfmc_addr.offset), addr_io);
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, 0x00, 3, LA_DEASSERT_CS, addr_io);
	}
	++code_count;

	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.blk_erase.size = code_count;

	SNOR_MIO_CT_DEBUG("[BLOCK ERASE]\n");
	for ( i = 0; i < snor_mio_drv.blk_erase.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.blk_erase.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.blk_erase.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.blk_erase.offset + i)));
	}

	code_offset = snor_mio_drv.blk_erase.offset + snor_mio_drv.blk_erase.size;

	return code_offset;
}

unsigned int SNOR_MIO_Make_cmd_write(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int	code_count;
	unsigned int	addr_io, cmd_io;
	unsigned int	write_io;
	unsigned int 	code[10];

	SNOR_MIO_TRACE();
	//-------------------------------------------
	// WRITE
	//-------------------------------------------
	snor_mio_drv.write.offset = code_offset;
	code_count = 0;

	cmd_io		= IO_NUM_SINGLE;
	addr_io 	= IO_NUM_SINGLE;
	write_io	= IO_NUM_SINGLE;

	if (snor_mio_drv.cmd_write == CMD_4PP4B) {
		cmd_io		= IO_NUM_SINGLE;
		addr_io		= IO_NUM_QUAD;
		write_io 	= IO_NUM_QUAD;
	} else if (snor_mio_drv.cmd_write == CMD_PP4B) {
		cmd_io 		= IO_NUM_SINGLE;
		addr_io 	= IO_NUM_SINGLE;
		write_io 	= IO_NUM_SINGLE;
	}

	MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, snor_mio_drv.cmd_write, 1, LA_KEEP_CS, cmd_io);
	++code_count;
	if (snor_mio_drv.flags & ADDR_4B) {
		MK_WRITE_PP_ADDR(code[code_count], 4, (snor_mio_drv.sfmc_addr.offset), addr_io);
	}else {
		//MK_WRITE_PP_ADDR_3B(code[code_count], 3, (snor_mio_drv.sfmc_addr.offset), addr_io);
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, 0x00, 3, LA_KEEP_CS, addr_io);
	}
	++code_count;
	MK_WRITE_DATA(code[code_count], SFMC_BUF_SIZE, (snor_mio_drv.sfmc_buf.offset), write_io);
	++code_count;

	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.write.size = code_count;

	SNOR_MIO_CT_DEBUG("[WRITE]\n");
	for ( i = 0; i < snor_mio_drv.write.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.write.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.write.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.write.offset + i)));
	}

	code_offset = snor_mio_drv.write.offset + snor_mio_drv.write.size;

	return code_offset;
}

unsigned int SNOR_MIO_Make_cmd_read(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int	code_count;
	unsigned int	dummy_io;
	unsigned int 	code[10];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// READ
	//-------------------------------------------
	snor_mio_drv.read.offset = code_offset;

	code_count = 0;

	MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, snor_mio_drv.cmd_read, 1, LA_KEEP_CS, IO_NUM_SINGLE);
	++code_count;

	switch (snor_mio_drv.cmd_read) {
		case CMD_READ:
		case CMD_READ4B:
			dummy_io 	= IO_NUM_NC;
			break;

		case CMD_FAST_READ:
		case CMD_FAST_READ4B:
			dummy_io	= IO_NUM_SINGLE;
			break;

		default:
			dummy_io 	= IO_NUM_NC;
			break;
	}

	if (snor_mio_drv.flags & ADDR_4B) {
		MK_WRITE_ADDR_AHB(code[code_count], D_DTR_DISABLE, IO_NUM_SINGLE);
	} else {
		MK_WRITE_ADDR_AHB_3B(code[code_count], D_DTR_DISABLE, IO_NUM_SINGLE);
	}

	++code_count;

	if (dummy_io != IO_NUM_NC) {
		MK_WRITE_DUMMY_CYCLE(code[code_count], D_DTR_DISABLE, 1, dummy_io);
		++code_count;
	}

	MK_READ_DATA_AHB(code[code_count], D_DTR_DISABLE, IO_NUM_SINGLE);
	++code_count;
	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.read.size = code_count;

	SNOR_MIO_CT_DEBUG("[READ]\n");
	for ( i = 0; i < snor_mio_drv.read.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.read.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.read.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.read.offset + i)));
	}

	code_offset = snor_mio_drv.read.offset + snor_mio_drv.read.size;

	return code_offset;
}

unsigned int SNOR_MIO_Make_cmd_read_fast(unsigned int code_offset)
{
	unsigned int	i;
	unsigned int	code_count;
	unsigned int	addr_io, read_io, dummy_io, cmd_io;
	unsigned int	cmd_count;
	unsigned int 	dummy_count;
	unsigned int	performance_enhance;
	unsigned int 	code[10];
	SNOR_MIO_TRACE();

	//-------------------------------------------
	// READ
	//-------------------------------------------
	snor_mio_drv.read_fast.offset = code_offset;

	// Set default
	snor_mio_drv.dt_mode = D_DTR_DISABLE;
	cmd_io = IO_NUM_SINGLE;
	dummy_count = 1;
	cmd_count = 1;
	performance_enhance = FALSE;

	switch (snor_mio_drv.cmd_read_fast) {
		case CMD_READ:
		case CMD_READ4B:
			addr_io 	= IO_NUM_SINGLE;
			read_io 	= IO_NUM_SINGLE;
			dummy_io 	= IO_NUM_NC;
			break;

		case CMD_FAST_READ:
		case CMD_FAST_READ4B:
			addr_io 	= IO_NUM_SINGLE;
			read_io 	= IO_NUM_SINGLE;
			dummy_io	= IO_NUM_SINGLE;
			break;

		case CMD_FASTDTRD_4B:
			addr_io 	= IO_NUM_SINGLE;
			read_io 	= IO_NUM_SINGLE;
			dummy_io	= IO_NUM_SINGLE;
			snor_mio_drv.dt_mode = D_DTR_ENABLE;
			break;

		case CMD_DREAD:
			addr_io 	= IO_NUM_SINGLE;
			read_io 	= IO_NUM_DUAL;
			dummy_io	= IO_NUM_SINGLE;
			break;

		case CMD_QREAD:
			addr_io 	= IO_NUM_SINGLE;
			read_io 	= IO_NUM_QUAD;
			dummy_io	= IO_NUM_SINGLE;
			cmd_io 		= IO_NUM_SINGLE;
			break;

		case CMD_4DTRD:
		case CMD_4DTRD4B:
			addr_io 	= IO_NUM_QUAD;
			read_io 	= IO_NUM_QUAD;
			dummy_io	= IO_NUM_QUAD;
			cmd_io 		= IO_NUM_SINGLE;
			snor_mio_drv.dt_mode = D_DTR_ENABLE;
			dummy_count = 8;
			performance_enhance = TRUE;
			break;

		case CMD_4READ:
		case CMD_4READ4B:
			addr_io 	= IO_NUM_QUAD;
			read_io 	= IO_NUM_QUAD;
			dummy_io	= IO_NUM_QUAD;
			cmd_io		= IO_NUM_SINGLE;
			snor_mio_drv.dt_mode = D_DTR_DISABLE;
			dummy_count = 2;
			performance_enhance = TRUE;
			break;

		case CMD_QREAD4B:
			addr_io 	= IO_NUM_SINGLE;
			dummy_io	= IO_NUM_SINGLE;
			read_io 	= IO_NUM_QUAD;
			cmd_io 		= IO_NUM_SINGLE;
			break;

		case CMD_8READ:
			addr_io 	= IO_NUM_OCTA;
			read_io 	= IO_NUM_OCTA;
			dummy_io	= IO_NUM_OCTA;
			cmd_io		= IO_NUM_OCTA;
			dummy_count = 0x15;
			cmd_count 	= 2;
			break;

		case CMD_8DTRD:
			addr_io 	= IO_NUM_OCTA;
			read_io 	= IO_NUM_OCTA;
			dummy_io	= IO_NUM_OCTA;
			cmd_io 		= IO_NUM_OCTA;
			dummy_count = 0x15;
			cmd_count 	= 2;
			snor_mio_drv.dt_mode = D_DTR_ENABLE;
			break;

		default:
			addr_io 	= IO_NUM_SINGLE;
			read_io 	= IO_NUM_SINGLE;
			dummy_io 	= IO_NUM_NC;
			break;
	}

	code_count = 0;

	if (cmd_io == IO_NUM_OCTA) {
		MK_WRITE_CMD(code[code_count], snor_mio_drv.dt_mode, snor_mio_drv.cmd_read_fast, cmd_count, LA_KEEP_CS, cmd_io);
	} else {
		MK_WRITE_CMD(code[code_count], D_DTR_DISABLE, snor_mio_drv.cmd_read_fast, cmd_count, LA_KEEP_CS, cmd_io);
	}
	++code_count;

	if (snor_mio_drv.flags & ADDR_4B) {
		MK_WRITE_ADDR_AHB(code[code_count], snor_mio_drv.dt_mode, addr_io);
	} else {
		MK_WRITE_ADDR_AHB_3B(code[code_count], snor_mio_drv.dt_mode, addr_io);
	}

	++code_count;

	if (performance_enhance == TRUE) {
		// performance enhance mode
		MK_WRITE_CMD(code[code_count], snor_mio_drv.dt_mode, 0x00, 1, LA_KEEP_CS, dummy_io);
		++code_count;
	}

	if (dummy_io != IO_NUM_NC) {
		MK_WRITE_DUMMY_CYCLE(code[code_count], snor_mio_drv.dt_mode, dummy_count, dummy_io);
		++code_count;
	}

	MK_READ_DATA_AHB(code[code_count], snor_mio_drv.dt_mode, read_io);
	++code_count;
	MK_STOP_CMD(code[code_count]);
	++code_count;
	snor_mio_drv.read_fast.size = code_count;

	SNOR_MIO_CT_DEBUG("[READ_FAST]\n");
	for ( i = 0; i < snor_mio_drv.read_fast.size; ++i ) {
		SET_CODE_TABLE((snor_mio_drv.read_fast.offset + i), code[i]);

		SNOR_MIO_CT_DEBUG( "[0x%08X][0x%08X]\n",
									(SFMC_REG_CODE_TABLE + ((snor_mio_drv.read_fast.offset + i) <<2)),
									GET_CODE_TABLE((snor_mio_drv.read_fast.offset + i)));
	}

	code_offset = snor_mio_drv.read_fast.offset + snor_mio_drv.read_fast.size;

	return code_offset;
}

void SNOR_MIO_Make_CMD(unsigned int code_offset)
{
	SNOR_MIO_TRACE();
	code_offset = SNOR_MIO_Make_cmd_read(code_offset);
	code_offset = SNOR_MIO_Make_cmd_write(code_offset);
	code_offset = SNOR_MIO_Make_cmd_erase(code_offset);
//	code_offset = SNOR_MIO_Make_cmd_lock(code_offset);
//	code_offset = SNOR_MIO_Make_cmd_unlock(code_offset);
	SNOR_MIO_Make_cmd_read_fast(code_offset);
}

int SNOR_MIO_Init(void)
{
	unsigned int code_offset;
//	unsigned int ip_num, version;
	int res = FALSE;
	unsigned char memory_type;

	SNOR_MIO_TRACE();

	SNOR_MIO_PortConfig();

//	tcc_set_peri((int)PERI_MICOM_SFMC, ENABLE, XIN_CLK_RATE);

	//-------------------------------------------
	// Controller Setting
	//-------------------------------------------
	SNOR_MIO_DEBUG("SNOR Mode Selection\n");

	//mdelay(10);
//	ip_num = 	*(volatile unsigned int *)(SFMC_REG_MAGIC);
//	version = 	*(volatile unsigned int *)(SFMC_REG_VERSION);
//	SNOR_MIO_CT_DEBUG("SNOR IP Num: 0x%08X, Ver: 0x%08X\n", ip_num, version);

	SET_CMD_RUN(SFMC_REG_RUN_SOFT_RESET|SFMC_REG_RUN_AUTO_STOP);

    *(volatile unsigned int *)(SFMC_REG_MODE) = SFMC_REG_MODE_FLASH_RESET;

	mdelay(10);

	SET_CMD_RUN(~SFMC_REG_RUN_SOFT_RESET);

	*(volatile unsigned int *)(SFMC_REG_TIMING)		= SFMC_REG_TIMING_SC_EXTND(0) |
													  SFMC_REG_TIMING_CS_TO_CS(4) |
													  SFMC_REG_TIMING_READ_LATENCY(3) |
													  SFMC_REG_TIMING_SEL_DQS_FCLK;
    *(volatile unsigned int *)(SFMC_REG_DELAY_SO)	= SFMC_REG_DELAY_SO_INV_SCLK(1) |
													  SFMC_REG_DELAY_SO_SLCH(1);

    *(volatile unsigned int *)(SFMC_REG_DELAY_CLK)	= 0;

	SNOR_MIO_DEBUG("SPI-STR mode Set Done\n");

	code_offset = SNOR_MIO_Make_cmd_readid();

	res = SNOR_MIO_CheckMemoryType();
	if (res == FALSE) {
		SNOR_MIO_DEBUG("Failed to read SNOR ID\n");
		return -1;
	}

	switch (snor_mio_drv.ManufID)
	{
		case 0xEF:
		case 0xC8: /* GigaDevice is the same as Winbond */
			code_offset = SNOR_MIO_Make_WINBOND_CMD(code_offset);
			break;
		case 0x01:
			code_offset = SNOR_MIO_Make_CYPRESS_CMD(code_offset);
			break;
		case 0x20:
			memory_type = (snor_mio_drv.DevID >> 8) & 0xFF;
			if (memory_type == 0x70) /* XMC */
				code_offset = SNOR_MIO_Make_XMC_CMD(code_offset);
			else /* MICRON */
				printf("MICRON SNOR is not supported yet.\n");
			break;
		case 0x9D:
			code_offset = SNOR_MIO_Make_ISSI_CMD(code_offset);
			break;
		default:
			code_offset = SNOR_MIO_Make_MXIC_CMD(code_offset);
			break;
	}
#if 0
	if ( snor_mio_drv.flags & ADDR_4B)
		SNOR_MIO_4B_Enable();
#endif
	SNOR_MIO_Make_CMD(code_offset);

	switch (snor_mio_drv.ManufID)
	{
		case 0xEF:
		case 0xC8:
			SNOR_MIO_WINBOND_DefaultConfig();
			break;
		case 0x01:
			SNOR_MIO_CYPRESS_DefaultConfig();
			break;
		case 0x20:
			memory_type = (snor_mio_drv.DevID >> 8) & 0xFF;
			if (memory_type == 0x70) /* XMC */
				SNOR_MIO_XMC_DefaultConfig();
			else /* MICRON */
				printf("MICRON SNOR is not supported yet.\n");
			break;
		case 0x9D:
			SNOR_MIO_ISSI_DefaultConfig();
			break;
		default:
			SNOR_MIO_MXIC_DefaultConfig();
			break;
	}

	snor_mio_drv.uiDataBuffer = (unsigned int* )malloc(SNOR_SECTOR_SIZE);
#if 0
	tcc_set_peri((int)PERI_MICOM_SFMC, ENABLE, (40*1000*1000));

	SNOR_MIO_QuadEnable();

	if (snor_mio_drv.uiDataBuffer == NULL)
		printf("Memory allocation failed\n");
#endif

//	SNOR_MIO_IO_Clock_Training();
//	SNOR_MIO_IO_READ_TEST();
//	SNOR_MIO_IO_TEST();

	return 0;
}


void sfmc_test_SWRST_RC_TIME (unsigned int warm_boot, unsigned int reset_enable, unsigned int reset_start, unsigned int cmd_iteration, unsigned int run_iteration)
{
	unsigned int	addr, data_temp, manu_run;
        *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x00) = reset_enable;
        *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x04) = 0xF00003E8; //enough, tSHSL : 7ns ~ 30ns
        *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x08) = reset_start;

        if (warm_boot != 1) { // cold boot, just 40us reset recovery time
            *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x0C) = 0xF0002710; // 40us
            *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x10) = 0xF4000000;
        } else { // warm boot, wait command iteration
            for (addr=0;addr<cmd_iteration;addr++) {
            *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x0C+(addr<<2)) = 0xF0002710; // 40us x 255ea(max) -> 10.2ms
            }
            *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x0C+(addr<<2)) = 0xF4000000;
        }

        *(volatile unsigned int *)(SFMC_REG_BADDR_MANU) = 0x00000800;
        *(volatile unsigned int *)(SFMC_REG_RUN)        = 0x00000001;

            while(1)
            {
                data_temp = *(volatile unsigned int *)(SFMC_REG_RUN);
                if (data_temp==0x0)
                        break;
            }

        if (warm_boot == 1) { // warm boot, manual run iteration
            for (manu_run=0;manu_run<run_iteration-1;manu_run++) {
            *(volatile unsigned int *)(SFMC_REG_BADDR_MANU) = 0x0000080C;
            *(volatile unsigned int *)(SFMC_REG_RUN)        = 0x00000001;

                while(1)
                {
                    data_temp = *(volatile unsigned int *)(SFMC_REG_RUN);
                    if (data_temp==0x0)
                        break;
                }
            } //run iteration
        } //warm boot only

}

void sfmc_test_RST_RC_TIME(unsigned int warm_boot, unsigned int otp_rst_rcvl)
{
	unsigned int reset_enable;
	unsigned int reset_start;
	unsigned int spi_swreset;
	unsigned int qpi_swreset;
	unsigned int opi_str_swreset;
	unsigned int opi_dtr_swreset;
	unsigned int cmd_iteration;
	unsigned int run_iteration;
	unsigned int swreset_mode;
	unsigned int	nReg, data_temp, addr, manu_run;
    /* caution!!!!! reset recovery time needs from 40us to 1s
    40us(0xF0002710) -> 40us                                                 for cold boot
    40us(0xF0002710) x command_iteration(255ea) x run_iteration(100ea) -> 1s for warm boot
    */

    cmd_iteration = (otp_rst_rcvl & 0x000000FF) >>  0;
    //DBG_PRINTF("cmd_iteration : %x", cmd_iteration);
    run_iteration = (otp_rst_rcvl & 0x0000FF00) >>  8;
    //DBG_PRINTF("run_iteration : %x", run_iteration);
    swreset_mode  = (otp_rst_rcvl & 0xF0000000) >> 28;
    //DBG_PRINTF("swreset_mode : %x", swreset_mode);

    spi_swreset     = (swreset_mode & 0x1) >> 0;
    qpi_swreset     = (swreset_mode & 0x2) >> 1;
    opi_str_swreset = (swreset_mode & 0x4) >> 2;
    opi_dtr_swreset = (swreset_mode & 0x8) >> 3;

    //////////////////////////////////////////
    //H/W Reset Recovery Time Configuration
    //////////////////////////////////////////
    *(volatile unsigned int *)(SFMC_REG_MODE)       = 0x00000000;
    for (nReg=0;nReg<0x20;nReg++); // don't remove!!!! (Reset# low pulse width > 10us)
    *(volatile unsigned int *)(SFMC_REG_MODE)       = 0x00000015;

    if (warm_boot != 1) { // cold boot, just 40us reset recovery time
        *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x00) = 0xF0002710; // 40us
        *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x04) = 0xF4000000;

        *(volatile unsigned int *)(SFMC_REG_BADDR_MANU) = 0x00000800;
        *(volatile unsigned int *)(SFMC_REG_RUN)        = 0x00000001;

            while(1)
            {
                data_temp = *(volatile unsigned int *)(SFMC_REG_RUN);
                if (data_temp==0x0)
                        break;
            }

    } else { // warm_boot, reset recovery time is configured by otp
        for (addr=0;addr<cmd_iteration;addr++) {
        *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x00+(addr<<2)) = 0xF0002710; // 40us x 255ea(max) -> 10.2ms
        }
        *(volatile unsigned int *)(SFMC_REG_CODE_TABLE + 0x00+(addr<<2)) = 0xF4000000;

        for (manu_run=0;manu_run<run_iteration;manu_run++) { // 10.2ms x 255ea(max) -> 2.6s
        *(volatile unsigned int *)(SFMC_REG_BADDR_MANU) = 0x00000800;
        *(volatile unsigned int *)(SFMC_REG_RUN)        = 0x00000001;

            while(1)
            {
                data_temp = *(volatile unsigned int *)(SFMC_REG_RUN);
                if (data_temp==0x0)
                        break;
            }
        } //run_iteration
    } //cold vs. warm

    //////////////////////////////////////////
    //S/W Reset Recovery Time Configuration
    //////////////////////////////////////////
    //otp_rst_rcvl[28] == 1    -> SPI S/W reset Enable
    if  (spi_swreset) {
        reset_enable = 0xA4000066;
        reset_start  = 0xA4000099;

		printf(" SPI S/W Reset\n");
        sfmc_test_SWRST_RC_TIME(warm_boot,reset_enable,reset_start,cmd_iteration,run_iteration);
    }
    //otp_rst_rcvl[29] == 1    -> QPI S/W reset Enable
    if  (qpi_swreset) {
        reset_enable = 0xA6000066;
        reset_start  = 0xA6000099;

		printf(" QPI S/W Reset\n");
        sfmc_test_SWRST_RC_TIME(warm_boot,reset_enable,reset_start,cmd_iteration,run_iteration);
    }
    //otp_rst_rcvl[30] == 1    -> OPI_STR S/W reset Enable
    if  (opi_str_swreset) {
        reset_enable = 0xAB006699;
        reset_start  = 0xAB009966;

		printf(" OPI_STR S/W Reset\n");
        sfmc_test_SWRST_RC_TIME(warm_boot,reset_enable,reset_start,cmd_iteration,run_iteration);
    }
    //otp_rst_rcvl[31] == 1    -> OPI_DTR S/W reset Enable
    if  (opi_dtr_swreset) {
        reset_enable = 0xAB006699; //check!! change to dtr mode
        reset_start  = 0xAB009966; //check!! change to dtr mode

		printf(" OPI_DTR S/W Reset\n");
        sfmc_test_SWRST_RC_TIME(warm_boot,reset_enable,reset_start,cmd_iteration,run_iteration);
    }
}

static unsigned char SNOR_MIO_ReadConfig(void)
{
	unsigned int	data;
	unsigned char 	config;
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.rdcr.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	data = (unsigned int)GET_CODE_TABLE(snor_mio_drv.sfmc_buf.offset);
	config = (data & 0xFF);
	//SNOR_MIO_DEBUG("status: 0x%08X\n", status);

	return config;
}

static unsigned char SNOR_MIO_ReadConfig1(void)
{
	unsigned int	data;
	unsigned char 	config;
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.rdcr1.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	data = (unsigned int)GET_CODE_TABLE(snor_mio_drv.sfmc_buf.offset);
	config = (data & 0xFF);
	//SNOR_MIO_DEBUG("status: 0x%08X\n", status);

	return config;
}

static unsigned char SNOR_MIO_ReadConfig2(void)
{
	unsigned int	data;
	unsigned char 	config;
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.rdcr2.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	data = (unsigned int)GET_CODE_TABLE(snor_mio_drv.sfmc_buf.offset);
	config = (data & 0xFF);
	//SNOR_MIO_DEBUG("status: 0x%08X\n", status);

	return config;
}

static unsigned char SNOR_MIO_ReadStatus(void)
{
	unsigned int	data;
	unsigned char 	status;
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.rdsr.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	data = (unsigned int)GET_CODE_TABLE(snor_mio_drv.sfmc_buf.offset);
	status = (data & 0xFF);

	//SNOR_MIO_DEBUG("status: 0x%08X\n", status);

	return status;
}

static unsigned char SNOR_MIO_ReadStatus1(void)
{
	unsigned int	data;
	unsigned char 	status;
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.rdsr1.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	data = (unsigned int)GET_CODE_TABLE(snor_mio_drv.sfmc_buf.offset);
	status = (data & 0xFF);
	//SNOR_MIO_DEBUG("status: 0x%08X\n", status);

	return status;
}

static unsigned char SNOR_MIO_ReadStatus2(void)
{
	unsigned int	data;
	unsigned char 	status;
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.rdsr2.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	data = (unsigned int)GET_CODE_TABLE(snor_mio_drv.sfmc_buf.offset);
	status = (data & 0xFF);
	//SNOR_MIO_DEBUG("status: 0x%08X\n", status);

	return status;
}

static int SNOR_MIO_WaitWriteComplete(void)
{
	unsigned char nStatus;
	unsigned int retry_count;

	retry_count = 10000;
    while(1)
    {
        nStatus = (unsigned char)SNOR_MIO_ReadStatus();
        if (ISZERO(nStatus,Hw0)) //check WIP
            break;

		--retry_count;
		mdelay(1);
		if (retry_count == 0)
		{
			printf("\x1b[1;33m[%s:%d]\x1b[0m\n", __func__, __LINE__);
			return -1;
    }
}

	return 0;
}

static void SNOR_MIO_SetPort(void)
{
	SNOR_MIO_TRACE();
}

static void SNOR_MIO_ReleasePort(void)
{
	SNOR_MIO_TRACE();
}


static void SNOR_MIO_4B_Disable(void)
{
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.ex4b.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
}


static int SNOR_MIO_WriteEnable(void)
{
    unsigned char nStatus;
	unsigned int retry_count;

    SNOR_MIO_TRACE();
	retry_count = 10000;
    while(1)
    {
        SET_CMD_MANU_ADDR(snor_mio_drv.write_enable.offset);
        SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
        WAIT_CMD_COMPLETE();

        nStatus = (unsigned char)SNOR_MIO_ReadStatus();
        if (!ISZERO(nStatus,Hw1)) //check WEL
            break;

		--retry_count;
		mdelay(1);
		if (retry_count == 0)
		{
			return -1;
		}
    }
	return 0;
}

static int SNOR_MIO_ISSI_DefaultConfig(void)
{
	unsigned char 	status;
	unsigned char 	config;
	int		res;
	SNOR_MIO_TRACE();

	status = SNOR_MIO_ReadStatus();
	printf("Read Status Reg - status: 0x%02X\n", status);

	printf("Set QE (Quad Enable) bit\n");
	printf("Disable AUTOBOOT\n");
	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.wrsr.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();

	SET_CMD_MANU_ADDR(snor_mio_drv.wrab.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();
	status = SNOR_MIO_ReadStatus();
	printf("Read Status Reg - status: 0x%02X\n", status);

	config = SNOR_MIO_ReadConfig();
	printf("Read Config Reg - Config: 0x%02X\n", config);
	return res;
}


static int SNOR_MIO_MXIC_DefaultConfig(void)
{
	unsigned char 	status;
	unsigned char 	config;
	int		res;
	SNOR_MIO_TRACE();

	status = SNOR_MIO_ReadStatus();
	printf("Read Status Reg - status: 0x%02X\n", status);

	if(ISZERO(status,Hw6))
	{
		printf("Set QE (Quad Enable) bit\n");
		res = SNOR_MIO_WriteEnable();
		SET_CMD_MANU_ADDR(snor_mio_drv.wrsr.offset);
		SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
		WAIT_CMD_COMPLETE();
		res = SNOR_MIO_WaitWriteComplete();

		status = SNOR_MIO_ReadStatus();
		printf("Read Status Reg - status: 0x%02X\n", status);
	}

	config = SNOR_MIO_ReadConfig();
	printf("Read Config Reg - Config: 0x%02X\n", config);
	return res;
}

static int SNOR_MIO_WINBOND_WRSR1_Default(void)
{
	int		res;
	SNOR_MIO_TRACE();

	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.wrsr1.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();

	return res;
}

static int SNOR_MIO_WINBOND_WRSR2_Default(void)
{
	int		res;
	SNOR_MIO_TRACE();

	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.wrsr2.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();

	return res;
}

static int SNOR_MIO_WINBOND_DefaultConfig(void)
{
	unsigned char 	status;
	int		res;
	SNOR_MIO_TRACE();

	status = SNOR_MIO_ReadStatus();
	printf("Read Status Reg(05h) - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadStatus1();
	printf("Read Status1 Reg(35h) - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadStatus2();
	printf("Read Status2 Reg(15h) - status: 0x%02X\n", status);

	res = SNOR_MIO_WINBOND_WRSR1_Default();
	printf("Set QE (Quad Enable) bit\n");
	res |= SNOR_MIO_WINBOND_WRSR2_Default();
	printf("Clear WPS (Write Protect Selection) bit\n");

	status = SNOR_MIO_ReadStatus();
	printf("Read Status Reg(05h) - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadStatus1();
	printf("Read Status1 Reg(35h) - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadStatus2();
	printf("Read Status2 Reg(15h) - status: 0x%02X\n", status);

	return res;
}

static int SNOR_MIO_CYPRESS_DefaultConfig(void)
{
	unsigned char 	status;
	unsigned char 	config;
	int		res;
	SNOR_MIO_TRACE();

	status = SNOR_MIO_ReadStatus();
	printf("Read Status-1 Reg - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadConfig();
	printf("Read Config-1 Reg - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadConfig1();
	printf("Read Config-2 Reg - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadConfig2();
	printf("Read Config-3 Reg - status: 0x%02X\n", status);

	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.wrsr.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();
	printf("Default set for TCC\n");

	status = SNOR_MIO_ReadStatus();
	printf("Read Status-1 Reg - status: 0x%02X\n", status);
	config = SNOR_MIO_ReadConfig();
	printf("Read Config-1 Reg - Config: 0x%02X\n", config);
	status = SNOR_MIO_ReadConfig1();
	printf("Read Config-2 Reg - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadConfig2();
	printf("Read Config-3 Reg - status: 0x%02X\n", status);

	return res;
}

static int SNOR_MIO_XMC_DefaultConfig(void)
{
	unsigned char 	status;
	int		res;
	SNOR_MIO_TRACE();

	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.wrsr.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();

	SET_CMD_MANU_ADDR(snor_mio_drv.wrsr2.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();

	printf("Default set for TCC\n");

	status = SNOR_MIO_ReadStatus();
	printf("Read Status Reg(05h) - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadStatus1();
	printf("Read Status2 Reg(09h) - status: 0x%02X\n", status);
	status = SNOR_MIO_ReadStatus2();
	printf("Read Status3 Reg(95h) - status: 0x%02X\n", status);

	return res;
}

static void SNOR_MIO_WriteDisable(void)
{
	SNOR_MIO_TRACE();
	SET_CMD_MANU_ADDR(snor_mio_drv.write_disable.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
}

#if 0		/* 017.04.10 */
static void SNOR_MIO_WriteEAR(unsigned int address)
{
	SNOR_MIO_TRACE();
	address = (address & 0xFF000000) >> 24;

	SET_CMD_MANU_ADDR(snor_mio_drv.ear_mode.offset);
	address |= ( CMD_EAR << 8) & 0x0000FF00;
	address |= ( address << 16) & 0xFFFF0000;
	SET_CODE_TABLE(snor_mio_drv.sfmc_addr.offset, address);

	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
}
#endif /* 0 */

#if 0
static int SNOR_MIO_IndividualLock(unsigned int address)
{
	int res;

	SNOR_MIO_TRACE();
	SNOR_MIO_DEBUG("sec_unlock: 0x%08X\n", address);

	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.individual_lock.offset);

	SET_CODE_TABLE_ERASE_ADDR(snor_mio_drv.individual_lock.offset, address);

	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();

	return res;
}

static int SNOR_MIO_IndividualUnlock(unsigned int address)
{
	int res;

	SNOR_MIO_TRACE();
	SNOR_MIO_DEBUG("sec_unlock: 0x%08X\n", address);

	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.individual_unlock.offset);

	SET_CODE_TABLE_ERASE_ADDR(snor_mio_drv.individual_unlock.offset, address);

	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();

	return res;
}
#endif

static int SNOR_MIO_ChipErase(void)
{
	int res;

	SNOR_MIO_TRACE();
	SNOR_MIO_DEBUG("%s\n", __func__);

	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.chip_erase.offset);
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	while (1) {
		res = SNOR_MIO_WaitWriteComplete();
		if (!res)
			break;
	}

	return res;
}

static int SNOR_MIO_BlockErase(unsigned int address)
{
	int res;

	SNOR_MIO_TRACE();
	SNOR_MIO_DEBUG("blk_erase: 0x%08X\n", address);
	//SNOR_MIO_WriteEAR(address);
	//address = (address & 0x00FFFFFF);
	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.blk_erase.offset);
	if (snor_mio_drv.flags & ADDR_4B) {
		//address |= ( CMD_ERASE_64K<< 24) & 0xFF000000;
		SET_CODE_TABLE(snor_mio_drv.sfmc_addr.offset, address);
	} else {
		SET_CODE_TABLE_ERASE_ADDR(snor_mio_drv.blk_erase.offset, address);
	}
	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();
	return res;
}

static int SNOR_MIO_SectorErase(unsigned int address)
{
	int res;

	SNOR_MIO_TRACE();
	//SNOR_MIO_DEBUG("sec_erase: 0x%08X\n", address);
	//SNOR_MIO_WriteEAR(address);
	//address = (address & 0x00FFFFFF);
	res = SNOR_MIO_WriteEnable();
	SET_CMD_MANU_ADDR(snor_mio_drv.sec_erase.offset);

	if (snor_mio_drv.flags & ADDR_4B) {
		//address |= (snor_mio_drv.erase_cmd << 24) & 0xFF000000;
		SET_CODE_TABLE(snor_mio_drv.sfmc_addr.offset, address);
	} else {
		SET_CODE_TABLE_ERASE_ADDR(snor_mio_drv.sec_erase.offset, address);
	}

	SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
	WAIT_CMD_COMPLETE();
	res = SNOR_MIO_WaitWriteComplete();
	return res;
}

void SNOR_MIO_Erase(unsigned int address, unsigned int size)
{
	unsigned int lba = 0;
	unsigned int nPercent, nPercent_unit;

	unsigned int count_4k = 0;
	SNOR_MIO_TRACE();

	//printf("[SNOR Erase] addr: 0x%08x, size: %8d kbyte     ", address, size>>10);


	if (address & 0xFFF)
	{
		//Address Error
		return;
	}

	if ((address & 0xFFFF) && (size > (64 * 1024)))
	{
		count_4k = (64 * 1024) - (address & 0xFFFF);

		for(lba = 0;lba < count_4k; lba += 4*1024) {
			//SNOR_MIO_DEBUG("Sector Erase : 0x%08x\n\r", address + lba);
			SNOR_MIO_SectorErase(address + lba);
		}

		address += count_4k;
		size -= count_4k;
	}

	nPercent = 0;
	nPercent_unit = ( size / (64*1024));
	for (lba = 0;lba < nPercent_unit; lba++) {
		//if (lba && !(lba%41))
		//  printf("\r\n");
		if (nPercent<99)
		{
			//  nPercent += 100/nPercent_unit;
			nPercent = (100*lba)/nPercent_unit;
			printf("\b\b\b\b%3d%%", nPercent);
		}

		//printf("Sector Erase: 0x%08x, nPercent_unit: %d, nPercent: %d\n", address, nP     ercent_unit, nPercent);
		SNOR_MIO_BlockErase(address);
		address += 64*1024;
		size -= 64*1024;
	}

	if (size > 0)
	{
		nPercent_unit = size % (4*1024);
		if (nPercent_unit) nPercent_unit = size / (4*1024) + 1;
		else nPercent_unit = size / (4*1024);

		for (lba = 0;lba < nPercent_unit; lba ++) {
			//printf("Sector Erase : 0x%08x\n", address);
			SNOR_MIO_SectorErase(address);
			address += 4*1024;
			size -= 4*1024;
		}
	}

	printf("\b\b\b\b%3d%%", 100);
	printf(" OK.\r\n");
}

static int SNOR_MIO_WriteByte(unsigned int address, unsigned char *pBuffer, unsigned int lengthInByte)
{
	unsigned int sfmc_buff_addr;
	unsigned int write_address;
	int	res = FALSE;
	SNOR_MIO_TRACE();
//	SNOR_MIO_DEBUG("[%s]address: 0x%08X, buffer: 0x%08X, length: %d\n", __func__, address, (unsigned int)pBuffer, lengthInByte);

	while(lengthInByte)
	{
		unsigned int nCountInPage;
		nCountInPage = 256 - (address&0xFF);
		if (nCountInPage > lengthInByte)
			nCountInPage = lengthInByte;

		write_address = address;

		res = SNOR_MIO_WriteEnable();

		SET_CMD_MANU_ADDR(snor_mio_drv.write.offset);

		sfmc_buff_addr = GET_CODE_TABLE_ADDR(snor_mio_drv.sfmc_buf.offset);
		memset((void*)sfmc_buff_addr, 0xFF, 256);
		memcpy((void*)sfmc_buff_addr, (const void*)pBuffer, nCountInPage);

		if (snor_mio_drv.flags & ADDR_4B) {
			SET_CODE_TABLE(snor_mio_drv.sfmc_addr.offset, write_address);
		} else {
			SET_CODE_TABLE_WRITE_ADDR(snor_mio_drv.write.offset, write_address);
		}

		SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
		WAIT_CMD_COMPLETE();
		res = SNOR_MIO_WaitWriteComplete();

		pBuffer	+= nCountInPage;
		address += nCountInPage;
		lengthInByte -= nCountInPage;
	}

	return res;
}

int SNOR_MIO_Write(unsigned int address, const void *pBuffer, unsigned int length)
{
	SNOR_MIO_TRACE();
	SNOR_MIO_DEBUG("Write address: 0x%08X, buffer: 0x%08X, length: %d\n", address, (unsigned int)pBuffer, length);

	SNOR_MIO_WriteByte(address,(unsigned char*)pBuffer,length);

	return 0;
}

#if 0
int SNOR_MIO_WriteSector(unsigned int lba_addr, const void *pBuffer, unsigned int nSector)
{
	unsigned int 	*uiBuffer;
	unsigned char	*ucpCompBuffer;
	unsigned char 	*ucpBuffer;
	unsigned char 	*ucpWriteBuffer;
	unsigned int	i;

	unsigned int	start_lba_addr, end_lba_addr;
	unsigned int	start_snor_sec_addr, erase_snor_sec_count;
	unsigned int 	loop_lba_end;
	unsigned int 	head_merge_sec_count, tail_merge_sec_count;
	unsigned int	partial_sec_count;
	unsigned int	uiLba_Addr;

	uiBuffer		 =	snor_mio_drv.uiDataBuffer;
	ucpCompBuffer	 =	(unsigned char  *)snor_mio_drv.uiCompBuffer;
	ucpBuffer		 = (unsigned char  *)&uiBuffer[0];
	ucpWriteBuffer	 = (unsigned char  *)pBuffer;

	SNOR_MIO_DEBUG("lba_addr: %d, nSector: %d, buffer: 0x%08X, uiBuffer: 0x%08X\n", lba_addr, nSector, (unsigned int)pBuffer, &uiBuffer[0]);

	end_lba_addr 			= (lba_addr + nSector - 1);
	start_snor_sec_addr 	= (lba_addr >> 3);
	erase_snor_sec_count 	= ((end_lba_addr >> 3) - start_snor_sec_addr + 1);

	SNOR_MIO_DEBUG("Update SNOR Sector (4kbyte): %d  (%d ~ %d)\n",
			erase_snor_sec_count, start_snor_sec_addr, (start_snor_sec_addr + erase_snor_sec_count - 1));

	for (i = 0; i < erase_snor_sec_count; ++i)
	{
		ucpBuffer = (unsigned char	*)uiBuffer;
		partial_sec_count = 8;
		if ( i == 0) {
			start_lba_addr = lba_addr;
		} else {
			start_lba_addr = ((start_snor_sec_addr + i) << 3);
		}

		head_merge_sec_count = (start_lba_addr % 8);
		loop_lba_end = (((start_snor_sec_addr + i + 1) << 3) - 1);

		if ( end_lba_addr >= loop_lba_end) {
			tail_merge_sec_count = 0;
		} else {
			tail_merge_sec_count = loop_lba_end - end_lba_addr;
		}

		SNOR_MIO_DEBUG("------------------------------------------\n");
		SNOR_MIO_DEBUG("Data merge\n");
		SNOR_MIO_DEBUG("------------------------------------------\n");
		if (head_merge_sec_count != 0) {
			uiLba_Addr 		= ((start_snor_sec_addr + i) << 3);
			SNOR_MIO_DEBUG("Head: %d sector (lba: %d ~ %d)\n",	head_merge_sec_count, uiLba_Addr, (uiLba_Addr + head_merge_sec_count - 1));
			SNOR_MIO_ReadSector(uiLba_Addr, head_merge_sec_count, ucpBuffer);
			partial_sec_count -= head_merge_sec_count;
			ucpBuffer += (head_merge_sec_count << 9);
		} else {
			SNOR_MIO_DEBUG("Head: [NOP]\n");
		}

		if (tail_merge_sec_count != 0) {

			if (tail_merge_sec_count != partial_sec_count) {
				SNOR_MIO_DEBUG("New data: %d sector\n", (partial_sec_count - tail_merge_sec_count));
				memcpy(ucpBuffer, ucpWriteBuffer, ((partial_sec_count - tail_merge_sec_count) << 9));
				ucpBuffer += ((partial_sec_count - tail_merge_sec_count) << 9);
				ucpWriteBuffer += ((partial_sec_count - tail_merge_sec_count) << 9);
				partial_sec_count -= (partial_sec_count - tail_merge_sec_count);
			}

			uiLba_Addr 		= (loop_lba_end - tail_merge_sec_count + 1);
			SNOR_MIO_DEBUG("Tail: %d sector (lba: %d ~ %d)\n",tail_merge_sec_count,  uiLba_Addr, loop_lba_end);
			SNOR_MIO_ReadSector(uiLba_Addr, tail_merge_sec_count, ucpBuffer);
			partial_sec_count -= tail_merge_sec_count;
		} else {

			if (partial_sec_count != 0) {
				SNOR_MIO_DEBUG("New data: %d sector\n", partial_sec_count);
				memcpy(ucpBuffer, ucpWriteBuffer, (partial_sec_count << 9));
				ucpBuffer += (partial_sec_count << 9);
				ucpWriteBuffer += (partial_sec_count << 9);
				partial_sec_count -= partial_sec_count;
			}

			SNOR_MIO_DEBUG("Tail: [NOP]\n");
		}

		if( (tail_merge_sec_count == 0) && (head_merge_sec_count == 0))
		{
			SNOR_MIO_DEBUG("Check for update needs\n");

			SNOR_MIO_ReadSector(start_lba_addr, 8, ucpCompBuffer);
			if (memcmp(ucpCompBuffer, uiBuffer, SNOR_SECTOR_SIZE) != 0) {

				SNOR_MIO_DEBUG("------------------------------------------\n");
				SNOR_MIO_DEBUG("Erase & Write Sector (4kbyte) lba_addr: %d\n", (start_lba_addr >> 3));
				SNOR_MIO_DEBUG("------------------------------------------\n");

				SNOR_MIO_SectorErase(((start_lba_addr >> 3) << 12));
				SNOR_MIO_WriteByte(((start_lba_addr >> 3) << 12), (unsigned char*)uiBuffer, SNOR_SECTOR_SIZE);
			} else {
				SNOR_MIO_DEBUG("Do not update\n");
			}
		} else {
			SNOR_MIO_DEBUG("------------------------------------------\n");
			SNOR_MIO_DEBUG("Erase & Write Sector (4kbyte) lba_addr: %d\n", (start_lba_addr >> 3));
			SNOR_MIO_DEBUG("------------------------------------------\n");

			SNOR_MIO_SectorErase(((start_lba_addr >> 3) << 12));
			SNOR_MIO_WriteByte(((start_lba_addr >> 3) << 12), (unsigned char*)uiBuffer, SNOR_SECTOR_SIZE);
		}
	}

	return 0;
}
#endif

static void SNOR_MIO_Read_AHB(unsigned int address, unsigned char *pBuffer, unsigned int length)
{
#if 0 //Not supported yet
	unsigned int i;
	SNOR_MIO_TRACE();
	//SNOR_MIO_DEBUG("Read address: 0x%08X, buffer: 0x%08X, length: %d\n", address, (unsigned int)pBuffer, length);

#ifdef SNOR_MIO_GDMA
	HwGDMA0->uSADDR0 	= (unsigned int)(NOR_FLASH_BASE_ADDR + address) ;
	HwGDMA0->uDADDR0	= (unsigned int)pBuffer;
	HwGDMA0->uSPARAM0.nSPARAM	= 4;
	HwGDMA0->uDPARAM0.nDPARAM 	= 4;
	HwGDMA0->uHCOUNT0   = (length/32) ;
	HwGDMA0->uCHCTRL0.nCHCTRL =
		((0x1)<<13)	| 	// SYNC
		((0x1)<<12) | 	// HRD
		((0x2)<<8) 	|  	// TYPE	- SW Transfer
		((0x3)<<6) 	|  	// BSIZE - 1/2/4/8 Burst
		((0x2)<<4) 	|  	// WSIZE - byte/half/WORD
		((0x1)<<3) 	|  	// FLAG
		((0x1)<<0) 	|  	// EN
		(0);

	while (!HwGDMA0->uCHCTRL0.bCHCTRL.FLG);
#else
	memcpy((void*)pBuffer, (void *)(NOR_FLASH_BASE_ADDR + address), length);
#endif /* 0 */
#endif
}

static void SNOR_MIO_ReadByte_fast(unsigned int address, unsigned char *pBuffer, unsigned int lengthInByte)
{
	SNOR_MIO_TRACE();
	SNOR_MIO_DEBUG("address: 0x%08X, buffer: 0x%08X, length: %d\n", address, (unsigned int)pBuffer, lengthInByte);

	SET_CMD_AUTO_ADDR(snor_mio_drv.read_fast.offset);

	SET_CMD_RUN(SFMC_REG_RUN_AUTO_RUN);

#ifdef SNOR_MIO_GDMA
	arch_invalidate_cache_range((addr_t)pBuffer, lengthInByte);
#endif

#ifdef SNOR_MIO_GDMA
	while(lengthInByte)
	{
		unsigned int nCountInPage;
		nCountInPage = 256 - (address&0xFF);
		if (nCountInPage>lengthInByte)
			nCountInPage = lengthInByte;

		SNOR_MIO_Read_AHB(address, pBuffer, nCountInPage);

		pBuffer += nCountInPage;
		address += nCountInPage;
		lengthInByte -= nCountInPage;
	}

#else
	memcpy((void*)pBuffer, (void *)(NOR_FLASH_BASE_ADDR + address), lengthInByte);
#endif
	SET_CMD_RUN(SFMC_REG_RUN_AUTO_STOP);
}


static void SNOR_MIO_ReadByte(unsigned int address, unsigned char *pBuffer, unsigned int lengthInByte)
{
	SNOR_MIO_TRACE();
	//	SNOR_MIO_DEBUG("[%s]address: 0x%08X, buffer: 0x%08X, length: %d\n", __func__, address, (unsigned int)pBuffer, lengthInByte);

	SET_CMD_AUTO_ADDR(snor_mio_drv.read.offset);

	SET_CMD_RUN(SFMC_REG_RUN_AUTO_RUN);

#ifdef SNOR_MIO_GDMA
	arch_invalidate_cache_range((addr_t)pBuffer, lengthInByte);
#endif

#ifdef SNOR_MIO_GDMA
	while(lengthInByte)
	{
		unsigned int nCountInPage;
		nCountInPage = 256 - (address&0xFF);
		if (nCountInPage>lengthInByte)
			nCountInPage = lengthInByte;

		SNOR_MIO_Read_AHB(address, pBuffer, nCountInPage);

		pBuffer += nCountInPage;
		address += nCountInPage;
		lengthInByte -= nCountInPage;
	}

#else
	memcpy((void*)pBuffer, (void *)(NOR_FLASH_BASE_ADDR + address), lengthInByte);
#endif
	SET_CMD_RUN(SFMC_REG_RUN_AUTO_STOP);
}

int SNOR_MIO_Read_Fast(unsigned int address, void *pBuffer, unsigned int length)
{
	SNOR_MIO_TRACE();

	SNOR_MIO_SetPort();

	SNOR_MIO_ReadByte_fast(address, (unsigned char*)pBuffer, length);

	SNOR_MIO_ReleasePort();
	return 0;
}

int SNOR_MIO_Read(unsigned int address, void *pBuffer, unsigned int length)
{
	SNOR_MIO_TRACE();

	SNOR_MIO_SetPort();

	SNOR_MIO_ReadByte(address, (unsigned char*)pBuffer, length);

	SNOR_MIO_ReleasePort();

	return 0;
}

int SNOR_MIO_Start_AutoRead(void)
{
	SNOR_MIO_SetPort();

	SET_CMD_AUTO_ADDR(snor_mio_drv.read.offset);
	SET_CMD_RUN(SFMC_REG_RUN_AUTO_RUN);

	SNOR_MIO_ReleasePort();

	return 0;
}

int SNOR_MIO_Stop_AutoRead(void)
{
	SNOR_MIO_SetPort();

	SET_CMD_RUN(SFMC_REG_RUN_AUTO_STOP);

	SNOR_MIO_ReleasePort();

	return 0;
}

#if 0
int SNOR_MIO_ReadSector(unsigned long ulLBA_addr, unsigned long ulSector, void *buff)
{
	unsigned int address = ulLBA_addr<<9;
	unsigned int length = ulSector<<9;
	SNOR_MIO_DEBUG("[read sector] lba: %d, sector: %d\n", ulLBA_addr, ulSector );

	SNOR_MIO_Read(address, buff, length);
	return 0;
}
#endif

unsigned int SNOR_MIO_FWDN_DevInfo(char *info)
{
	unsigned int offset = 0;

	offset += sprintf(info + offset, "#### SNOR Info ####\n");
	offset += sprintf(info + offset, "Manufacture ID: 0x%x\n", snor_mio_drv.ManufID);
	offset += sprintf(info + offset, "Device ID: 0x%x\n", snor_mio_drv.DevID);
	offset += sprintf(info + offset, "Name: %s\n", snor_mio_drv.name);
	offset += sprintf(info + offset, "Sector Size: %u KiB (%u Byte)\n",
			(snor_mio_drv.erase_size >> 10), snor_mio_drv.erase_size);
	offset += sprintf(info + offset, "Total Capacity: %u MiB (%u Byte)\n",
			(snor_mio_drv.size >> 20), snor_mio_drv.size);
	offset += sprintf(info + offset, "4Byte Address Mode: %s\n",
			(snor_mio_drv.flags & ADDR_4B)? "Supported": "Unsupported");

	return offset;
}

int SNOR_MIO_FWDN_LowFormat(void)
{
	int res;

    res = SNOR_MIO_ChipErase();

	return res;
}

int SNOR_MIO_FWDN_Read(unsigned int address, unsigned int length, void *buff)
{
	if (snor_mio_drv.size < (address + length)) {
		SNOR_MIO_DEBUG("[%s]Exceed Size\n", __func__);
	}

	SNOR_MIO_Read(address, buff, length);

	return 0;
}

int SNOR_MIO_FWDN_Write(unsigned int address, unsigned int length, void *buf)
{

	unsigned char *buffer;
	unsigned char *data;
	unsigned int i, size;

	unsigned int total_sec_cnt;

	SNOR_MIO_DEBUG("%s[%d]: address=0x%X, length=0x%X, buf=0x%p\n", __func__, __LINE__, address, length, buf);
	if (snor_mio_drv.size < (address + length)) {
		SNOR_MIO_DEBUG("[%s]Exceed Size\n", __func__);
		return -1;
	}

	data = (unsigned char  *)buf;
	buffer = (unsigned char  *)snor_mio_drv.uiDataBuffer;



	if (address % SNOR_SECTOR_SIZE) {
		/* Sector Read */
		SNOR_MIO_Read((address & ~(0xFFF)), buffer, SNOR_SECTOR_SIZE);
		i = (address & 0xFFF);
		if (length > (SNOR_SECTOR_SIZE - i)) {
			size = (length - (SNOR_SECTOR_SIZE - i));
		}
		else {
			size = length;
		}

		SNOR_MIO_DEBUG("Erase & Write less than 4KB of data, address: 0x%X\n", address);
		if (memcmp(&buffer[i], data, size)) {
			/* Data Merge */
			memcpy(&buffer[i], data, size);
			SNOR_MIO_SectorErase((address & ~(0xFFF)));
			SNOR_MIO_WriteByte((address & ~(0xFFF)), buffer, SNOR_SECTOR_SIZE);
		}

		address += size;
		data += size;
		length -= size;
	}

	/* Write data in 4KBytes */
	total_sec_cnt = (length / SNOR_SECTOR_SIZE);
	SNOR_MIO_DEBUG("Erase & Write data in 4KBytes, address: 0x%X, total_sec_cnt=%d\n", address, total_sec_cnt);
	for (i = 0; i < total_sec_cnt; i++) {
		SNOR_MIO_Read(address, buffer, SNOR_SECTOR_SIZE);

		if (memcmp(buffer, data, SNOR_SECTOR_SIZE)) {
			SNOR_MIO_SectorErase(address);
			SNOR_MIO_WriteByte(address, data, SNOR_SECTOR_SIZE);
		}

		address += SNOR_SECTOR_SIZE;
		data += SNOR_SECTOR_SIZE;
		length -= SNOR_SECTOR_SIZE;
	}

	/* Remaining data */
	if (length > 0) {
		SNOR_MIO_DEBUG("Erase & Write remaining data, address: 0x%X, length=%d\n", address, length);
		SNOR_MIO_Read(address, buffer, SNOR_SECTOR_SIZE);

		if (memcmp(buffer, data, length)) {
			memcpy(buffer, data, length);
			SNOR_MIO_SectorErase(address);
			SNOR_MIO_WriteByte(address, buffer, SNOR_SECTOR_SIZE);
		}
	}

	return 0;
}


void SNOR_MIO_RST_TEST(void)
{
	unsigned int warm_boot;
	unsigned int otp_rst_rcvl;
	unsigned char MID;
	unsigned short DID;
	unsigned int	i, j;
	unsigned char	code[512];
	unsigned char 	nOriginDataBuf[512];
	unsigned char 	nTempBuf[512];
	unsigned int	test_case = 1;
    unsigned short 	current_io_mode_backup;
	unsigned char	data_status;
	printf("\n\x1b[1;33m[%s]\x1b[0m\n", __func__);

	// code table backup
	memcpy(&code[0], (const void *)SFMC_REG_CODE_TABLE, 512);
	SNOR_MIO_ReadID(&MID,&DID);
	printf("SNOR MID: 0x%x, DID: 0x%x\n", MID, DID);

	//===================================
	// Test Case Run
	//===================================
	test_case = 13;
	SNOR_MIO_Read(0, &nOriginDataBuf, 256);
	SET_CMD_RUN(SFMC_REG_RUN_AUTO_STOP|SFMC_REG_RUN_MAN_STOP);

	for ( j = 0; j < test_case; ++j) {

		if ( j == 0 ) {
			printf("\x1b[1;33m (%d) SPI Read\x1b[0m\n",j);
			SNOR_MIO_Read(0, &nTempBuf, 256);

		} else if ( j == 1 ) {
			printf("\x1b[1;33m (%d) SPI Erase\x1b[0m\n",j);
			SNOR_MIO_Erase(0, 256);
		} else if ( j == 2 ) {
			printf("\x1b[1;33m (%d) SPI Write\x1b[0m\n",j);
			SNOR_MIO_Write(0,&nTempBuf, 256);

		} else if ( j == 3 ) {
			printf("\x1b[1;33m (%d) Write Enable\x1b[0m\n",j);
			SNOR_MIO_WriteEnable();

		} else if ( j == 4 ) {
			printf("\x1b[1;33m (%d) Write Disable\x1b[0m\n",j);
			SNOR_MIO_WriteDisable();

		} else if ( j == 5 ) {
			printf("\x1b[1;33m (%d) Read Status\x1b[0m\n",j);
			SNOR_MIO_ReadStatus();

		} else if ( j == 6 ) {
			printf("\x1b[1;33m (%d) SPI Read CMD\x1b[0m\n",j);
			// 0: cmd
			SET_CODE_TABLE((snor_mio_drv.read.offset + 1), 0xF4000000);
			SET_CMD_MANU_ADDR(snor_mio_drv.read.offset);
			SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
			WAIT_CMD_COMPLETE();

		} else if ( j == 7 ) {
			printf("\x1b[1;33m (%d) SPI Read CMD-ADDR\x1b[0m\n",j);
			// 0: cmd
			// 1: addr
			SET_CODE_TABLE((snor_mio_drv.read.offset + 2), 0xF4000000);
			SET_CMD_MANU_ADDR(snor_mio_drv.read.offset);
			SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
			WAIT_CMD_COMPLETE();

		} else if ( j == 8 ) {
			printf("\x1b[1;33m (%d) Enable QPI mode \x1b[0m(%d)\n", j, snor_mio_drv.current_io_mode);
			//SNOR_MIO_Enable_Multi_IO();
			printf("io num: %d\n", snor_mio_drv.current_io_mode);

		} else if ( j == 9 ) {
			printf("\x1b[1;33m (%d) Disable QPI mode \x1b[0m\n",j);
			//SNOR_MIO_Disable_Multi_IO();

		} else if ( j == 10 ) {
			printf("\x1b[1;33m (%d) QPI Read fast\x1b[0m\n",j);
			SNOR_MIO_Read_Fast(0, &nTempBuf, 256);

		} else if ( j == 11 ) {
			printf("\x1b[1;33m (%d) SPI Write CMD\x1b[0m\n",j);
			SNOR_MIO_WriteEnable();
			// 0: cmd
			SET_CODE_TABLE((snor_mio_drv.write.offset + 1), 0xF4000000);
			SET_CMD_MANU_ADDR(snor_mio_drv.write.offset);
			SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
			WAIT_CMD_COMPLETE();

		} else if ( j == 12 ) {
			printf("\x1b[1;33m (%d) SPI Write CMD-ADDR\x1b[0m\n",j);
			SNOR_MIO_WriteEnable();
			// 0: cmd
			SET_CODE_TABLE((snor_mio_drv.write.offset + 2), 0xF4000000);
			SET_CMD_MANU_ADDR(snor_mio_drv.write.offset);
			SET_CMD_RUN(SFMC_REG_RUN_MAN_RUN);
			WAIT_CMD_COMPLETE();

		}

		SET_CMD_RUN(SFMC_REG_RUN_AUTO_STOP|SFMC_REG_RUN_MAN_STOP);

		// code table restore
		memcpy((void*)SFMC_REG_CODE_TABLE, &code[0], 512);
#if 0		/* 016.12.09 */
		SNOR_MIO_WriteEnable();		// Need for After Read CMD
		SNOR_MIO_ReadID(&MID,&DID);
		if ((snor_mio_drv.ManufID == MID) && (snor_mio_drv.DevID == DID)) {
			printf("\x1b[1;36mSNOR Status OK!!!\x1b[0m\n");
		} else {
			printf("SNOR MID: 0x%x, DID: 0x%x\n", MID, DID);
			printf("\x1b[1;31mNeed SNOR Reset Recovery!!\x1b[0m\n");
		}
#endif /* 0 */

		current_io_mode_backup = snor_mio_drv.current_io_mode;
		snor_mio_drv.current_io_mode = IO_NUM_SINGLE;
		SNOR_MIO_Read(0, &nTempBuf, 256);
		SET_CMD_RUN(SFMC_REG_RUN_AUTO_STOP|SFMC_REG_RUN_MAN_STOP);
		snor_mio_drv.current_io_mode = current_io_mode_backup;
		data_status = 0;
		for ( i = 0; i < (256); ++i )
		{
			if ( nOriginDataBuf[i] != nTempBuf[i]) {
				if ( data_status==0)
					printf("\x1b[1;31mNeed Reset Recovery!!\x1b[0m\n");
			//	printf("\torigin data[%d]: 0x%02X != read data[%d]: 0x%02X\n", i, nOriginDataBuf[i], i, nTempBuf[i] );

				data_status = 1;
			}
		}

		if (data_status==0)
			printf("\x1b[1;37mRead Success!\x1b[0m\n");

		//===================================
		// setting Reset parameter
		//===================================
		otp_rst_rcvl = ( ( 0xff & 0xFF)			// Wait Command Iteration
						|((0x49 << 8) & 0xFF00)	// Wait Manual Run Interation
						|(Hw28)					// SPI S/W Reset
						|(Hw29) 				// QPI S/W Reset
						|(Hw30) 				// OPI STR S/W Reset
						|(Hw31) 				// OPI DTR S/W Reset
						| 0 );

		warm_boot = TRUE;
//		warm_boot = FALSE;

		printf("+Reset Recovery\n");
		sfmc_test_RST_RC_TIME( warm_boot, otp_rst_rcvl);
		printf("-Reset Recovery\n");


		// code table restore
		memcpy((void*)SFMC_REG_CODE_TABLE, &code[0], 512);

#if 0		/* 016.12.09 */
		SNOR_MIO_WriteEnable();		// Need for After Read CMD

		SNOR_MIO_ReadID(&MID,&DID);

		if ((snor_mio_drv.ManufID == MID) && (snor_mio_drv.DevID == DID)) {
			printf("\x1b[1;36mSNOR Reset Recovery Success!!!!\x1b[0m\n\n");
		} else {
			printf("SNOR MID: 0x%x, DID: 0x%x\n", MID, DID);
			printf("\x1b[1;31mSNOR Reset Recovery Fail!!!!\x1b[0m\n\n");
		}
#endif /* 0 */

		current_io_mode_backup = snor_mio_drv.current_io_mode;
		snor_mio_drv.current_io_mode = IO_NUM_SINGLE;
		SNOR_MIO_Read(0, &nTempBuf, 256);
		SET_CMD_RUN(SFMC_REG_RUN_AUTO_STOP|SFMC_REG_RUN_MAN_STOP);
		snor_mio_drv.current_io_mode = current_io_mode_backup;
		data_status = 0;
		for ( i = 0; i < (256); ++i )
		{
			if ( nOriginDataBuf[i] != nTempBuf[i]) {
				if ( data_status==0)
					printf("\x1b[1;31mSNOR Read Fail!!\x1b[0m\n");
			//	printf("\torigin data[%d]: 0x%02X != read data[%d]: 0x%02X\n", i, nOriginDataBuf[i], i, nTempBuf[i] );
				data_status = 1;
			}
		}

		if (data_status==0)
			printf("\x1b[1;36mSNOR Reset Recovery Success!!!!\x1b[0m\n\n");

	}

	printf("\x1b[1;36m-----------------------------------------------------\x1b[0m\n");

	while(1);
}

#define TEST_BUFFER 	0xF0000000
#define TEST_BUFFER2 	0xF1000000

#define TRAINING_TEST_BUFF_SIZE (64*1024)
#define READ_TEST_BUFF_SIZE 	(64*1024)

#if 1 //wang
static void SNOR_MIO_Window_Margin_TEST(unsigned int *pPreRead)
{
	int	clk_wd_buf, clk_rd_buf;
//	unsigned int	backup_clk_buf;
//	unsigned int 	d_time;
	unsigned int	match_count;
	unsigned int	nReg;
	unsigned int 	*pSNOR;

	printf("\nSNOR_MIO Windos Magin TEST...\n\n");

	pSNOR = (unsigned int*)(0x08200000);

	SET_CMD_AUTO_ADDR(snor_mio_drv.read_fast.offset);

	printf("---------------------------------------------\n");
	printf(" Current value\n");
	printf("---------------------------------------------\n");
	printf("REG_TIMING: \t0x%08X\n", *(volatile unsigned int *)(SFMC_REG_TIMING));
	printf("REG_DELAY_SO: \t0x%08X\n", *(volatile unsigned int *)(SFMC_REG_DELAY_SO));
//	printf("REG_DELAY_CLK: \t0x%08X\n", *(volatile unsigned int *)(SFMC_REG_DELAY_CLK));

//	backup_clk_buf = *(volatile unsigned int *)SFMC_REG_DELAY_CLK;

//	d_time = (unsigned int)current_time();

	for (clk_wd_buf = 0x3f; clk_wd_buf >= 0; clk_wd_buf--) {
		*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000030;
		*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) &= ~(0x0000003F);
		*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) |= SFMC_REG_DELAY_CLK_WD_BUF(clk_wd_buf);

		printf("\n");
		printf("\x1b[1;34m%02X \x1b[0m", clk_wd_buf);

		for (clk_rd_buf = 0; clk_rd_buf < (0x3f + 1); clk_rd_buf++) {
			*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000030;
			*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) &= ~(0x00003F00);
			*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) |= SFMC_REG_DELAY_CLK_RD_BUF(clk_rd_buf);
			*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000010;

			for (nReg=0;nReg<0x100;nReg++); //delay

			match_count = 40;
			while (match_count != 0) {
				if (memcmp(pPreRead, pSNOR, TRAINING_TEST_BUFF_SIZE) != 0) {
					// error
					printf("\x1b[0;31m X \x1b[0m");
					break;
				}
				else {
					// match
					match_count--;
				}
			}
			if (match_count == 0) {
				printf("\x1b[0;32m O \x1b[0m");
			}
		}
	}

	*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000030;

	printf("\n   ");
	for (clk_rd_buf = 0; clk_rd_buf < (0x3f + 1); clk_rd_buf++)
		printf("\x1b[1;33m%02X \x1b[0m", clk_rd_buf);
	printf("\n\x1b[1;33mX-Axis: CLK_RD\x1b[0m,");
	printf(" \x1b[1;34mY-Axis: CLK_WD\x1b[0m\n");

	return;
}
#endif

void SNOR_MIO_IO_READ_SPEED_TEST(unsigned int  *pFastR_Buffer)
{
	unsigned int	i;
	unsigned int  	d_time;
	unsigned int  	speed;

	printf("\n");
	printf("---------------------------------------------\n");
	printf("Read Speed Test (Data Size: %d MByte) \n", (READ_TEST_BUFF_SIZE/1024/1024));
	printf("---------------------------------------------\n");

	speed = 0;
	for ( i = 0; i < 10; ++i) {
		d_time = (unsigned int)current_time();
#if 0
		SNOR_MIO_ReadByte_fast(0x00000000, (unsigned char*)pFastR_Buffer, READ_TEST_BUFF_SIZE);
#else
		SNOR_MIO_ReadByte(0x00000000, (unsigned char*)pFastR_Buffer, READ_TEST_BUFF_SIZE);
#endif
		d_time = ((unsigned int)current_time() - d_time);
		printf("%d Mbyte / %u ms - Speed: %u KB/s\n",(READ_TEST_BUFF_SIZE/1024/1024), d_time, (READ_TEST_BUFF_SIZE/1024 * 1000)/d_time);
		speed += ((READ_TEST_BUFF_SIZE/1024/1024 * 10000)/d_time);
	}

	printf("average speed: \x1b[1;31m%u.%u MB/s\x1b[0m\n", (speed / 100), ((speed - ((speed / 100)*100)) / 10));

}

void SNOR_MIO_IO_READ_TEST(unsigned int *pRBuffer, unsigned int  *pFastR_Buffer)
{
	unsigned int	i, j, err_count;
	unsigned char c = 0;
	unsigned char data_dump_print;

	unsigned int	Test_count, Test_count2, Test_count3;
	printf("pRBuffer: 0x%08X, pFastR_Buffer: 0x%08X\n", pRBuffer, pFastR_Buffer);

	Test_count 	= 0;
	Test_count2 = 1;
	Test_count3 = 1;
	printf("---------------------------------------------\n");
	printf("Stress Test Size: %d MByte\n", (READ_TEST_BUFF_SIZE/1024/1024));
	printf("---------------------------------------------\n");
	printf("Test Count: %0d x %0d x %0d",Test_count3, Test_count2, Test_count);

retest:
	c = 0;
	SNOR_MIO_ReadByte_fast(0x00000000, (unsigned char*)pFastR_Buffer, READ_TEST_BUFF_SIZE);

	if (memcmp(pRBuffer, pFastR_Buffer, READ_TEST_BUFF_SIZE) != 0) {
		printf("\nRead Data Error\n");

		err_count = 0;
		for (i =0; i < (READ_TEST_BUFF_SIZE>>2); ++i) {
			if ( (pRBuffer[i] != pFastR_Buffer[i])) {
				++err_count;
				printf("Origin[0x%08X] != Read[0x%08X]\n", pRBuffer[i], pFastR_Buffer[i]);
			}
		}
		printf("Error Num: \x1b[1;31m%d bytes\x1b[0m / %d bytes\n",
				(err_count << 2), (READ_TEST_BUFF_SIZE));

#if 0		/* 016.12.21 */
		printf("data print? (y/n) : ");

		while(1) {
			getc((char *)&c);
			if (c == 'y') {
				data_dump_print = 1;
				break;
			}
			else if ( c == 'n') {
				data_dump_print = 0;
				break;
			}
		}
		printf("%c\n",c );
		c = 0;
#else
	data_dump_print = 0;
#endif /* 0 */

		if ( data_dump_print == 1) {
			for (i =0; i < (READ_TEST_BUFF_SIZE>>4); ++i) {
				j = (i <<2);
				if ((pRBuffer[j+0] != pFastR_Buffer[j+0]) ||
					(pRBuffer[j+1] != pFastR_Buffer[j+1]) ||
					(pRBuffer[j+2] != pFastR_Buffer[j+2]) ||
					(pRBuffer[j+3] != pFastR_Buffer[j+3])) {
					printf("[0x%08X] | %08X %08X %08X %08X |\x1b[1;31m %08X %08X %08X %08X\x1b[0m\n",
							j<<2, 	pRBuffer[j+0], pRBuffer[j+1], pRBuffer[j+2], pRBuffer[j+3],
								pFastR_Buffer[j+0], pFastR_Buffer[j+1], pFastR_Buffer[j+2], pFastR_Buffer[j+3] );
				} else {
					printf("[0x%08X] | %08X %08X %08X %08X | %08X %08X %08X %08X\n",
							j<<2, 	pRBuffer[j+0], pRBuffer[j+1], pRBuffer[j+2], pRBuffer[j+3],
								pFastR_Buffer[j+0], pFastR_Buffer[j+1], pFastR_Buffer[j+2], pFastR_Buffer[j+3] );
				}

				getc((char *)&c);
				if ( c == 's')
					break;
			}

			printf("Error Num: \x1b[1;31m%d bytes\x1b[0m / %d bytes\n",
					(err_count << 2), (READ_TEST_BUFF_SIZE));
		}
		return;

	} else {

		if (Test_count == 0xFFFFFFFF) {
			Test_count = 0;
			if (Test_count2 == 0xFFFFFFFF) {
				if (Test_count3 == 0xFFFFFFFF) {
					printf("\n");
					Test_count3 = 0;
				}
				++Test_count3;
				Test_count2 = 1;
			}
			++Test_count2;
		}
		++Test_count;

		printf("\r");
		printf("Test Count: %0d x %0d x %0d",Test_count3, Test_count2, Test_count);

		goto retest;
	}

	printf("select~!!\n 1 :re-test\n 2 :exit\n");
	printf("  : ");

	while(1) {
		getc((char *)&c);
		if (c == '1') {
			printf("%c\n",c );
			goto retest;
		} else if (c == '2') {
			printf("%c\n",c );
			break;
		}
	}

	while(1);
}


void SNOR_MIO_Progress_print(unsigned char *in_count)
{
	unsigned char count;
	count = *in_count;
#if 0
	printf("#");
	if (count == 20) {
		count = 0;
		printf("\r");
	}

	++count;
	*in_count = count;
#else
		printf("\r");
		if (count == 8)
			count = 0;

		switch (count) {
			case 0:
				printf("|");
				break;
			case 1:
				printf("/");
				break;
			case 2:
				printf("-");
				break;
			case 3:
				printf("\\");
				break;
			case 4:
				printf("|");
				break;
			case 5:
				printf("/");
				break;
			case 6:
				printf("-");
				break;
			case 7:
				printf("\\");
				break;
		}

		++count;
		*in_count = count;
#endif /* 0 */

}

static unsigned int SNOR_MIO_Window_Margin_count(unsigned int *pPreRead)
{
	int	clk_wd_buf, clk_rd_buf;
//	unsigned int	backup_clk_buf;
//	unsigned int 	d_time;
	unsigned int	match_count;
	unsigned int	nReg;
	unsigned int 	*pSNOR;
	unsigned int	total = 0;
	unsigned char	print_c = 0;

	pSNOR = (unsigned int*)(0x08200000);
	SET_CMD_AUTO_ADDR(snor_mio_drv.read_fast.offset);

	for (clk_wd_buf = 0x3f; clk_wd_buf >= 0; clk_wd_buf--) {
		*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000030;
		*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) &= ~(0x0000003F);
		*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) |= SFMC_REG_DELAY_CLK_WD_BUF(clk_wd_buf);

		SNOR_MIO_Progress_print(&print_c);
		for (clk_rd_buf = 0; clk_rd_buf < (0x3f + 1); clk_rd_buf++) {
			*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000030;
			*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) &= ~(0x00003F00);
			*(volatile unsigned int *)(SFMC_REG_DELAY_CLK) |= SFMC_REG_DELAY_CLK_RD_BUF(clk_rd_buf);
			for (nReg=0;nReg<0x100;nReg++); //delay
			*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000010;

			for (nReg=0;nReg<0x100;nReg++); //delay

			match_count = 5;
			while (match_count != 0) {
				if (memcmp(pPreRead, pSNOR, 1024) != 0) {
					break;
				}
				else {
					// match
					match_count--;
				}
			}
			if (match_count == 0)
				total++;
		}
	}
	*(volatile unsigned int *)(SFMC_REG_RUN)		= 0x00000030;

	return total;
}

static int SNOR_MIO_IO_Clock_Training(void)
{
	unsigned int	read_latency;
	unsigned int	sldh;
	unsigned int	sel_pn;
	unsigned int	sel_dqs, sel_dqs_param;
	unsigned char 	sldh_value;
//	unsigned int 	d_time;
	unsigned int	backup_reg_timing;
	unsigned int	backup_reg_delay_so;
//	unsigned int	backup_reg_delay_clk;
//	unsigned int	backup_clk_buf_max;
	unsigned int	new_count = 0, success_count = 0;
	unsigned int 	*pPreRead = NULL;
	char	input_c = 0;
	unsigned int	set_clk = 80000000;

	pPreRead = malloc(TRAINING_TEST_BUFF_SIZE);//(unsigned int* )(0xF0000000); //Internal SRAM(256KB) for A53
	SNOR_MIO_Read(0x00200000, pPreRead, TRAINING_TEST_BUFF_SIZE);

	printf("Training Start\n");
//	d_time = (unsigned int)current_time();

	printf("Select SNOR clock\n");
	printf("1 : 100Mhz\n");
	printf("2 : 80Mhz\n");
	printf("3 : 66.6Mhz\n");
	printf("4 : 50Mhz\n");
	printf("  : ");
	while (1) {
		dgetc(&input_c, 1);
		if (input_c == '1')
			set_clk = 100000000;
		else if (input_c == '2')
			set_clk = 80000000;
		else if (input_c == '3')
			set_clk = 66666666;
		else if (input_c == '4')
			set_clk = 50000000;
		if ((input_c >= '1') && (input_c <= '4')) {
			printf("%c\n", input_c);
			break;
		}
	}
	printf("\nSet SNOR clock: %dMhz\n", set_clk / 1000000);
	tcc_set_peri(PERI_MICOM_SFMC, ENABLE, set_clk);

	sel_pn = 0;
	read_latency = 0;
	sldh = 0;
	sel_dqs = 0;
	backup_reg_timing = 0;
	backup_reg_delay_so = 0;
//	backup_reg_delay_clk = 0;

	for( sldh = 0; sldh < SFMC_SLDH_NUM; ++sldh)
		for( read_latency = 0; read_latency < SFMC_READ_LATENCY_NUM; ++read_latency)
			for( sel_dqs = 0; sel_dqs < SFMC_SEL_DQS_NUM; ++sel_dqs)
				for( sel_pn = 0; sel_pn < SFMC_SEL_PN_NUM; ++sel_pn) {


		sel_dqs_param = sel_dqs + 1;
		if (sel_dqs_param == 4)
			sel_dqs_param = 0;

		//--------------------------------------------
		// set parameter
		//--------------------------------------------
		*(volatile unsigned int *)(SFMC_REG_TIMING) =	SFMC_REG_TIMING_SC_EXTND(1) |	// Fixed value
														SFMC_REG_TIMING_CS_TO_CS(0x4) |	// Fixed value
														SFMC_REG_TIMING_READ_LATENCY(read_latency) |
														SFMC_REG_TIMING_SEL_PN_DT(sel_pn) |
														SFMC_REG_TIMING_SEL_DQS(sel_dqs_param);
		if(sldh == 0)
			sldh_value = 0xFF;
		else
			sldh_value = 0;
		// Fixed Configuration value
		*(volatile unsigned int *)(SFMC_REG_DELAY_SO)  = SFMC_REG_DELAY_SO_INV_SCLK(1) |
														 SFMC_REG_DELAY_SO_SLCH(sldh)	|
														 SFMC_REG_DELAY_SO_SLDH(sldh_value);

		new_count = SNOR_MIO_Window_Margin_count(pPreRead);

		if (new_count > success_count) {
			success_count = new_count;
			backup_reg_timing = *(volatile unsigned int *)(SFMC_REG_TIMING);
			backup_reg_delay_so = *(volatile unsigned int *)(SFMC_REG_DELAY_SO);
			printf("\n---------------------------------------------\n");
			printf(" Window margin count: %d\n", new_count);
			printf("---------------------------------------------\n");
			printf("REG_TIMING: \t0x%08X\n", *(volatile unsigned int *)(SFMC_REG_TIMING));
			printf("REG_DELAY_SO: \t0x%08X\n", *(volatile unsigned int *)(SFMC_REG_DELAY_SO));

		}
	}

	if (success_count == 0) {
		SNOR_MIO_CT_DEBUG("training fail!!!!!\n");
		while(1);
	}
	else {
		printf("\n---------------------------------------------\n");
		printf(" Highest Window margin count: %d\n", success_count);
		printf("---------------------------------------------\n");
		printf("REG_TIMING: \t0x%08X\n", backup_reg_timing);
		printf("REG_DELAY_SO: \t0x%08X\n", backup_reg_delay_so);

		*(volatile unsigned int *)(SFMC_REG_TIMING) = backup_reg_timing;
		*(volatile unsigned int *)(SFMC_REG_DELAY_SO) = backup_reg_delay_so;
	}

	SNOR_MIO_Window_Margin_TEST(pPreRead);

//	d_time = (unsigned int)current_time();

	printf("Finish\n");

//	while(1)
//		arch_idle();

	return 0;
}

void SNOR_MIO_IO_TEST(void)
{
	unsigned int 	nSectorSize, nSectorCount;
	unsigned int 	nAddress, nAddress_mb;
	unsigned int 	*pWBuffer;
	unsigned int 	*pRBuffer;
	unsigned int	read_print_size;
	unsigned int	i, j, k;
	SNOR_MIO_TRACE();

	printf("----------------------------------------\n");
	printf("SNOR MIO IO Test Func start!!\n");
	printf("----------------------------------------\n");

	nSectorSize 	= snor_mio_drv.sector_size;
	nSectorCount	= 1;

	read_print_size = 64;

	printf("[Sector Size: 0x%08X, Count: 0x%08X]\n", nSectorSize, nSectorCount );

	pWBuffer = (unsigned int*)TEST_BUFFER;
	pRBuffer = (unsigned int*)TEST_BUFFER2;// + nSectorSize;

	for ( k = 0; k < snor_mio_drv.sector_count; ++k) {

		nAddress_mb	= k * 64 * 1024;

		printf("----------------------------------------\n");
		printf("Block Read \n");
		printf("----------------------------------------\n");
		nAddress = nAddress_mb;
		for ( i = 0; i < nSectorCount; ++i )
		{
			printf("Block Addr[0x%08X]\n", nAddress);
			SNOR_MIO_Read(nAddress, pRBuffer, nSectorSize);
			// data print
			if (read_print_size != 0)
			{
				printf("\x1b[1;33m[Read DATA] (nSectorSize: %d)", read_print_size);
				for ( j = 0; j < (read_print_size >> 2); ++j) {
					if (!(j % 4))
						printf("\n");

					printf("%08x ", pRBuffer[j]);
				}
				printf("\x1b[0m\n");
			}

			nAddress += nSectorSize;
		}

		printf("----------------------------------------\n");
		printf("Block Erase \n");
		printf("----------------------------------------\n");
		nAddress = nAddress_mb;
		for ( i = 0; i < nSectorCount; ++i )
		{
			printf("Block Addr[0x%08X]\n", nAddress);
			SNOR_MIO_BlockErase(nAddress);
			nAddress += nSectorSize;
		}


		printf("----------------------------------------\n");
		printf("Block Read \n");
		printf("----------------------------------------\n");
		nAddress = nAddress_mb;
		for ( i = 0; i < nSectorCount; ++i )
		{
			printf("Block Addr[0x%08X]\n", nAddress);
			SNOR_MIO_Read(nAddress, pRBuffer, nSectorSize);
			// data print
			if (read_print_size != 0)
			{
				printf("\x1b[1;33m[Read DATA] (nSectorSize: %d)", read_print_size);
				for ( j = 0; j < (read_print_size >> 2); ++j) {
					if (!(j % 4))
						printf("\n");

					printf("%08x ", pRBuffer[j]);
				}
				printf("\x1b[0m\n");
			}

			nAddress += nSectorSize;
		}

		printf("----------------------------------------\n");
		printf("Block Write \n");
		printf("----------------------------------------\n");
		nAddress = nAddress_mb;
		for ( i = 0; i < nSectorCount; ++i )
		{
			printf("[Test Data Init]\n");
			for ( j = 0; j < (nSectorSize>>2); ++j )
			{
				pWBuffer[j] = (((i & 0xFF) << 24) | j);
			}

			printf("Block Addr[0x%08X]\n", nAddress);
			SNOR_MIO_Write(nAddress, pWBuffer, nSectorSize);
			nAddress += nSectorSize;
		}


		printf("----------------------------------------\n");
		printf("Block Read & Compare\n");
		printf("----------------------------------------\n");
		nAddress = nAddress_mb;
		for ( i = 0; i < nSectorCount; ++i )
		{
			printf("Block Addr[0x%08X]\n", nAddress);
			SNOR_MIO_Read(nAddress, pRBuffer, nSectorSize);
			// data print
			if (read_print_size != 0)
			{
				printf("\x1b[1;33m[Read DATA] (nSectorSize: %d)", read_print_size);
				for ( j = 0; j < (read_print_size >> 2); ++j) {
					if (!(j % 4))
						printf("\n");

					printf("%08x ", pRBuffer[j]);
				}
				printf("\x1b[0m\n");
			}

			for ( j = 0; j < (32>>2); ++j )
			{
				pWBuffer[j] = (((i & 0xFF) << 24) | j);
				if ( pWBuffer[j] != pRBuffer[j]) {
					printf("pWBuffer[%d]: 0x%08X != pRBuffer[%d]: 0x%08X\n", j, pWBuffer[j], j, pRBuffer[j] );
				}
			}

			nAddress += nSectorSize;
		}
	}

	printf("----------------------------------------\n");
	printf("SNOR MIO IO Test finish!!\n");
	printf("----------------------------------------\n");
	while(1);
}

