LOCAL_DIR := $(GET_LOCAL_DIR)

INCLUDES += -I$(LOCAL_DIR)/include

DEFINES += SNOR_MIO
OBJS += \
    $(LOCAL_DIR)/snor_mio.o 

