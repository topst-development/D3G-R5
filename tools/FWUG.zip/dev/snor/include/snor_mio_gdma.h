/////////////////////////////////////////////////////////
//	GDMA
/////////////////////////////////////////////////////////

#ifndef _GDMA_H_

#define _GDMA_H_


#define HwIOBUS             0x16000000		// TCC8020
#define HwGDMA0              ((volatile GDMA         *)(HwIOBUS   + 0x020000))

#define GDMA0	0
#define GDMA1	1
#define GDMA2	2
#define GDMA3	3
#define GDMA4	4

#define DMACH0	0
#define DMACH1	1
#define DMACH2	2

//	Source Parameter
/////////////////////////////////////////////////////////
typedef	struct	{
	uint	SINC		: 8;
	uint	SMASK		:24;
} SPARAM;

typedef	union {
	uint		nSPARAM;
	SPARAM		bSPARAM;
} SPARAM_U;

//	Destination Parameter
/////////////////////////////////////////////////////////
typedef	struct	{
	uint	DINC		: 8;
	uint	DMASK		:24;
} DPARAM;

typedef	union {
	uint		nDPARAM;
	DPARAM		bDPARAM;
} DPARAM_U;

//	Channel Control
/////////////////////////////////////////////////////////
#define	DMA_8BIT	0
#define	DMA_16BIT	1
#define	DMA_32BIT	2

#define	DMA_1BST	0
#define	DMA_2BST	1
#define	DMA_4BST	2
#define	DMA_8BST	3

#define	DREQ_EDGE	0
#define	DREQ_HW		1
#define	DREQ_SW		2
#define	DREQ_LEVEL	3

#define	DMARD		0x0
#define	DMAWR		0x1

typedef	struct	{
	uint	CHEN		: 1;
	uint	REP			: 1;
	uint	IEN			: 1;
	uint	FLG			: 1;
	uint	WSIZE		: 2;
	uint	BSIZE		: 2;
	uint	TYPE		: 2;
	uint	ARB			: 1;
	uint	LOCK		: 1;
	uint	HRD			: 1;
	uint	SYN			: 1;
	uint	DTM			: 1;
	uint	CONT		: 1;
	uint				:16;
} CHCTRL;

typedef	union {
	uint		nCHCTRL;
	CHCTRL		bCHCTRL;
} CHCTRL_U;

//	Repeat Control
/////////////////////////////////////////////////////////
typedef	struct	{
	uint	RPTCNT		:24;
	uint				: 6;
	uint	EOT			: 1;
	uint	DRI			: 1;
} RPTCTRL;

typedef	union {
	uint		nRPTCTRL;
	RPTCTRL		bRPTCTRL;
} RPTCTRL_U;

//	Channel Configuration
/////////////////////////////////////////////////////////
typedef	struct	{
	uint	RPTCNT		:24;
	uint				: 6;
	uint	EOT			: 1;
	uint	DRI			: 1;
} CHCOFIG;

typedef	union {
	uint		nCHCOFIG;
	CHCOFIG		bCHCOFIG;
} CHCOFIG_U;

//	DMA Request Selection
/////////////////////////////////////////////////////////
#define DREQ_GPSB03_TX  0x00000001	// DREQ_GPSB0_TX, DREQ_GPSB3_TX
#define DREQ_GPSB14_TX  0x00000002	// DREQ_GPSB1_TX, DREQ_GPSB4_TX
#define DREQ_GPSB25_TX  0x00000004	// DREQ_GPSB2_TX, DREQ_GPSB5_TX
#define DREQ_TS0       	0x00000008
#define DREQ_GPSB03_RX  0x00000010	// DREQ_GPSB0_RX, DREQ_GPS03_RX
#define DREQ_GPSB14_RX  0x00000020	// DREQ_GPSB1_RX, DREQ_GPSB4_RX
#define DREQ_GPSB25_RX  0x00000040	// DREQ_GPSB2_RX, DREQ_GPSB5_RX
#define DREQ_TS1       	0x00000080
#define DREQ_UTTX26    	0x00000100	// DREQ_UTTX2, DREQ_UTTX6
#define DREQ_UTRX26    	0x00000200	// DREQ_UTRX2, DREQ_UTRX6
#define DREQ_UTTX37    	0x00000400	// DREQ_UTTX3, DREQ_UTTX7
#define DREQ_UTRX37    	0x00000800	// DREQ_UTRX3, DREQ_UTRX7
#define DREQ_SPTX1		0x00001000
#define DREQ_SPTX0		0x00002000
#define DREQ_DATX      	0x00004000
#define DREQ_DARX      	0x00008000
#define DREQ_MSTICK0	0x00010000
#define DREQ_MSTICK1	0x00020000
#define DREQ_NFC       	0x00040000
#define DREQ_I2CS01RX   0x00080000	// DREQ_I2CS0RX, DREQ_I2CS1RX
#define DREQ_MSPTX1		0x00100000
#define DREQ_MSPTX0		0x00200000
#define DREQ_MCDRX     	0x00400000
#define DREQ_MDATX     	0x00800000
#define DREQ_MDARX     	0x01000000
#define DREQ_I2CS01TX  	0x02000000	// DREQ_I2CS0TX, DREQ_I2CS1TX
#define DREQ_UTTX04    	0x04000000	// DREQ_UTTX0, DREQ_UTTX4
#define DREQ_UTRX04    	0x08000000	// DREQ_UTRX0, DREQ_UTRX4
#define DREQ_MSPRX     	0x10000000
#define DREQ_UTTX15    	0x20000000	// DREQ_UTTX1, DREQ_UTTX5
#define DREQ_UTRX15    	0x40000000	// DREQ_UTRX1, DREQ_UTRX5
#define DREQ_TS2       	0x80000000

//	GDMA0 Register
/////////////////////////////////////////////////////////

typedef	struct	_GDMA {
	uint		uSADDR0;			// 0x00
	SPARAM_U	uSPARAM0;			// 0x04
	uint		_undef0;			// 0x08
	uint		uCSADDR0;			// 0x0C
	uint		uDADDR0;			// 0x10
	DPARAM_U	uDPARAM0;			// 0x14
	uint		_undef1;			// 0x18
	uint		uCDADDR0;			// 0x1C
	uint		uHCOUNT0;			// 0x20
	CHCTRL_U	uCHCTRL0;			// 0x24
	RPTCTRL_U	uRPTCTRL0;			// 0x28
	uint		uDREQSEL0;			// 0x2C
	uint		uSADDR1;			// 0x30
	SPARAM_U	uSPARAM1;			// 0x34
	uint		_undef2;			// 0x38
	uint		uCSADDR1;			// 0x3C
	uint		uDADDR1;			// 0x40
	DPARAM_U	uDPARAM1;			// 0x44
	uint		_undef3;			// 0x48
	uint		uCDADDR1;			// 0x4C
	uint		uHCOUNT1;			// 0x50
	CHCTRL_U	uCHCTRL1;			// 0x54
	RPTCTRL_U	uRPTCTRL1;			// 0x58
	uint		uDREQSEL1;			// 0x5C
	uint		uSADDR2;			// 0x60
	SPARAM_U	uSPARAM2;			// 0x64
	uint		_undef4;			// 0x68
	uint		uCSADDR2;			// 0x6C
	uint		uDADDR2;			// 0x70
	DPARAM_U	uDPARAM2;			// 0x74
	uint		_undef5;			// 0x78
	uint		uCDADDR2;			// 0x7C
	uint		uHCOUNT2;			// 0x80
	CHCTRL_U	uCHCTRL2;			// 0x84
	RPTCTRL_U	uRPTCTRL2;			// 0x88
	uint		uDREQSEL2;			// 0x8C
	uint		_undef6;			// 0x90
}	GDMA;


///////////////////////////////////////////////////////////
//
//	for I2C Controller
//
//////////////////////////////////////////////////////////

//=================================//
//  I2C Channel Control Registers  //
//=================================//
typedef struct {
  uint  CH0   : 16;  //M0
  uint  CH1   : 16;  //M1
} CHCFG0;

typedef struct {
  uint  CH2   : 16;  //M2
  uint  CH3   : 16;  //M3
} CHCFG1;

typedef struct {
  uint  CH4   : 16;  //M4
  uint  CH5   : 16;  //M5
} CHCFG2;


typedef struct {
  uint  CH6   : 16;  //M6
  uint  CH7   : 16;  //M7
} CHCFG3;

typedef struct {
  uint  CH8   : 16;  //S0
  uint  CH9   : 16;  //S1
} CHCFG4;

typedef struct {
  uint  CH10  : 16;  //S2
  uint  CH11  : 16;  //S3
} CHCFG5;

typedef union {
  uint   nCHCFG0;
  CHCFG0 bCHCFG0;
} CHCFG0_U;

typedef union {
  uint   nCHCFG1;
  CHCFG1 bCHCFG1;
} CHCFG1_U;

typedef union {
  uint   nCHCFG2;
  CHCFG2 bCHCFG2;
} CHCFG2_U;

typedef union {
  uint   nCHCFG3;
  CHCFG3 bCHCFG3;
} CHCFG3_U;

typedef union {
  uint   nCHCFG4;
  CHCFG4 bCHCFG4;
} CHCFG4_U;

typedef union {
  uint   nCHCFG5;
  CHCFG5 bCHCFG5;
} CHCFG5_U;


// Channel IRQ Status Register
typedef struct {
  uint  MIRQ0 : 1;
  uint  MIRQ1 : 1;
  uint  MIRQ2 : 1;
  uint  MIRQ3 : 1;
  uint  MIRQ4 : 1;
  uint  MIRQ5 : 1;
  uint  MIRQ6 : 1;
  uint  MIRQ7 : 1;
  uint  SIRQ0 : 1;
  uint  SIRQ1 : 1;
  uint  SIRQ2 : 1;
  uint  SIRQ3 : 1;
  uint        :20;
} IRQSTR;

typedef union {
  uint   nIRQSTR;
  IRQSTR bIRQSTR;
} IRQSTR_U;

typedef struct {
  CHCFG0_U     uCHCFG0;  // 0x00
  CHCFG1_U     uCHCFG1;  // 0x04
  CHCFG2_U     uCHCFG2;  // 0x08
  CHCFG3_U     uCHCFG3;  // 0x0C
  CHCFG4_U     uCHCFG4;  // 0x10
  CHCFG5_U     uCHCFG5;  // 0x14
  uint         :32;  // 0x14
  IRQSTR_U     uIRQSTR;  // 0x1C
} I2CCFG;



//========================//
//  I2C Master Registers  //
//========================//
// TCC8960 has eight  I2C master
// TCC8930 has four I2C master

// Timing Register
typedef struct {
  uint  FC    : 5;
  uint  CS    : 1;
  uint        : 2;
  uint  RC    : 8;
  uint        :16;
} TIME;

typedef union {
  uint  nTIME;
  TIME  bTIME;
} TIME_U;

// Status Register
typedef struct {
  uint  IF    : 1; // intr flag ( 1 for pending )
  uint  TIP   : 1; // transfer completed ( 1 for transferring )
  uint  STR   : 1;
  uint        : 2;
  uint  AL    : 1; // arbitration lost ( 1 for lost )
  uint  BUSY  : 1; // '1' after START signal detected,
                   // '0' for STOP
  uint  RXACK : 1; // acknowledge received ( 0 for no-ack )
  uint        :24;
} STS;

typedef union {
  uint  nSTATUS;
  STS   bSTATUS;
} MSTAT_U;

// Receive Register
typedef struct {
  uint  RXDATA :16;
  uint         :16;
} RXDAT;

typedef union {
  uint  nRXDATA;
  RXDAT bRXDATA;
} RXDATA_U;

// Command Register
typedef struct {
  uint  IACK  : 1;	// intr ack ( writing '1' for clear )
  //uint        : 2;
  uint        : 1;
  uint  DEL   : 1;	// delay condition generation
  uint  ACK	  : 1;	// sent acknowledge ( 1 for disabled )
  uint  WR    : 1;	// write to slave
  uint  RD    : 1;	// read from slave
  uint  STO	  : 1;	// stop condition generation
  uint  STA	  : 1;	// start condition generation
  uint        :24;
} CMD;

typedef union {
  uint  nCOMMAND;
  CMD   bCOMMAND;
} COMMAND_U;

// Transmit Register
typedef struct {
  uint  TXDATA :16;
  uint         :16;
} TXDAT;

typedef union {
  uint  nTXDATA;
  TXDAT bTXDATA;
} TXDATA_U;

// Control Register
typedef struct {
  uint        : 5;
  uint  MODE  : 1;
  uint  IEN	  : 1;
  uint  EN    : 1;
  uint        :24;
} CTRL_I2C;

typedef union {
  uint  	nCONTROL;
  CTRL_I2C  bCONTROL;
} CONTROL_U;

// Prescale Register
typedef struct {
  uint  CPD   :16;
  uint        :16;
} PRES;

typedef union {
  uint  nPRESCALE;
  PRES  bPRESCALE;
} PRESCALE_U;

typedef struct {
  uint  DLY   :16;
  uint        :16;
} DLY;

typedef union {
  uint nDLY;
  DLY  bDLY;
} DLY_U;

typedef struct {
  PRESCALE_U   uPRESCALE;  // 0x00
  CONTROL_U    uCONTROL;   // 0x04
  TXDATA_U     uTXDATA;    // 0x08
  COMMAND_U    uCOMMAND;   // 0x0C
  RXDATA_U     uRXDATA;    // 0x10
  MSTAT_U      uSTATUS;    // 0x14
  TIME_U       uTIME;      // 0x18
  DLY_U        uDLY;       // 0x1C
} I2CM;

//=======================//
//  I2C Slave Registers  //
//=======================//
// TCC8960 has four I2C slave

// Data Buffer 1
typedef struct {
  uint  DB4   : 8;
  uint  DB5   : 8;
  uint  DB6   : 8;
  uint  DB7   : 8;
} MB1;

typedef union {
  uint  nMB1;
  MB1   bMB1;
} MB1_U;

// Data Buffer 0
typedef struct {
  uint  DB0   : 8;
  uint  DB1   : 8;
  uint  DB2   : 8;
  uint  DB3   : 8;
} MB0;

typedef union {
  uint  nMB0;
  MB0   bMB0;
} MB0_U;

// Buffer Valid Flag Register
typedef struct {
  uint  MBFR  : 8;
  uint        : 8;
  uint  MBFT  : 8;
  uint        : 8;
} MBF;

typedef union {
  uint  nMBF;
  MBF   bMBF;
} MBF_U;

// Status Register
typedef struct {
  uint  SADR  : 8;
  uint		    : 8;
  uint  SMCS  : 7;
  uint  DDIR	: 1;
  uint        : 8;
} STAT;

typedef union {
  uint  nSTAT;
  STAT  bSTAT;
} STAT_U;

// Interrupt Register
typedef struct {
  uint  IRQEN   :14;
  uint          : 2;
  uint  IRQSTAT :14;
  uint          : 2;
} INT;

typedef union {
  uint  nINT;
  INT   bINT;
} INT_U;

// Address Register
typedef struct {
	uint	    	: 1;
	uint	ADDR	: 7;
	uint		    :24;
} ADDR;

typedef union {
  uint  nADDR;
  ADDR  bADDR;
} ADDR_U;

// Control register
typedef struct {
  uint	EN	  : 1;
  uint	AM	  : 1; //address mode
  uint	CLR	  : 1; //FIFO control (clear)
  uint	SDA	  : 1; //SDA control
  uint	WS    : 1; //SCL wait control
  uint	RCLR  : 1; //Clear int
  uint	WSM	  : 1; //SCL wait for MB
  uint 	drqm  : 1; //DRQ control for MB
  uint 	RXTH  : 2;
  uint		  : 2;
  uint	TXTH  : 2;
  uint		  : 2;
  uint	DRQEN : 4;
  uint	FC	  : 9;
  uint  FM    : 1; //Counter(Filter) Control
  uint	SLV   : 2; //Master Signal Control
} CTL;

typedef union {
  uint  nCTL;
  CTL   bCTL;
} CTL_U;

// Data Port register
typedef struct {
  uint  PORT : 8;
  uint       : 8;
  uint  RXVC : 3;
  uint       : 5;
  uint  TXVC : 3;
  uint       : 5;
} PORT;

typedef union {
  uint  nPORT;
  PORT  bPORT;
} PORT_U;

typedef struct {
  PORT_U       uPORT;  // 0x80
  CTL_U        uCTL;   // 0x84
  ADDR_U       uADDR;  // 0x88
  INT_U        uINT;   // 0x8C
  STAT_U       uSTAT;  // 0x90
  uint         undef1; // 0x94
  uint         undef2; // 0x98
  MBF_U        uMBF;   // 0x9C
  MB0_U        uMB0;   // 0xA0
  MB1_U        uMB1;   // 0xA4
} I2CS;

typedef	struct	_I2C_CH {
	uint	nPRESCALE;			// 16 bits data [15:00]
	union	{
		uint	nCONTROL;
		struct	_I2C_CONTROL {
			uint	_reser0	: 5;
			uint	MODE	: 1;
			uint	IEN	: 1;
			uint	EN	: 1;
			uint	_undef0	:24;
		}	bCONTROL;
	}	uCONTROL;
	uint	nTXDATA;			// 16 bits data [15:00]
	union	{
		uint	nCOMMAND;
		struct	_I2C_COMMAND {
			uint	IACK	: 1;	// interrupt acknowledge ( writing '1' for clear )
			uint	_reser0	: 1;
			//uint	_reser0	: 2;
			//uint    DEL : 0;	// delay condition generation
			uint     : 1;	// delay condition generation
			uint	ACK	: 1;	// sent acknowledge ( 1 for disabled )
			uint	WR	: 1;	// write to slave
			uint	RD	: 1;	// read from slave
			uint	STO	: 1;	// stop condition generation
			uint	STA	: 1;	// start condition generation
			uint	_undef0	:24;
		}	bCOMMAND;
	}	uCOMMAND;
	uint	nRXDATA;			// 16 bits data [15:00]
	union	{
		uint	nSTATUS;
		struct	_I2C_STATUS {
			uint	IF	: 1;	// interrupt flag ( 1 for pending )
			uint	TIP	: 1;	// transfer completed ( 0 for transferring )
  			uint  	STR   : 1; // delay completed ( '1' duing delay counting)
			uint	_undef0	: 2;
			//uint	_undef0	: 3;
			uint	AL	: 1;	// arbitration lost ( 1 for lost arbitration )
			uint	BUSY	: 1;	// '1' after START signal detected, '0' for STOP
			uint	RXACK	: 1;	// acknowledge received ( 0 for no-ack )
			uint	_undef1	:24;
		}	bSTATUS;
	}	uSTATUS;
	union	{
		uint	nTIME;
		struct	_I2C_TIME {
			uint	FC	: 5;
			uint 	CS	: 1;
			uint		: 2;
			uint	RC	: 8;
			uint		: 16;
		}	bTIME;
	}	uTIME ;
	uint	undef0[9];
}	I2C_CH;



typedef struct _I2C{
	I2C_CH	pCH0;
	I2C_CH	pCH1;
	union	{
		uint	nPORT;
		struct _I2C_PORTS {
			uint		PORT : 8;
			uint			 : 8;
			uint		RXVC : 3;
			uint			 : 5;
			uint        TXVC : 3;
			uint			 : 5;
		} bPORT;
	}	uPORT;
	union	{
		uint	nCTL;
		struct _I2C_CTL {
			uint	EN	: 1;
			uint		: 1;
			uint	CLR : 1;
			uint	SDA	: 1;
			uint	WS  : 1;
			uint	RCLR: 1;
			uint		: 2;
			uint 	RXTH: 2;
			uint		: 2;
			uint	TXTH: 2;
			uint		: 2;
			uint	DRQEN : 4;
			uint	FC	: 5;
			uint		: 5;
			uint	SLV : 2;
		} bCTL;
	}	uCTL;
	union	{
		uint	nADDR;
		struct _I2C_ADDR {
			uint		: 1;
			uint	ADDR: 7;
			uint		:24;
		} bADDR;
	}	uADDR;
	union {
		uint	nINT;
		struct _I2C_INT {
			uint	IRQEN: 12;
			uint		:  4;
			uint	IRQSTAT : 12;
			uint		: 4;
		} bINT;
	} uINT;
	union {
		uint	nSTAT;
		struct _I2C_STAT {
			uint SADR 	: 8;
			uint		:15;
			uint DDIR	: 1;
			uint		: 8;
		} bSTAT;
	} uSTAT;
	uint  tempp[2];
	union {
		uint	nMBF;
		struct _I2C_MBF {
			uint	MBFR : 8;
			uint		 : 8;
			uint	MBRT : 8;
			uint 		 : 8;
		} bMBF;
	} uMBF;
//	unsigned char DATA[7];
	union {
		uint  nDATA0;
	} uDATA0;
	union {
		uint  nDATA1;
	} uDATA1;
} I2C;

#define I2C_PORT0 0
#define I2C_PORT1 1
#define I2C_PORT2 2
#define I2C_PORT3 3
#define I2C_PORT4 4
#define I2C_PORT5 5
#define I2C_PORT6 6
#define I2C_PORT7 7
#define I2C_PORT8 8
#define I2C_PORT9 9
#define I2C_PORT10 10
#define I2C_PORT11 11

#define I2CM_CH0 0
#define I2CM_CH1 1
#define I2CM_CH2 2
#define I2CM_CH3 3
#define I2CM_CH4 4
#define I2CM_CH5 5
#define I2CM_CH6 6
#define I2CM_CH7 7
#define I2CS_CH0 8
#define I2CS_CH1 9
#define I2CS_CH2 10
#define I2CS_CH3 11
//
#define I2C_8BIT  0
#define I2C_16BIT 1

#define	I2C_START	((0x1)<<7)
#define	I2C_STOP	((0x1)<<6)
#define	I2C_RD		((0x1)<<5)
#define	I2C_WR		((0x1)<<4)
#define	I2C_ACK		((0x1)<<3)
#define	I2C_DELAY	((0x1)<<2)
#define	I2C_IACK	((0x1)<<0)


#if 1  // pnor

typedef struct{
    uint A2X : 4; //[03:00]  //External Bus Controller Enable
    uint     : 28;
} XCFG0;

typedef union{
    uint    nXCFG0;
    XCFG0   bXCFG0;
} XCFG0_U;


typedef struct{
    uint penX      : 4; //[03:00] //Prefetch Enable, Burst Length Define
    uint BEC_CS0   : 1; //[04] //Byte Enable Control for Read
    uint BEC_CS1   : 1; //[05] //Byte Enable Control for Read
    uint BEC_CS2   : 1; //[06] //Byte Enable Control for Read
    uint BEC_CS3   : 1; //[07] //Byte Enable Control for Read
    uint wbthX     : 4; //[11:08] //Write Buffer Theshold
    uint           : 12; //[23:12]
    uint DIMUX_CS0 : 2; //[25:24] //Data Input Mux in CS0, 01: xio[15:8], 10: xio[31:16], 11: xio[31:24]
    uint DIMUX_CS1 : 2; //[27:26] //Data Input Mux in CS1
    uint DIMUX_CS2 : 2; //[29:28] //Data Input Mux in CS2
    uint DIMUX_CS3 : 2; //[31:30] //Data Input Mux in CS3
} XCFG1;

typedef union{
    uint    nXCFG1;
    XCFG1   bXCFG1;
} XCFG1_U;


typedef struct{
    uint sizeX0     : 6; //[05:00] //Prefetch Size
    uint            : 4; //[09:06]
    uint baseX0     : 19; //[28:10] //Prefetch Base
    uint            : 3; //[31:29]
} XCFG;

typedef union{
    uint nXCFG;
    XCFG bXCFG;
} XCFG_U;

//Timing Control Description
//
//<----->|<------------>|<------>|
// SETUP |     PW+1     |  HOLD  |
//       | data tranfer |        |
//HOLD is used when MASK register is 0

typedef struct{
    uint REC       :   4; //[03:00] Recovery (CS high)
    uint HOLD      :   4; //[07:04] Hold
    uint PW        :   8; //[15:08] Pulse Width
    uint SETUP     :   6; //[21:16] Setup
    uint MASK      :   3; //[24:22] Page Address Mask (4=32bytes), (3=16bytes). This register means how long the PNOR controller can transfer data.
    uint BYTE_EN   :   1; //[25]    Byte Enable
    uint BW        :   2; //[27:26] Bus Width (2=16-bit)
    uint RDY_POL   :   1; //[28]    Ready Polarity
    uint RDY_EN    :   1; //[29]    Ready Enable
    uint BASE      :   2; //[31:30] Base
} XSCS;

typedef union{
    uint    nXSCS;
    XSCS    bXSCS;
} XSCS_U;


//    Parallel NOR Controller Register
/////////////////////////////////////////////////////////
typedef struct _PNOR {
    XCFG0_U               uXCFG0;     // 0x100
    XCFG1_U               uXCFG1;     // 0x104
    XCFG_U                uXCFG2;     // 0x108
    XCFG_U                uXCFG3;     // 0x10C
    XSCS_U                uXSCS0;     // 0x110
    XSCS_U                uXSCS1;     // 0x114
    XSCS_U                uXSCS2;     // 0x118
    XSCS_U                uXSCS3;     // 0x11C
    uint                  uXTMOV;     // 0x120
} PNOR;

#endif
#endif
