/****************************************************************************
 *   FileName    : snor_mio_gpio.h
 *   Description : Serial Flash Multi I/O Driver
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef _SNOR_MIO_GPIO_H
#define _SNOR_MIO_GPIO_H

#if 0 /* for tcc802x */

#define HwSMUBUS            0x14000000
#define HwGPIO              ((volatile GPIO         *)(HwSMUBUS  + 0x200000))

#define EIRQ_GPIOC_5	64

//===================================================//
//         Register structure for GP(ABCDEFG)        //
//===================================================//
typedef struct {
    unsigned int        P0      : 1;
    unsigned int        P1      : 1;
    unsigned int        P2      : 1;
    unsigned int        P3      : 1;
    unsigned int        P4      : 1;
    unsigned int        P5      : 1;
    unsigned int        P6      : 1;
    unsigned int        P7      : 1;
    unsigned int        P8      : 1;
    unsigned int        P9      : 1;
    unsigned int        P10     : 1;
    unsigned int        P11     : 1;
    unsigned int        P12     : 1;
    unsigned int        P13     : 1;
    unsigned int        P14     : 1;
    unsigned int        P15     : 1;
    unsigned int        P16     : 1;
    unsigned int        P17     : 1;
    unsigned int        P18     : 1;
    unsigned int        P19     : 1;
    unsigned int        P20     : 1;
    unsigned int        P21     : 1;
    unsigned int        P22     : 1;
    unsigned int        P23     : 1;
    unsigned int        P24     : 1;
    unsigned int        P25     : 1;
    unsigned int        P26     : 1;
    unsigned int        P27     : 1;
    unsigned int        P28     : 1;
    unsigned int        P29     : 1;
    unsigned int        P30     : 1;
    unsigned int        P31     : 1;
}   GPIO_BIT1;

typedef union {
    unsigned int        nReg;
    GPIO_BIT1   bReg;
}   GPIO_B1_U;

typedef struct {
    unsigned int        P0      : 2;
    unsigned int        P1      : 2;
    unsigned int        P2      : 2;
    unsigned int        P3      : 2;
    unsigned int        P4      : 2;
    unsigned int        P5      : 2;
    unsigned int        P6      : 2;
    unsigned int        P7      : 2;
    unsigned int        P8      : 2;
    unsigned int        P9      : 2;
    unsigned int        P10     : 2;
    unsigned int        P11     : 2;
    unsigned int        P12     : 2;
    unsigned int        P13     : 2;
    unsigned int        P14     : 2;
    unsigned int        P15     : 2;
    unsigned int        P16     : 2;
    unsigned int        P17     : 2;
    unsigned int        P18     : 2;
    unsigned int        P19     : 2;
    unsigned int        P20     : 2;
    unsigned int        P21     : 2;
    unsigned int        P22     : 2;
    unsigned int        P23     : 2;
    unsigned int        P24     : 2;
    unsigned int        P25     : 2;
    unsigned int        P26     : 2;
    unsigned int        P27     : 2;
    unsigned int        P28     : 2;
    unsigned int        P29     : 2;
    unsigned int        P30     : 2;
    unsigned int        P31     : 2;
}   GPIO_BIT2;

typedef union {
    unsigned int        nReg[2];
    GPIO_BIT2   bReg;
}   GPIO_B2_U;

typedef struct {
    unsigned int        P0      : 4;
    unsigned int        P1      : 4;
    unsigned int        P2      : 4;
    unsigned int        P3      : 4;
    unsigned int        P4      : 4;
    unsigned int        P5      : 4;
    unsigned int        P6      : 4;
    unsigned int        P7      : 4;
    unsigned int        P8      : 4;
    unsigned int        P9      : 4;
    unsigned int        P10     : 4;
    unsigned int        P11     : 4;
    unsigned int        P12     : 4;
    unsigned int        P13     : 4;
    unsigned int        P14     : 4;
    unsigned int        P15     : 4;
    unsigned int        P16     : 4;
    unsigned int        P17     : 4;
    unsigned int        P18     : 4;
    unsigned int        P19     : 4;
    unsigned int        P20     : 4;
    unsigned int        P21     : 4;
    unsigned int        P22     : 4;
    unsigned int        P23     : 4;
    unsigned int        P24     : 4;
    unsigned int        P25     : 4;
    unsigned int        P26     : 4;
    unsigned int        P27     : 4;
    unsigned int        P28     : 4;
    unsigned int        P29     : 4;
    unsigned int        P30     : 4;
    unsigned int        P31     : 4;
}   GPIO_BIT4;

typedef union {
    unsigned int        nReg[4];
    GPIO_BIT4   bReg;
}   GPIO_B4_U;

typedef struct {
    GPIO_B1_U   uDAT;  // pGPx + 0x000 : Data
    GPIO_B1_U   uCON;  // pGPx + 0x004 : Output enable
    GPIO_B1_U   uSET;  // pGPx + 0x008 : OR func. on output data
    GPIO_B1_U   uCLR;  // pGPx + 0x00C : BIC func. on output data
    GPIO_B1_U   uXOR;  // pGPx + 0x010 : XOR func. on output data
    GPIO_B2_U   uCD;   // pGPx + 0x014 : Driver strength
    GPIO_B1_U   uPE;   // pGPx + 0x01C : PU/PD Enable func.
    GPIO_B1_U   uPS;   // pGPx + 0x020 : PU/PD Selection func.
    GPIO_B1_U   uIEN;  // pGPx + 0x024 : Input buffer Enable func.
    GPIO_B1_U   uIS;   // pGPx + 0x028 : Schimitt Input func.
    GPIO_B1_U   uSR;   // pGPx + 0x02C : Fast Slew Rate func.
    GPIO_B4_U   uFNC;  // pGPx + 0x030 : Port Configuration
} GPGROUP;

typedef struct {
    unsigned int        EINT0   : 8;
    unsigned int        EINT1   : 8;
    unsigned int        EINT2   : 8;
    unsigned int        EINT3   : 8;
    unsigned int        EINT4   : 8;
    unsigned int        EINT5   : 8;
    unsigned int        EINT6   : 8;
    unsigned int        EINT7   : 8;
    unsigned int        EINT8   : 8;
    unsigned int        EINT9   : 8;
    unsigned int        EINT10  : 8;
    unsigned int        EINT11  : 8;
    unsigned int        EINT12  : 8;
    unsigned int        EINT13  : 8;
    unsigned int        EINT14  : 8;
    unsigned int        EINT15  : 8;
}   EINTCFG;

typedef union {
    unsigned int        nReg[4];
    EINTCFG     bReg;
}   EINTCFG_U;

typedef struct {
    unsigned int                :12;
    unsigned int        GPO     :20;
    unsigned int        GPIS    : 1;
    unsigned int                :31;
    unsigned int        GPIP_L  :32;
    unsigned int        GPIP_H  :32;
    unsigned int                :32;
    unsigned int                :32;
}   ECIDCFG;

typedef union {
    unsigned int        nReg[6]; // 0x290~0x2A4
    ECIDCFG     bReg;
}   ECIDCFG_U;


typedef struct  {
  GPGROUP       pGPA;     // 0x000
  GPGROUP       pGPB;     // 0x040
  GPGROUP       pGPC;     // 0x080
  GPGROUP       pGPD;     // 0x0C0
  GPGROUP       pGPE;     // 0x100
  GPGROUP       pGPF;     // 0x140
  GPGROUP       pGPG;     // 0x180
  GPGROUP       pGPHDMI;  // 0x1C0   - removed
  GPGROUP       pGPSD1;   // 0x200   - removed
  GPGROUP       pGPSD0;   // 0x240
  EINTCFG_U     pEINTCFG; // 0x280
  ECIDCFG_U     pECIDCFG; // 0x290
  unsigned int          undef0[2];
  unsigned int          pEXTCLKCFG; // 0x2B0
  unsigned int          undef1[83];
  GPGROUP       pGPH;     // 0x400
  GPGROUP       pGPK;     // 0x440
} GPIO;
#else

typedef struct {
	volatile uint	uDAT;		// pGPx + 0x000 : Data
	volatile uint	uCON;		// pGPx + 0x004 : Output enable
	volatile uint	uSET;		// pGPx + 0x008 : OR func. on output data
	volatile uint	uCLR;		// pGPx + 0x00C : BIC func. on output data
	volatile uint	uXOR;		// pGPx + 0x010 : XOR func. on output data
	volatile uint	uCD[2];		// pGPx + 0x014 : Driver strength
	volatile uint	uPE;		// pGPx + 0x01C : PU/PD Enable func.
	volatile uint	uPS;		// pGPx + 0x020 : PU/PD Selection func.
	volatile uint	uIEN;		// pGPx + 0x024 : Input buffer Enable func.
	volatile uint	uIS;		// pGPx + 0x028 : Schimitt Input func.
	volatile uint	uSR;		// pGPx + 0x02C : Fast Slew Rate func.
	volatile uint	uFNC[4];	// pGPx + 0x030 : Port Configuration
} GPGROUP;

typedef struct {
    uint        EINT0   : 8;
    uint        EINT1   : 8;
    uint        EINT2   : 8;
    uint        EINT3   : 8;
    uint        EINT4   : 8;
    uint        EINT5   : 8;
    uint        EINT6   : 8;
    uint        EINT7   : 8;
    uint        EINT8   : 8;
    uint        EINT9   : 8;
    uint        EINT10  : 8;
    uint        EINT11  : 8;
    uint        EINT12  : 8;
    uint        EINT13  : 8;
    uint        EINT14  : 8;
    uint        EINT15  : 8;
}   EINTCFG;

typedef union {
    uint        nReg[4];
    EINTCFG     bReg;
}   EINTCFG_U;

typedef struct {
    uint                :16;
    uint        GPO     :16;
    uint        GPIS    : 1;
    uint                :31;
    uint        GPIP_0  :32;
    uint        GPIP_1  :32;
    uint        GPIP_2  :32;
    uint        GPIP_3  :32;
}   ECIDCFG;

typedef union {
    uint        nReg[6]; // 0x290~0x2A4
    ECIDCFG     bReg;
}   ECIDCFG_U;

typedef struct {
	uint		EXTCLKSEL_00	: 8;
	uint		EXTCLKSEL_01	: 8;
	uint		EXTCLKSEL_02	: 8;
	uint		EXTCLKSEL_03	: 8;
} EXTCLKSEL;
typedef union {
	uint		nReg;
	EXTCLKSEL	bReg;
} EXTCLKSEL_U;

typedef struct {
	uint	uVI2O_OEN;
	uint	uVI2I_DAT;
	uint	uVI2O_EN;
	uint	uVI2I_EN;
	uint	uMON_DO;
	uint	uMON_OEN;
} TPG;

typedef struct  {
  GPGROUP       pGPA;			// 0x000
  GPGROUP       pGPB;     		// 0x040
  GPGROUP       pGPC;     		// 0x080
  GPGROUP       pGPD;     		// 0x0C0
  GPGROUP       pGPE;     		// 0x100
  GPGROUP       pGPF;     		// 0x140
  GPGROUP       pGPG;     		// 0x180
  GPGROUP       pGPHDMI;  		// 0x1C0
  GPGROUP       pGPSD0;   		// 0x200
  GPGROUP       pGPSD1;   		// 0x240
  EINTCFG_U     pEINTCFG; 		// 0x280
  ECIDCFG_U     pECIDCFG; 		// 0x290 ~ 0x2A4
  uint			reserved0[2];	// 0x2A8 ~ 0x2AC
  EXTCLKSEL_U	pEXTCLKSEL;		// 0x2B0
  uint			reserved1[3];	// 0x2B4 ~ 0x2BC
  uint			reserved2[4];	// 0x2C0 ~ 0x2CC
  uint			reserved3[4];	// 0x2D0 ~ 0x2DC
  uint			reserved4[4];	// 0x2E0 ~ 0x2EC
  uint			reserved5[4];	// 0x2F0 ~ 0x2FC
  uint			pGPA_FNCLOCKEN;		// 0x300
  uint			pGPB_FNCLOCKEN;		// 0x304
  uint			pGPC_FNCLOCKEN;		// 0x308
  uint			pGPD_FNCLOCKEN;		// 0x30C
  uint			pGPE_FNCLOCKEN;		// 0x310
  uint			pGPF_FNCLOCKEN;		// 0x314
  uint			pGPG_FNCLOCKEN;		// 0x318
  uint			pGPHDMI_FNCLOCKEN;	// 0x31C
  uint			pGPSD0_FNCLOCKEN;	// 0x320
  uint			pGPSD1_FNCLOCKEN;	// 0x324
  uint		    pGPSD2_FNCLOCKEN;	// 0x328
  uint		    pGPH_FNCLOCKEN;		// 0x32C
  uint		    pGPK_FNCLOCKEN;		// 0x330
  uint		    pGPMA_FNCLOCKEN;	// 0x334
  uint		    reserved7[18];		// 0x338 ~ 0x37C
  uint		    pGPA_ENLOCKEN;		// 0x380
  uint		    pGPB_ENLOCKEN;		// 0x384
  uint		    pGPC_ENLOCKEN;		// 0x388
  uint		    pGPD_ENLOCKEN;		// 0x38C
  uint		    pGPE_ENLOCKEN;		// 0x390
  uint		    pGPF_ENLOCKEN;		// 0x394
  uint		    pGPG_ENLOCKEN;		// 0x398
  uint		    pGPHDMI_ENLOCKEN;	// 0x39C
  uint		    pGPSD0_ENLOCKEN;	// 0x3A0
  uint		    pGPSD1_ENLOCKEN;	// 0x3A4
  uint		    pGPSD2_ENLOCKEN;	// 0x3A8
  uint		    pGPH_ENLOCKEN;		// 0x3AC
  uint		    pGPK_ENLOCKEN;		// 0x3B0
  uint		    pGPMA_ENLOCKEN;		// 0x3B4
  uint		    reserved9[18];		// 0x3B8 ~ 0x3FC
  TPG		    pGPA_TPG;		    // 0x400 ~ 0x414
  uint		    reserved10[2];		// 0x418 ~ 0x41C
  TPG		    pGPB_TPG;		    // 0x420 ~ 0x434
  uint		    reserved11[2];		// 0x438 ~ 0x43C
  TPG		    pGPC_TPG;		    // 0x440 ~ 0x454
  uint		    reserved12[2];		// 0x458 ~ 0x45C
  TPG		    pGPD_TPG;		    // 0x460 ~ 0x474
  uint		    reserved13[2];		// 0x478 ~ 0x47C
  TPG		    pGPE_TPG;		    // 0x480 ~ 0x494
  uint		    reserved14[2];		// 0x498 ~ 0x49C
  TPG		    pGPF_TPG;		    // 0x4A0 ~ 0x4B4
  uint		    reserved15[2];		// 0x4B8 ~ 0x4BC
  TPG		    pGPG_TPG;		    // 0x4C0 ~ 0x4D4
  uint		    reserved16[2];		// 0x4D8 ~ 0x4DC
  TPG		    pGPHDMI_TPG;		// 0x4E0 ~ 0x4F4
  uint		    reserved17[2];		// 0x4F8 ~ 0x4FC
  TPG		    pGPSD0_TPG;		    // 0x500 ~ 0x514
  uint		    reserved18[2];		// 0x518 ~ 0x51C
  TPG		    pGPSD1_TPG;		    // 0x520 ~ 0x534
  uint		    reserved19[2];		// 0x538 ~ 0x53C
  TPG		    pGPSD2_TPG;		    // 0x540 ~ 0x554
  uint		    reserved20[2];		// 0x558 ~ 0x55C
  TPG		    pGPH_TPG;		    // 0x560 ~ 0x574
  uint		    reserved21[2];		// 0x578 ~ 0x57C
  TPG		    pGPK_TPG;		    // 0x580 ~ 0x594
  uint		    reserved22[2];		// 0x598 ~ 0x59C
  TPG		    pGPMA_TPG;		    // 0x5A0 ~ 0x5B4
  uint		    reserved23[2];		// 0x5B8 ~ 0x5BC
  uint		    reserved24[16];		// 0x5C0 ~ 0x5FC
  GPGROUP       pGPSD2;             // 0x600
  GPGROUP       pGPH;  	            // 0x640
  GPGROUP       pGPK;   	        // 0x680
  GPGROUP       pGPMA;              // 0x6C0

} GPIO;

#define HwMCGPIO_BASE		0x1B935000
#define HwGPIO              ((volatile GPIO         *)(HwMCGPIO_BASE))

#endif

#endif

