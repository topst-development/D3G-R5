#ifndef __TCC_SC_CKC_H__
#define __TCC_SC_CKC_H__

#define STRG_CKC_BASE	0x1D2C1000

#define	STRG_CKC_SUB_OFFSET		0x0
#define STRG_CKC_eMMC_OFFSET		0x4
#define STRG_CKC_UFS_CTRL_OFFSET	0x8
#define	STRG_CKC_UFS_INTERNAL_OFFSET	0xC

#define	STRG_DPLL_OFFSET		0x10
#define	STRG_CLKDIV_OFFSET		0x30

#define STRG_DPLL_PMS_OFFSET		0x10
#define	STRG_DPLL_CON_OFFSET		0x14
#define	STRG_DPLL_MON_OFFSET		0x18
#define	STRG_DIV_CLK_OFFSET		0x30

#define STRG_CLK_SEL_SHIFT		0
#define STRG_CLK_SEL_MASK		0x7
#define	STRG_CLK_EXTSEL_SHIFT		3
#define	STRG_CLK_EXTSEL_MASK		0x1
#define	STRG_CLK_CHGRQ_SHIFT		31
#define	STRG_CLK_CHGRQ_MASK		0x1

enum {
	STRG_SRC_XIN = 0,
	STRG_SRC_PLL_DIR,
	STRG_SRC_PLL_DIV0 = 3,
	STRG_SRC_PLL_DIV1,
	STRG_SRC_PLL_DIV2,
	STRG_SRC_PLL_DIV3,
	STRG_SRC_EXT_CLK
};

struct clk_ctrl {
	unsigned int	strg_subsys;
	unsigned int	strg_eMMC;
	unsigned int	strg_UFS_ctrl;
	unsigned int	strg_UFS_inter_ref;
};

#define	PLL_P_SHIFT			0
#define	PLL_M_SHIFT			6
#define	PLL_S_SHIFT			16
#define	PLL_BYPASS_SHIFT		21
#define	PLL_LOCK_SHIFT			23
#define	PLL_ICP_SHIFT			24
#define	PLL_LOCK_EN_SHIFT		26
#define	PLL_RSEL_SHIFT			27
#define	PLL_EN_SHIFT			31

#define	PLL_P_MASK			0x3F
#define	PLL_M_MASK			0x3FF
#define	PLL_S_MASK			0x7
#define	PLL_BYPASS_MASK			0x1
#define	PLL_LOCK_MASK			0x1
#define	PLL_ICP_MASK			0x3
#define	PLL_LOCK_EN_MASK		0x1
#define	PLL_RSEL_MASK			0xF
#define	PLL_EN_MASK			0x1

struct pll_ctrl {
	unsigned int	strg_pll_pms;
	unsigned int	strg_pll_con;
	unsigned int	strg_pll_mon;
};

#define	CLK_DIV3_ENABLE_SHIFT		31
#define CLK_DIV3_VAL_SHIFT		24

#define	CLK_DIV2_ENABLE_SHIFT		23
#define CLK_DIV2_VAL_SHIFT		16

#define	CLK_DIV1_ENABLE_SHIFT		15
#define CLK_DIV1_VAL_SHIFT		8

#define	CLK_DIV0_ENABLE_SHIFT		7
#define CLK_DIV0_VAL_SHIFT		0

#define CLK_DIV_VAL_MASK		0x3F
#define	CLK_DIV_ENABLE_MASK		0x1

enum {
	CLK_DIV0 = 0,
	CLK_DIV1,
	CLK_DIV2,
	CLK_DIV3,
};

/* Clock enable/reset register in storage core. */
#define	STRG_CLK_MASK_BASE	(0x1D2C0000 + 0x14)
#define	STRG_CLK_RST_BASE	(0x1D2C0000 + 0x18)

/* Clock enable/reset register field. */
/* 1 : enable, 0 : disable(masking) */
#define	STRG_ENABLE			0x1
#define	STRG_DISABLE			0x0

#define	STRG_MASK_CM4			0
#define	STRG_MASK_CODEMEM		2
#define	STRG_MASK_DATAMEM		3
#define	STRG_MASK_MBOX0			4
#define	STRG_MASK_MBOX1			5
#define	STRG_MASK_MBOX2			6
#define	STRG_MASK_SMBOX0		7
#define	STRG_MASK_SMBOX1		8
#define	STRG_MASK_SMBOX2		9
#define	STRG_MASK_UFS_HCI		10
#define	STRG_MASK_UFS_FMP		11
#define	STRG_MASK_SD			13
#define	STRG_MASK_DMAC			14
#define	STRG_MASK_CFG			15
#define	STRG_MASK_WDT			16
#define	STRG_MASK_SWRAP			17
#define	STRG_MASK_SD_IOMUX		18
/* CM4_SYS, CM4_POR are only available in reset masking register. */
#define	STRG_MASK_CM4_SYS		19
#define	STRG_MASK_CM4_POR		20
#define	STRG_MASK_DCPT_MEM		21

void vCKC_udelay(unsigned int usecs);
void vCKC_Set_Subsystem_Clock(unsigned int src, unsigned int ext);
void vCKC_Set_eMMC_Clock(unsigned int src, unsigned int ext);
void vCKC_Set_UFS_Controller_Clock(unsigned int src, unsigned int ext);
void vCKC_Set_UFS_InterRef_Clock(unsigned int src, unsigned int ext);
void vCKC_Set_PLL_PMS_Clock(unsigned int p, unsigned int m, unsigned int s);
void vCKC_Set_CLKDIVC(unsigned int id, unsigned int val);
void vCKC_Set_Clk_Mask(unsigned int id, unsigned int en);
void vCKC_Set_Reset_Mask(unsigned int id, unsigned int en);

#endif
