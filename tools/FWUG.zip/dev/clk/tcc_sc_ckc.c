#include <stdio.h>
#include "tcc_sc_ckc.h"

void vCKC_udelay(unsigned int usecs)
{
    // TBD
}

// set sub system clock
void vCKC_Set_Subsystem_Clock(unsigned int src, unsigned int ext)
{
	struct clk_ctrl *strg_clk = (struct clk_ctrl *)(STRG_CKC_BASE);
	unsigned int reg_val = 0;
	unsigned int write_chk = (STRG_CLK_CHGRQ_MASK << STRG_CLK_CHGRQ_SHIFT);

	// ext == 1, external clock source
	if (ext == 0)
		reg_val = (src << STRG_CLK_SEL_SHIFT) & (STRG_CLK_SEL_MASK);
	else
		reg_val = (ext << STRG_CLK_EXTSEL_SHIFT) & (STRG_CLK_EXTSEL_MASK);

	// Set source clock val.
	strg_clk->strg_subsys = reg_val;
	
	// Loop until write done.
	while(strg_clk->strg_subsys & write_chk);
}

// set eMMC Clock
void vCKC_Set_eMMC_Clock(unsigned int src, unsigned int ext)
{
	struct clk_ctrl *strg_clk = (struct clk_ctrl *)(STRG_CKC_BASE);
	unsigned int reg_val = 0;
	unsigned int write_chk = (STRG_CLK_CHGRQ_MASK << STRG_CLK_CHGRQ_SHIFT);
	
	// ext == 1, external clock source
	if (ext == 0)
		reg_val = (src << STRG_CLK_SEL_SHIFT) & (STRG_CLK_SEL_MASK);
	else
		reg_val = (ext << STRG_CLK_EXTSEL_SHIFT) & (STRG_CLK_EXTSEL_MASK);

	// Set source clock val.
	strg_clk->strg_eMMC = reg_val;

	// Loop until write done.
	while(strg_clk->strg_eMMC & write_chk);
}

// set UFS Controller Clock
void vCKC_Set_UFS_Controller_Clock(unsigned int src, unsigned int ext)
{
	struct clk_ctrl *strg_clk = (struct clk_ctrl *)(STRG_CKC_BASE);
	unsigned int reg_val = 0;
	unsigned int write_chk = (STRG_CLK_CHGRQ_MASK << STRG_CLK_CHGRQ_SHIFT);
	
	// ext == 1, external clock source
	if (ext == 0)
		reg_val = (src << STRG_CLK_SEL_SHIFT) & (STRG_CLK_SEL_MASK);
	else
		reg_val = (ext << STRG_CLK_EXTSEL_SHIFT) & (STRG_CLK_EXTSEL_MASK);

	// Set source clock val.
	strg_clk->strg_UFS_ctrl = reg_val;

	// Loop until write done.
	while(strg_clk->strg_UFS_ctrl & write_chk);	
}

// set UFS Internal Ref. Clock
void vCKC_Set_UFS_InterRef_Clock(unsigned int src, unsigned int ext)
{
	struct clk_ctrl *strg_clk = (struct clk_ctrl *)(STRG_CKC_BASE);
	unsigned int reg_val = 0;
	unsigned int write_chk = (STRG_CLK_CHGRQ_MASK << STRG_CLK_CHGRQ_SHIFT);

	// ext == 1, external clock source
	if (ext == 0)
		reg_val = (src << STRG_CLK_SEL_SHIFT) & (STRG_CLK_SEL_MASK);
	else
		reg_val = (ext << STRG_CLK_EXTSEL_SHIFT) & (STRG_CLK_EXTSEL_MASK);

	// Set source clock val.
	strg_clk->strg_UFS_inter_ref = reg_val;

	// Loop until write done.
	while(strg_clk->strg_UFS_inter_ref & write_chk);
}

// set PLL P, M, S reg
void vCKC_Set_PLL_PMS_Clock(unsigned int p, unsigned int m, unsigned int s)
{
	struct pll_ctrl *strg_pll = (struct pll_ctrl *)(STRG_CKC_BASE + STRG_DPLL_OFFSET);
	unsigned int reg_val = 0;

	// clear enable bit
	strg_pll->strg_pll_pms = strg_pll->strg_pll_pms & ~(1<<PLL_EN_SHIFT);
	vCKC_udelay(1);

	reg_val = (strg_pll->strg_pll_pms) & ~(
		(PLL_LOCK_EN_MASK << PLL_LOCK_EN_SHIFT) | (PLL_P_MASK << PLL_P_SHIFT) 
		| (PLL_M_MASK << PLL_M_SHIFT) | (PLL_S_MASK << PLL_S_SHIFT)
		);

	reg_val = (
		(PLL_LOCK_EN_MASK << PLL_LOCK_EN_SHIFT) | ((p&PLL_P_MASK) << PLL_P_SHIFT)
		| ((m&PLL_M_MASK) << PLL_M_SHIFT) | ((s&PLL_S_MASK) << PLL_S_SHIFT)
		);

	strg_pll->strg_pll_pms = reg_val;
	vCKC_udelay(1);

	// set enable bit
	strg_pll->strg_pll_pms = strg_pll->strg_pll_pms | (1<<PLL_EN_SHIFT);

	while ((strg_pll->strg_pll_pms &(PLL_LOCK_MASK<<PLL_LOCK_SHIFT)) == 0);
}

// set CLKDIVC reg
void vCKC_Set_CLKDIVC(unsigned int id, unsigned int val)
{
	volatile unsigned int *clkdiv_reg = (volatile unsigned int *)(STRG_CKC_BASE + STRG_CLKDIV_OFFSET);
	unsigned int div_en_shift = 0;
	unsigned int div_val_shift = 0;

	switch (id) 
	{
		case CLK_DIV0 :
			div_en_shift = CLK_DIV0_ENABLE_SHIFT;
			div_val_shift = CLK_DIV0_VAL_SHIFT;
			break;
		case CLK_DIV1 :
			div_en_shift = CLK_DIV1_ENABLE_SHIFT;
			div_val_shift = CLK_DIV1_VAL_SHIFT;
			break;
		case CLK_DIV2 :
			div_en_shift = CLK_DIV2_ENABLE_SHIFT;
			div_val_shift = CLK_DIV2_VAL_SHIFT;
			break;
		case CLK_DIV3 :
			div_en_shift = CLK_DIV3_ENABLE_SHIFT;
			div_val_shift = CLK_DIV3_VAL_SHIFT;
			break;
		default :
			break;
	}

	(*clkdiv_reg) = (*clkdiv_reg) & ~(CLK_DIV_ENABLE_MASK << div_en_shift);
	(*clkdiv_reg) = (*clkdiv_reg) & ~(CLK_DIV_VAL_MASK << div_val_shift);

	(*clkdiv_reg) = (*clkdiv_reg) | ((val & CLK_DIV_VAL_MASK) << div_val_shift);
	(*clkdiv_reg) = (*clkdiv_reg) | ((1 & CLK_DIV_ENABLE_MASK) << div_en_shift);
}

// set Clock masking register(CLK_MASK)
void vCKC_Set_Clk_Mask(unsigned int id, unsigned int en)
{
	volatile unsigned int *clkmask_reg = (volatile unsigned int *)(STRG_CLK_MASK_BASE);
	unsigned int field_bit = 0x1;
	if (en)
		(*clkmask_reg) = (*clkmask_reg) | (field_bit << id);
	else
		(*clkmask_reg) = (*clkmask_reg) & ~(field_bit << id);
}

// set Reset masking register(RST_MASK)
void vCKC_Set_Reset_Mask(unsigned int id, unsigned int en)
{
	volatile unsigned int *rstmask_reg = (volatile unsigned int *)(STRG_CLK_RST_BASE);
	unsigned int field_bit = 0x1;

	if (en)
		(*rstmask_reg) = (*rstmask_reg) | (field_bit << id);
	else
		(*rstmask_reg) = (*rstmask_reg) & ~(field_bit << id);
}

