/****************************************************************************
 *
 * Copyright (C) 2016 Telechips Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions
 * andlimitations under the License.
 ****************************************************************************/

#include <platform/iomap.h>
#include <platform/tcc_ckc.h>
#include <platform/ckc_reg.h>
#include <clock.h>
#include <reg.h>
#include <debug.h>
#include <string.h>
#include <div64.h>

/**********************************
 *  Pre Defines
 **********************************/
#define ckc_writel	writel
#define ckc_readl	readl

#define MAX_TCC_PLL	5
#define MAX_CLK_SRC	(MAX_TCC_PLL*2 + 2)	// XIN, XTIN

static uintptr_t	ckc_base = 0;
static uintptr_t	micom_ckc_base = 0;
static uintptr_t	mbusckc_base = 0;
static uintptr_t	iobus_cfg_base = 0;
static uintptr_t	iobus_cfg_base1 = 0;
static uintptr_t	hsiobus_cfg_base = 0;

static uint32_t	stClockSource[MAX_CLK_SRC];
static uint32_t stMicomClockSource[MPLL_MAX];

static inline void tcc_ckc_reset_clock_source(int id);

#define pms_to_val(p, m, s)	((p << DPLL_P_SHIFT) | (m << DPLL_M_SHIFT) | (s << DPLL_S_SHIFT))
#define dcon_to_val(k, mfr, mrr)	((k << DPLL_K_SHIFT) | (mfr << DPLL_MFR_SHIFT) | (mrr << DPLL_MRR_SHIFT))

#if 0
#define MEMPHY_PMS_LIST_MAX 	12
static tPMSValue memphy_list[MEMPHY_PMS_LIST_MAX] = {
	{ 500000000, pms_to_val(3, 250, 2) },
	{ 550000000, pms_to_val(3, 275, 2) },
	{ 600000000, pms_to_val(2, 200, 2) },
	{ 720000000, pms_to_val(2, 240, 2) },
	{ 760000000, pms_to_val(3, 380, 2) },
	{ 800000000, pms_to_val(3, 400, 2) },
	{ 900000000, pms_to_val(2, 150, 1) },
	{ 933000000, pms_to_val(4, 311, 1) },
	{1000000000, pms_to_val(3, 250, 1) },
	{1060000000, pms_to_val(3, 265, 1) },
	{1066000000, pms_to_val(3, 533, 2) },
	{1100000000, pms_to_val(3, 275, 1) },
};
#endif

#define MEMBUS_DPMS_LIST_MAX	4
static tPMSValue membus_list[MEMBUS_DPMS_LIST_MAX] = {
	{ 400000000, pms_to_val(1, 133, 3)},
	{ 500000000, pms_to_val(1,  83, 2)},
	{ 600000000, pms_to_val(1, 100, 2)},
	{ 700000000, pms_to_val(1, 175, 1)},
};

static uint32_t membus_dcon_list[MEMBUS_DPMS_LIST_MAX] = {
	dcon_to_val(21845, 75, 6),
	dcon_to_val(21845, 75, 4),
	dcon_to_val(    0, 75, 4),
	dcon_to_val(21845, 25, 22),
};

/* PLL Configuration Macro */
#define tcc_pll_write(reg,en,p,m,s,src) { \
	if (en) { \
		volatile uint32_t i; \
		ckc_writel((ckc_readl(reg) & (PLL_CHGPUMP_MASK << PLL_CHGPUMP_SHIFT)) \
			|(1<<PLL_LOCKEN_SHIFT) \
			|((src&PLL_SRC_MASK)<<PLL_SRC_SHIFT)|((s&PLL_S_MASK)<<PLL_S_SHIFT) \
			|((m&PLL_M_MASK)<<PLL_M_SHIFT)|((p&PLL_P_MASK)<<PLL_P_SHIFT), reg); \
		/* need to delay at least 1us. */ \
		for (i=100 ; i ; i--);  /* if cpu clokc is 1HGz then loop 100. */ \
		ckc_writel(ckc_readl(reg) | ((en&1)<<PLL_EN_SHIFT), reg); \
		while((ckc_readl(reg)&(1<<PLL_LOCKST_SHIFT))==0); \
	} else \
		ckc_writel(ckc_readl(reg) & ~(1<<PLL_EN_SHIFT), reg); \
}

#define tcc_dckc_pll_write(reg,en,p,m,s) { \
	if (en) { \
		volatile uint32_t i; \
		ckc_writel((ckc_readl(reg) & (PLL_CHGPUMP_MASK << PLL_CHGPUMP_SHIFT)) \
			|(1<<PLL_LOCKEN_SHIFT) \
			|((s&PLL_S_MASK)<<PLL_S_SHIFT) \
			|((m&PLL_M_MASK)<<PLL_M_SHIFT)|((p&PLL_P_MASK)<<PLL_P_SHIFT), reg); \
		for (i=100 ; i ; i--);  /* if cpu clokc is 1HGz then loop 100. */ \
		ckc_writel(ckc_readl(reg) | ((en&1)<<PLL_EN_SHIFT), reg); \
		while((ckc_readl(reg)&(1<<PLL_LOCKST_SHIFT))==0); \
	} else { \
		ckc_writel(ckc_readl(reg) & ~(1<<PLL_EN_SHIFT), reg); \
	} \
}

/* Dedicated CLKCTRL Configuration Macro (CPU0/CPU1/GPU3D/HEVC/BODA/MEM) */
#define tcc_dclkctrl_write(reg,sel) { \
	ckc_writel((sel&DCLKCTRL_SEL_MASK)<<DCLKCTRL_SEL_SHIFT, reg); \
	while(ckc_readl(reg) & (1<<DCLKCTRL_CHGRQ_SHIFT)); \
}


static void tcc_dpll_write(int id, tDPMS *dpms)
{
	uintptr_t pms_reg = ckc_base + CKC_PLLPMS + (id * 4);
	uintptr_t dcon_reg = ckc_base + CKC_PLLCON + (id * 4);
	uintptr_t dmon_reg = ckc_base + CKC_PLLMON + (id * 4);

	if (dpms->en == 1) {
		ckc_writel(0, pms_reg);
		// Configuration DPLLPMS Register
		ckc_writel((dpms->p << DPLL_P_SHIFT) |
			   (dpms->m << DPLL_M_SHIFT) |
			   (dpms->s << DPLL_S_SHIFT) |
			   (dpms->sscg_en << DPLL_SSCG_EN_SHIFT) |
			   (dpms->sel_pf << DPLL_SEL_PF_SHIFT) |
			   (dpms->src << DPLL_SRC_SHIFT), pms_reg);

		// Configuration DPLLCON Register for dithered mode
		if (dpms->sscg_en == 1) {
			ckc_writel((dpms->k << DPLL_K_SHIFT) |
				   (dpms->mfr << DPLL_MFR_SHIFT) |
				   (dpms->mrr << DPLL_MRR_SHIFT), dcon_reg);
		}
		ckc_writel(ckc_readl(dmon_reg) | (1 << DPLL_LOCKEN_SHIFT), dmon_reg);
		ckc_writel(ckc_readl(pms_reg) | (dpms->en << DPLL_EN_SHIFT), pms_reg);

		// Waiting Lock
		while((ckc_readl(dmon_reg) & (1 << DPLL_LOCKST_SHIFT)) == 0);
	}
	else {
		ckc_writel(ckc_readl(pms_reg) & ~((dpms->en & 1) << DPLL_EN_SHIFT), pms_reg);
	}
}

static inline void tcc_pclkctrl_write(uintptr_t reg, uint32_t md,
				      uint32_t en, uint32_t sel,
				      uint32_t div, uint32_t type) 
{
	if (type == PCLKCTRL_TYPE_XXX) {
		ckc_writel(ckc_readl(reg) & ~(1<<PCLKCTRL_OUTEN_SHIFT), reg);
		ckc_writel(ckc_readl(reg) & ~(1<<PCLKCTRL_EN_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(PCLKCTRL_DIV_XXX_MASK<<PCLKCTRL_DIV_SHIFT)) |
				((div&PCLKCTRL_DIV_XXX_MASK)<<PCLKCTRL_DIV_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(PCLKCTRL_SEL_MASK<<PCLKCTRL_SEL_SHIFT)) |
				((sel&PCLKCTRL_SEL_MASK)<<PCLKCTRL_SEL_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(1<<PCLKCTRL_EN_SHIFT))
			| ((en&1)<<PCLKCTRL_EN_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(1<<PCLKCTRL_OUTEN_SHIFT))
			| ((en&1)<<PCLKCTRL_OUTEN_SHIFT), reg);
	} else if (type == PCLKCTRL_TYPE_YYY) {
		ckc_writel(ckc_readl(reg) & ~(1<<PCLKCTRL_EN_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(PCLKCTRL_DIV_YYY_MASK<<PCLKCTRL_DIV_SHIFT)) |
				((div&PCLKCTRL_DIV_YYY_MASK)<<PCLKCTRL_DIV_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(PCLKCTRL_SEL_MASK<<PCLKCTRL_SEL_SHIFT)) |
				((sel&PCLKCTRL_SEL_MASK)<<PCLKCTRL_SEL_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(1<<PCLKCTRL_MD_SHIFT)) |
				((md&1)<<PCLKCTRL_MD_SHIFT), reg);
		ckc_writel((ckc_readl(reg) & ~(1<<PCLKCTRL_EN_SHIFT))
			| ((en&1)<<PCLKCTRL_EN_SHIFT), reg);
	}
}

static inline void tcc_micom_clkctrl_write(uintptr_t reg, uint32_t en,
				     uint32_t config, uint32_t sel)
{
	uint32_t cur_config;

	cur_config = (ckc_readl(reg) >> MCLKCTRL_CONFIG_SHIFT) & MCLKCTRL_CONFIG_MASK;

	if (config >= cur_config) {
		ckc_writel((ckc_readl(reg)&(~(MCLKCTRL_CONFIG_MASK<<MCLKCTRL_CONFIG_SHIFT)))
			   |((config&MCLKCTRL_CONFIG_MASK)<<MCLKCTRL_CONFIG_SHIFT), reg);
		while(ckc_readl(reg) & (1<<MCLKCTRL_CLKCHG_SHIFT));
		ckc_writel((ckc_readl(reg)&(~(MCLKCTRL_SEL_MASK<<MCLKCTRL_SEL_SHIFT)))
			   |((sel&MCLKCTRL_SEL_MASK)<<MCLKCTRL_SEL_SHIFT), reg);
		while(ckc_readl(reg) & (1<<MCLKCTRL_CLKCHG_SHIFT));
	}
	else {
		ckc_writel((ckc_readl(reg)&(~(MCLKCTRL_SEL_MASK<<MCLKCTRL_SEL_SHIFT)))
			   |((sel&MCLKCTRL_SEL_MASK)<<MCLKCTRL_SEL_SHIFT), reg);
		while(ckc_readl(reg) & (1<<MCLKCTRL_CLKCHG_SHIFT));
		ckc_writel((ckc_readl(reg)&(~(MCLKCTRL_CONFIG_MASK<<MCLKCTRL_CONFIG_SHIFT)))
			   |((config&MCLKCTRL_CONFIG_MASK)<<MCLKCTRL_CONFIG_SHIFT), reg);
		while(ckc_readl(reg) & (1<<MCLKCTRL_CLKCHG_SHIFT));
	}
	if (en) {
		ckc_writel((ckc_readl(reg)&(~(1<<MCLKCTRL_EN_SHIFT)))
				|((en&1)<<MCLKCTRL_EN_SHIFT), reg);
		while(ckc_readl(reg) & (1 << MCLKCTRL_DIVSTS_SHIFT));
	}
}

static inline void tcc_clkctrl_write(uintptr_t reg, uint32_t en,
				     uint32_t config, uint32_t sel)
{
	uint32_t cur_config;

	cur_config = (ckc_readl(reg) >> CLKCTRL_CONFIG_SHIFT) & CLKCTRL_CONFIG_MASK;

	if (config >= cur_config) {
		ckc_writel((ckc_readl(reg)&(~(CLKCTRL_CONFIG_MASK<<CLKCTRL_CONFIG_SHIFT)))
			   |((config&CLKCTRL_CONFIG_MASK)<<CLKCTRL_CONFIG_SHIFT), reg);
		while(ckc_readl(reg) & (1<<CLKCTRL_CFGRQ_SHIFT));
		ckc_writel((ckc_readl(reg)&(~(CLKCTRL_SEL_MASK<<CLKCTRL_SEL_SHIFT)))
			   |((sel&CLKCTRL_SEL_MASK)<<CLKCTRL_SEL_SHIFT), reg);
		while(ckc_readl(reg) & (1<<CLKCTRL_CHGRQ_SHIFT));
	}
	else {
		ckc_writel((ckc_readl(reg)&(~(CLKCTRL_SEL_MASK<<CLKCTRL_SEL_SHIFT)))
			   |((sel&CLKCTRL_SEL_MASK)<<CLKCTRL_SEL_SHIFT), reg);
		while(ckc_readl(reg) & (1<<CLKCTRL_CHGRQ_SHIFT));
		ckc_writel((ckc_readl(reg)&(~(CLKCTRL_CONFIG_MASK<<CLKCTRL_CONFIG_SHIFT)))
			   |((config&CLKCTRL_CONFIG_MASK)<<CLKCTRL_CONFIG_SHIFT), reg);
		while(ckc_readl(reg) & (1<<CLKCTRL_CFGRQ_SHIFT));
	}
	ckc_writel((ckc_readl(reg)&(~(1<<CLKCTRL_EN_SHIFT)))
			|((en&1)<<CLKCTRL_EN_SHIFT), reg);
	while(ckc_readl(reg) & (1 << CLKCTRL_CFGRQ_SHIFT));
}

static int tcc_find_pms_table(tPMSValue *table, uint32_t rate, uint32_t max)
{
	uint32_t i;

	for(i = 0; i < max; i++) {
		if(table[i].fpll == rate) {
			return i;
		}
	}

	return -1;
}

inline int tcc_find_pms(tPMS *PLL, uint32_t srcfreq)
{
	uint64_t	u64_pll, u64_src, fvco, srch_p, srch_m, u64_tmp;
	uint32_t srch_pll, err, srch_err;
	int	srch_s;

	if (PLL->fpll ==0) {
		PLL->en = 0;
		return 0;
	}

	u64_pll = (uint64_t)PLL->fpll;
	u64_src = (uint64_t)srcfreq;

	err = 0xFFFFFFFF;
	srch_err = 0xFFFFFFFF;
	for (srch_s=PLL_S_MAX,fvco=(u64_pll<<PLL_S_MAX) ; srch_s >= PLL_S_MIN ; fvco=(u64_pll<<(--srch_s))) {
		if (fvco >= PLL_VCO_MIN && fvco <= PLL_VCO_MAX) {
			for (srch_p=PLL_P_MIN ; srch_p<=PLL_P_MAX ; srch_p++) {
				srch_m = fvco*srch_p;
				do_div(srch_m, srcfreq);
		                if (srch_m < PLL_M_MIN || srch_m > PLL_M_MAX)
		                        continue;
				u64_tmp = srch_m*u64_src;
				do_div(u64_tmp, srch_p);
		                srch_pll = (uint32_t)(u64_tmp>>srch_s);
				if (srch_pll < PLL_MIN_RATE || srch_pll > PLL_MAX_RATE)
					continue;
		                srch_err = (srch_pll > u64_pll) ? srch_pll - u64_pll : u64_pll - srch_pll;
		                if (srch_err < err) {
		                        err = srch_err;
		                        PLL->p = (uint32_t)srch_p;
		                        PLL->m = (uint32_t)srch_m;
					PLL->s = (uint32_t)srch_s;
		                }
			}
		}
	}
	if (err == 0xFFFFFFFF)
		return -1;

	u64_tmp = u64_src*(uint64_t)PLL->m;
	do_div(u64_tmp, PLL->p);
	PLL->fpll = (uint32_t)(u64_tmp>>PLL->s);
	PLL->en = 1;
	return 0;
}

static inline int tcc_find_dithered_pms(tDPMS *PLL, uint32_t srcfreq)
{
	uint64_t	u64_pll, u64_src, fvco, srch_p, srch_m, u64_tmp;
	uint32_t srch_pll, err, srch_err;
	int	srch_s;

	if (PLL->fpll ==0) {
		PLL->en = 0;
		return 0;
	}

	u64_pll = (uint64_t)PLL->fpll;
	u64_src = (uint64_t)srcfreq;

	err = 0xFFFFFFFF;
	srch_err = 0xFFFFFFFF;
	for (srch_s=DPLL_S_MAX,fvco=(u64_pll<<DPLL_S_MAX) ; srch_s >= DPLL_S_MIN ; fvco=(u64_pll<<(--srch_s))) {
		if (fvco >= DPLL_VCO_MIN && fvco <= DPLL_VCO_MAX) {
			for (srch_p=DPLL_P_MIN ; srch_p<=DPLL_P_MAX ; srch_p++) {
				srch_m = fvco*srch_p;
				do_div(srch_m, srcfreq);
		                if (srch_m < DPLL_M_MIN || srch_m > DPLL_M_MAX)
		                        continue;
				u64_tmp = srch_m*u64_src;
				do_div(u64_tmp, srch_p);
		                srch_pll = (uint32_t)(u64_tmp>>srch_s);
				if (srch_pll < DPLL_MIN_RATE || srch_pll > DPLL_MAX_RATE)
					continue;
		                srch_err = (srch_pll > u64_pll) ? srch_pll - u64_pll : u64_pll - srch_pll;
		                if (srch_err < err) {
		                        err = srch_err;
		                        PLL->p = (uint32_t)srch_p;
		                        PLL->m = (uint32_t)srch_m;
					PLL->s = (uint32_t)srch_s;
		                }
			}
		}
	}
	if (err == 0xFFFFFFFF)
		return -1;

	u64_tmp = u64_src*(uint64_t)PLL->m;
	do_div(u64_tmp, PLL->p);
	PLL->fpll = (uint32_t)(u64_tmp>>PLL->s);
	PLL->en = ENABLE;
	return 0;
}

static int tcc_ckc_dedicated_pll_set_rate(uintptr_t reg, uint32_t rate)
{
	tPMS		nPLL;

	nPLL.fpll = rate;

	if (tcc_find_pms(&nPLL, XIN_CLK_RATE))
		goto tcc_ckc_setpll2_failed;
	tcc_dckc_pll_write(reg, nPLL.en, nPLL.p, nPLL.m, nPLL.s);
	return 0;

tcc_ckc_setpll2_failed:
	tcc_dckc_pll_write(reg, 0, PLL_P_MIN, (PLL_P_MIN*PLL_VCO_MIN+XIN_CLK_RATE)/XIN_CLK_RATE, PLL_S_MIN);
	return -1;
}

static uint32_t tcc_ckc_dedicated_pll_get_rate(uintptr_t reg)
{
	uint32_t	reg_values = ckc_readl(reg);
	tPMS		nPLLCFG;
	uint64_t		u64_tmp;

	nPLLCFG.p = (reg_values>>PLL_P_SHIFT)&(PLL_P_MASK);
	nPLLCFG.m = (reg_values>>PLL_M_SHIFT)&(PLL_M_MASK);
	nPLLCFG.s = (reg_values>>PLL_S_SHIFT)&(PLL_S_MASK);
	nPLLCFG.en = (reg_values>>PLL_EN_SHIFT)&(1);
	nPLLCFG.src = (reg_values>>PLL_SRC_SHIFT)&(PLL_SRC_MASK);

	u64_tmp = (uint64_t)XIN_CLK_RATE*(uint64_t)nPLLCFG.m;
	do_div(u64_tmp, nPLLCFG.p);
	return (uint32_t)((u64_tmp)>>nPLLCFG.s);
}

#if (0)
static int tcc_ckc_dedicated_plldiv_set(int id, uint32_t div)
{
	uintptr_t reg;
	uint32_t reg_values = 0;

	switch(id) {
	case FBUS_CPU0:
		reg = cpu0_base + CKC2_CLKDIVC;
		break;
	default:
		return -1;
	}

	if (div)
		reg_values |= ((1<<7)|(div & 0x1F));
	else
		reg_values |= 1;
	ckc_writel(reg_values, reg);

	return 0;
}

static int tcc_ckc_dedicated_plldiv_get(int id)
{
	uintptr_t reg;
	uint32_t reg_values = 0;

	switch(id) {
	case FBUS_CPU0:
		reg = cpu0_base + CKC2_CLKDIVC;
		break;
	default:
		return -1;
	}

	reg_values = ckc_readl(reg) & 0x3F;
	return reg_values;
}
#endif

static int tcc_ckc_is_normal_pll(int id)
{
	int ret = 0;

	if (id >= MAX_TCC_PLL) {
		return -1;
	}

	switch (id) {
	case PLL_0:
	case PLL_1:
	case PLL_DIV_0:
	case PLL_DIV_1:
		ret = 1;
		break;
	default:
		ret = 0;
	}

	return ret;
}

static int tcc_ckc_is_dpll_mode(int id)
{
	uintptr_t reg = 0;
	int ret = 0;

	if (tcc_ckc_is_normal_pll(id) == 1) {
		return 0;
	}

	switch(id) {
	case PLL_2:
	case PLL_DIV_2:
		reg = ckc_base + CKC_PLLPMS + (PLL_2 * 4);
		break;
	case PLL_3:
	case PLL_DIV_3:
		reg = ckc_base + CKC_PLLPMS + (PLL_3 * 4);
		break;
	case PLL_4:
	case PLL_DIV_4:
		reg = ckc_base + CKC_PLLPMS + (PLL_4 * 4);
		break;
	default:
		ret = 0;
	}
	ret = ((ckc_readl(reg) & (1 << DPLL_SSCG_EN_SHIFT)) != 0) ? 1 : 0;

	return ret;
}

static int tcc_ckc_npll_set_val(int id, uint32_t val)
{
	uintptr_t reg = ckc_base + CKC_PLLPMS + (id * 4);
	tPMS nPLL;

	if (tcc_ckc_is_normal_pll(id) != 1) {
		return -1;
	}

	memset(&nPLL, 0x0, sizeof(tPMS));

	nPLL.p = (val >> PLL_P_SHIFT) & PLL_P_MASK;
	nPLL.m = (val >> PLL_M_SHIFT) & PLL_M_MASK;
	nPLL.s = (val >> PLL_S_SHIFT) & PLL_S_MASK;
	nPLL.en = 1;

	tcc_pll_write(reg, nPLL.en, nPLL.p, nPLL.m, nPLL.s, PLLSRC_XIN);
	tcc_ckc_reset_clock_source(id);

	return 0;
}

static int tcc_ckc_dpll_set_val(int id, uint32_t val, uint32_t dcon)
{
	tDPMS dpms;

	if (tcc_ckc_is_normal_pll(id) == 1) {
		return -1;
	}

	memset(&dpms, 0x0, sizeof(tPMS));

	dpms.sscg_en = (val >> DPLL_SSCG_EN_SHIFT) & 0x1;
	dpms.sel_pf = (val >> DPLL_SEL_PF_SHIFT) & DPLL_SEL_PF_MASK;
	dpms.p = (val >> DPLL_P_SHIFT) & DPLL_P_MASK;
	dpms.m = (val >> DPLL_M_SHIFT) & DPLL_M_MASK;
	dpms.s = (val >> DPLL_S_SHIFT) & DPLL_S_MASK;
	dpms.src = PLLSRC_XIN;
	dpms.en = ENABLE;

	if (dpms.sscg_en != 0) {
		dpms.k = (dcon >> DPLL_K_SHIFT) & DPLL_K_MASK;
		dpms.mfr = (dcon >> DPLL_MFR_SHIFT) & DPLL_MFR_MASK;
		dpms.mrr = (dcon >> DPLL_MRR_SHIFT) & DPLL_MRR_MASK;
	}

	tcc_dpll_write(id, &dpms);
	tcc_ckc_reset_clock_source(id);

	return 0;
}

static int tcc_ckc_dpll_set_rate(int id, uint32_t rate)
{
	tDPMS dpms;

	if (tcc_ckc_is_normal_pll(id) == 1) {
		return -1;
	}

	memset(&dpms, 0x0, sizeof(tDPMS));

	dpms.fpll = rate;
	dpms.src = PLLSRC_XIN;
	dpms.sel_pf = DPLL_SEL_CENTER;
	if (tcc_find_dithered_pms(&dpms, XIN_CLK_RATE) != 0) {
		dpms.en = DISABLE;
		tcc_dpll_write(id, &dpms);
		tcc_ckc_reset_clock_source(id);
		return -1;
	}
	tcc_dpll_write(id, &dpms);

	tcc_ckc_reset_clock_source(id);

	return 0;
}

static int tcc_ckc_micom_pll_set_rate(int id, uint32_t rate)
{
        uintptr_t reg = 0;
        uint32_t idx = 0;

        if (id == PLL_MICOM_0) {
                reg = micom_ckc_base + MCKC_PLL0PMS;
                idx = MPLL_0;
        }

        if (id == PLL_MICOM_1) {
                reg = micom_ckc_base + MCKC_PLL1PMS;
                idx = MPLL_1;
        }

        tcc_ckc_dedicated_pll_set_rate(reg, rate);
        stMicomClockSource[idx] = tcc_ckc_dedicated_pll_get_rate(reg);

        return 0;
}

static int tcc_ckc_pll_set_rate(int id, uint32_t rate)
{
	uintptr_t	reg = ckc_base+CKC_PLLPMS+id*4;
	uint32_t	srcfreq = 0;
	uint32_t	src = PLLSRC_XIN;
	tPMS		nPLL;

	if (id == PLL_MICOM_0 || id == PLL_MICOM_1)
		return tcc_ckc_micom_pll_set_rate(id, rate);

	if (id >= MAX_TCC_PLL) {
		return -1;
	}

	if (rate < PLL_MIN_RATE || rate > PLL_MAX_RATE) {
		return -1;
	}

	switch(src) {
	case PLLSRC_XIN:
		srcfreq = XIN_CLK_RATE;
		break;
	case PLLSRC_HDMIXI:
		srcfreq = HDMI_CLK_RATE;
		break;
	case PLLSRC_EXTCLK0:
		srcfreq = EXT0_CLK_RATE;
		break;
	case PLLSRC_EXTCLK1:
		srcfreq = EXT1_CLK_RATE;
		break;
	default:
		goto tcc_ckc_setpll_failed;
	}
	if (srcfreq==0)
		goto tcc_ckc_setpll_failed;

	if (tcc_ckc_is_normal_pll(id) == 1) {
		memset(&nPLL, 0x0, sizeof(tPMS));
		nPLL.fpll = rate;
		if (tcc_find_pms(&nPLL, srcfreq) != 0) {
			goto tcc_ckc_setpll_failed;
		}
		tcc_pll_write(reg, nPLL.en, nPLL.p, nPLL.m, nPLL.s, src);
	}
	else {
		tcc_ckc_dpll_set_rate(id, rate);
		return 0;
	}
	tcc_ckc_reset_clock_source(id);
	return 0;

tcc_ckc_setpll_failed:
	tcc_pll_write(reg, 0, PLL_P_MIN, (PLL_P_MIN*PLL_VCO_MIN+XIN_CLK_RATE)/XIN_CLK_RATE, PLL_S_MIN, src);
	tcc_ckc_reset_clock_source(id);
	return -1;
}

static uint32_t tcc_ckc_pll_get_rate(int id)
{
	uintptr_t	reg = ckc_base+CKC_PLLPMS+id*4;
	//void	*reg = ckc_base+0x40;//)+(id*4);
	uint32_t	reg_values = ckc_readl(reg);
	tPMS		nPLLCFG;
	uint32_t	src_freq;
	uint64_t	u64_tmp;

	/*if (id >= MAX_TCC_PLL)
		return 0;*/

	if (tcc_ckc_is_normal_pll(id) == 1) {
		nPLLCFG.p = (reg_values>>PLL_P_SHIFT)&(PLL_P_MASK);
		nPLLCFG.m = (reg_values>>PLL_M_SHIFT)&(PLL_M_MASK);
		nPLLCFG.s = (reg_values>>PLL_S_SHIFT)&(PLL_S_MASK);
		nPLLCFG.en = (reg_values>>PLL_EN_SHIFT)&(1);
		nPLLCFG.src = (reg_values>>PLL_SRC_SHIFT)&(PLL_SRC_MASK);
	}
	else {
		nPLLCFG.p = (reg_values>>DPLL_P_SHIFT)&(DPLL_P_MASK);
		nPLLCFG.m = (reg_values>>DPLL_M_SHIFT)&(DPLL_M_MASK);
		nPLLCFG.s = (reg_values>>DPLL_S_SHIFT)&(DPLL_S_MASK);
		nPLLCFG.en = (reg_values>>DPLL_EN_SHIFT)&(1);
		nPLLCFG.src = (reg_values>>DPLL_SRC_SHIFT)&(DPLL_SRC_MASK);
	}

	if (nPLLCFG.en == 0)
		return 0;

	switch (nPLLCFG.src) {
	case PLLSRC_XIN:
		src_freq = XIN_CLK_RATE;
		break;
	case PLLSRC_HDMIXI:
		src_freq = HDMI_CLK_RATE;
		break;
	case PLLSRC_EXTCLK0:
		src_freq = EXT0_CLK_RATE;
		break;
	case PLLSRC_EXTCLK1:
		src_freq = EXT1_CLK_RATE;
		break;
	default:
		return 0;
	}

	u64_tmp = (uint64_t)src_freq*(uint64_t)nPLLCFG.m;
	do_div(u64_tmp, nPLLCFG.p);
	return (uint32_t)((u64_tmp)>>nPLLCFG.s);
}

static uint32_t tcc_ckc_plldiv_get_rate(int id)
{
	uintptr_t	reg;
	uint32_t	reg_values;
	uint32_t	offset=0, fpll=0, pdiv=0;

	switch(id) {
	case PLL_0:
	case PLL_1:
	case PLL_2:
	case PLL_3:
		reg = ckc_base+CKC_CLKDIVC;
		offset = (3-id)*8;
		break;
	case PLL_4:
		reg = ckc_base+CKC_CLKDIVC+0x4;
		offset = 24;
		break;
	case PLL_MICOM_0:
	case PLL_MICOM_1:
		reg = micom_ckc_base + MCKC_CLKDIVC;
		offset = (id - PLL_MICOM_1 + 2)*8;
		break;
	default:
		return 0;
	}

	reg_values = ckc_readl(reg);
	if (((reg_values >> offset)&0x80) == 0)	/* check plldivc enable bit */
		return 0;
	pdiv = (reg_values >> offset)&0x3F;

	if (id == PLL_MICOM_0)
		fpll = tcc_ckc_dedicated_pll_get_rate(micom_ckc_base + MCKC_PLL0PMS);
	else if (id == PLL_MICOM_1)
		fpll = tcc_ckc_dedicated_pll_get_rate(micom_ckc_base + MCKC_PLL1PMS);
	else
		fpll = tcc_ckc_pll_get_rate(id);
	if (!pdiv)
		return (uint32_t)fpll;
	else
		return (uint32_t)fpll/(pdiv+1);
}

static int tcc_ckc_pll_div_set(int id, uint32_t div)
{
	uintptr_t	reg;
	uint32_t	reg_values;
	uint32_t	offset=0;

	switch(id) {
	case PLL_0:
	case PLL_1:
	case PLL_2:
	case PLL_3:
		reg = ckc_base+CKC_CLKDIVC;
		offset = (3-id)*8;
		break;
	case PLL_4:
		reg = ckc_base+CKC_CLKDIVC+0x4;
		offset = 24;
		break;
	case PLL_MICOM_0:
	case PLL_MICOM_1:
		reg = micom_ckc_base + MCKC_CLKDIVC;
		offset = (id - PLL_MICOM_1 + 2)*8;
		break;
	default:
		return 0;
	}

	reg_values = ckc_readl(reg) & ~(0xFF<<offset);
	ckc_writel(reg_values, reg);
	if (div)
		reg_values |= (0x80|(div&0x3F))<<offset;
	else
		reg_values |= 1<<offset;
	ckc_writel(reg_values, reg);

	if (id == PLL_MICOM_0)
		stMicomClockSource[MPLL_DIV_0] = tcc_ckc_plldiv_get_rate(id);
	else if (id == PLL_MICOM_1)
		stMicomClockSource[MPLL_DIV_1] = tcc_ckc_plldiv_get_rate(id);
	else
		tcc_ckc_reset_clock_source(id);

	return 0;
}

static inline int tcc_find_micom_clkctrl(tCLKCTRL *CLKCTRL)
{
	uint32_t i, div[MPLL_MAX], err[MPLL_MAX], searchsrc, clk_rate;
	searchsrc = 0xFFFFFFFF;
	uint32_t xin_freq = CLKCTRL->en ? XIN_CLK_RATE/2 : XIN_CLK_RATE;

	if (CLKCTRL->freq <= xin_freq) {
		CLKCTRL->sel = MCLKCTRL_SEL_XIN;
		CLKCTRL->freq = xin_freq;
		CLKCTRL->config = CLKCTRL->en ? 1 : 0;
	}
	else {
		for (i=0 ; i < MPLL_MAX; i++) {
			if (stMicomClockSource[i] == 0)
				continue;
			if (CLKCTRL->en) {
				div[i] = (stMicomClockSource[i]
					+ CLKCTRL->freq-1)/CLKCTRL->freq;
				if (div[i] > (MCLKCTRL_CONFIG_MAX+1))
					div[i] = MCLKCTRL_CONFIG_MAX+1;
				else if (div[i] < (MCLKCTRL_CONFIG_MIN+1))
					div[i] = MCLKCTRL_CONFIG_MIN+1;
				clk_rate = stMicomClockSource[i]/div[i];
			} else
				clk_rate = stMicomClockSource[i];
			if (CLKCTRL->freq < clk_rate)
				continue;
			err[i] = CLKCTRL->freq - clk_rate;
			if (searchsrc == 0xFFFFFFFF)
					searchsrc = i;
			else {
				/* find similar clock */
				if (err[i] < err[searchsrc])
					searchsrc = i;
				/* find even division vlaue */
				else if(err[i] == err[searchsrc]) {
					if (div[i]%2 == 0)
						searchsrc = i;
				}
			}
			if (err[searchsrc] == 0)
				break;
		}
		if (searchsrc == 0xFFFFFFFF)
			return -1;
		switch(searchsrc) {
		case MPLL_0:	CLKCTRL->sel = MCLKCTRL_SEL_PLL0; break;
		case MPLL_1:	CLKCTRL->sel = MCLKCTRL_SEL_PLL1; break;
		case MPLL_DIV_0:	CLKCTRL->sel = MCLKCTRL_SEL_PLL0DIV; break;
		case MPLL_DIV_1:	CLKCTRL->sel = MCLKCTRL_SEL_PLL1DIV; break;
		case MPLL_XIN:	CLKCTRL->sel = MCLKCTRL_SEL_XIN; break;
		default: return -1;
		}
		if (CLKCTRL->en) {
			if (div[searchsrc] > (MCLKCTRL_CONFIG_MAX+1))
				div[searchsrc] = MCLKCTRL_CONFIG_MAX+1;
			else if (div[searchsrc] <= MCLKCTRL_CONFIG_MIN)
				div[searchsrc] = MCLKCTRL_CONFIG_MIN+1;
			CLKCTRL->freq = stMicomClockSource[searchsrc]/div[searchsrc];
			CLKCTRL->config = div[searchsrc] - 1;
		} else {
			CLKCTRL->freq = stMicomClockSource[searchsrc];
			CLKCTRL->config = 0;
		}
	}
	return 0;
}

static inline int tcc_find_clkctrl(tCLKCTRL *CLKCTRL)
{
	uint32_t i, div[MAX_CLK_SRC], err[MAX_CLK_SRC], searchsrc, clk_rate;
	searchsrc = 0xFFFFFFFF;

	if (CLKCTRL->freq <= (XIN_CLK_RATE/2)) {
		CLKCTRL->sel = CLKCTRL_SEL_XIN;
		CLKCTRL->freq = XIN_CLK_RATE/2;
		CLKCTRL->config = 1;
	}
	else {
		for (i=0 ; i<MAX_CLK_SRC ; i++) {
			if (stClockSource[i] == 0)
				continue;
			div[i] = (stClockSource[i]+CLKCTRL->freq-1)/CLKCTRL->freq;
			if (div[i] > (CLKCTRL_CONFIG_MAX+1))
				div[i] = CLKCTRL_CONFIG_MAX+1;
			else if (div[i] < (CLKCTRL_CONFIG_MIN+1))
				div[i] = CLKCTRL_CONFIG_MIN+1;
			clk_rate = stClockSource[i]/div[i];
			if (CLKCTRL->freq < clk_rate)
				continue;
			err[i] = CLKCTRL->freq - clk_rate;
			if (searchsrc == 0xFFFFFFFF)
				searchsrc = i;
			else {
				/* find similar clock */
				if (err[i] < err[searchsrc])
					searchsrc = i;
				/* find even division vlaue */
				else if(err[i] == err[searchsrc]) {
					if (div[i]%2 == 0)
						searchsrc = i;
				}
			}
			if (err[searchsrc] == 0)
				break;
		}
		if (searchsrc == 0xFFFFFFFF)
			return -1;
		switch(searchsrc) {
		case PLL_0:	CLKCTRL->sel = CLKCTRL_SEL_PLL0; break;
		case PLL_1:	CLKCTRL->sel = CLKCTRL_SEL_PLL1; break;
		case PLL_2:	CLKCTRL->sel = CLKCTRL_SEL_PLL2; break;
		case PLL_3:	CLKCTRL->sel = CLKCTRL_SEL_PLL3; break;
		case PLL_4:	CLKCTRL->sel = CLKCTRL_SEL_PLL4; break;
		case PLL_DIV_0:	CLKCTRL->sel = CLKCTRL_SEL_PLL0DIV; break;
		case PLL_DIV_1:	CLKCTRL->sel = CLKCTRL_SEL_PLL1DIV; break;
		case PLL_DIV_2:	CLKCTRL->sel = CLKCTRL_SEL_PLL2DIV; break;
		case PLL_DIV_3:	CLKCTRL->sel = CLKCTRL_SEL_PLL3DIV; break;
		case PLL_DIV_4:	CLKCTRL->sel = CLKCTRL_SEL_PLL4DIV; break;
		case PLL_XIN:	CLKCTRL->sel = CLKCTRL_SEL_XIN; break;
		default: return -1;
		}
		if (div[searchsrc] > (CLKCTRL_CONFIG_MAX+1))
			div[searchsrc] = CLKCTRL_CONFIG_MAX+1;
		else if (div[searchsrc] <= CLKCTRL_CONFIG_MIN)
			div[searchsrc] = CLKCTRL_CONFIG_MIN+1;
		CLKCTRL->freq = stClockSource[searchsrc]/div[searchsrc];
		CLKCTRL->config = div[searchsrc] - 1;
	}
	return 0;
}

/*static int tcc_ckc_is_clkctrl_enabled(int id)
{
	uintptr_t	reg = ckc_base+CKC_CLKCTRL+id*4;
	uintptr_t	reg_dckc_pll = NULL;

	switch (id) {
		case FBUS_CPU0:
			return 1;
		case FBUS_CPU1:
			if ((ckc_readl(cpubus_cfg_base + 0x4) & (1<<17)) == 0)
				return 0;
			return 1;
		case FBUS_MEM:
		case FBUS_MEM_PHY:
			return 1;
		case FBUS_GPU:
			reg_dckc_pll = gpu_3d_base;
			break;
	}

	if (reg_dckc_pll)
		return (ckc_readl(reg_dckc_pll+DCKC_PLLPMS) & (1<<PLL_EN_SHIFT)) ? 1 : 0;

	return (ckc_readl(reg) & (1<<CLKCTRL_EN_SHIFT)) ? 1 : 0;
}*/

static int tcc_ckc_clkctrl_enable(int id)
{
	uintptr_t	reg = ckc_base+CKC_CLKCTRL+id*4;

	switch (id) {
		case FBUS_CBUS:
		case FBUS_CMBUS:
		case FBUS_MEM:
		case FBUS_HSIO:
		case FBUS_SMU:
		case FBUS_DDI:
		case FBUS_IO:
			break;
		default:
			return 0;
	}
	ckc_writel(ckc_readl(reg) | (1<<CLKCTRL_EN_SHIFT), reg);
	while (ckc_readl(reg) & (1<<CLKCTRL_CFGRQ_SHIFT));

	return 0;
}

static int tcc_ckc_clkctrl_disable(int id)
{
	uintptr_t	reg = ckc_base+CKC_CLKCTRL+id*4;

	switch (id) {
		case FBUS_CBUS:
		case FBUS_CMBUS:
		case FBUS_MEM:
		case FBUS_HSIO:
		case FBUS_SMU:
		case FBUS_DDI:
		case FBUS_IO:
			break;
		default:
			return 0;
	}
	ckc_writel(ckc_readl(reg) & ~(1<<CLKCTRL_EN_SHIFT), reg);
	return 0;
}

/*static int tcc_ckc_is_dclkctrl(int id)
{
	int ret = 0;

	switch (id) {
	case FBUS_CPU0:
	case FBUS_CPU1:
	case FBUS_VBUS:
	case FBUS_BODA:
	case FBUS_CHEVC:
	case FBUS_BHEVC:
	case FBUS_MEM_PHY:
		ret = 1;
		break;
	default :
		ret = 0;
	}

	return ret;
}*/

static int tcc_ckc_micom_clkctrl_set_rate(int id, uint32_t rate)
{
	uintptr_t	reg = micom_ckc_base+MCKC_CLKCTRL+(id - FBUS_MICOM_CPU)*4;
	tCLKCTRL	nCLKCTRL;

	nCLKCTRL.en = (ckc_readl(reg) & (1<<MCLKCTRL_EN_SHIFT)) ? 1 : 0;

	nCLKCTRL.freq = rate;
	if (tcc_find_micom_clkctrl(&nCLKCTRL))
		return -1;

	tcc_micom_clkctrl_write(reg, nCLKCTRL.en, nCLKCTRL.config, nCLKCTRL.sel);
	return 0;
}

static int tcc_ckc_clkctrl_set_rate(int id, uint32_t rate)
{
	uintptr_t	reg = ckc_base+CKC_CLKCTRL+id*4;
	tCLKCTRL	nCLKCTRL;

	if (id == FBUS_MICOM_CPU)
		return tcc_ckc_micom_clkctrl_set_rate(id, rate);

	nCLKCTRL.en = (ckc_readl(reg) & (1<<CLKCTRL_EN_SHIFT)) ? 1 : 0;

	nCLKCTRL.freq = rate;
	if (tcc_find_clkctrl(&nCLKCTRL))
		return -1;

	tcc_clkctrl_write(reg, nCLKCTRL.en, nCLKCTRL.config, nCLKCTRL.sel);
	return 0;
}

static uint32_t tcc_ckc_clkctrl_get_rate(int id)
{
	uintptr_t	reg = ckc_base+CKC_CLKCTRL+id*4;
	uint32_t	reg_values = ckc_readl(reg);
	tCLKCTRL	nCLKCTRL;
	uint32_t	src_freq = 0;

	switch (id) {
		case FBUS_CBUS:
		case FBUS_HSIO:
		case FBUS_SMU:
		case FBUS_IO:
		case FBUS_MEM:
		case FBUS_CMBUS:
			break;
		default:
			return 0;
	}

	nCLKCTRL.sel = (reg_values & (CLKCTRL_SEL_MASK<<CLKCTRL_SEL_SHIFT))>>CLKCTRL_SEL_SHIFT;
	switch (nCLKCTRL.sel) {
		case CLKCTRL_SEL_PLL0:
			src_freq = tcc_ckc_pll_get_rate(PLL_0);
			break;
		case CLKCTRL_SEL_PLL1:
			src_freq = tcc_ckc_pll_get_rate(PLL_1);
			break;
		case CLKCTRL_SEL_PLL2:
			src_freq = tcc_ckc_pll_get_rate(PLL_2);
			break;
		case CLKCTRL_SEL_PLL3:
			src_freq = tcc_ckc_pll_get_rate(PLL_3);
			break;
		case CLKCTRL_SEL_PLL4:
			src_freq = tcc_ckc_pll_get_rate(PLL_4);
			break;
		case CLKCTRL_SEL_XIN:
			src_freq = XIN_CLK_RATE;
			break;
		case CLKCTRL_SEL_XTIN:
			src_freq = XTIN_CLK_RATE;
			break;
		case CLKCTRL_SEL_PLL0DIV:
			src_freq = tcc_ckc_plldiv_get_rate(PLL_0);
			break;
		case CLKCTRL_SEL_PLL1DIV:
			src_freq = tcc_ckc_plldiv_get_rate(PLL_1);
			break;
		case CLKCTRL_SEL_PLL2DIV:
			src_freq = tcc_ckc_plldiv_get_rate(PLL_2);
			break;
		case CLKCTRL_SEL_PLL3DIV:
			src_freq = tcc_ckc_plldiv_get_rate(PLL_3);
			break;
		case CLKCTRL_SEL_PLL4DIV:
			src_freq = tcc_ckc_plldiv_get_rate(PLL_4);
			break;
		case CLKCTRL_SEL_XINDIV:
		case CLKCTRL_SEL_XTINDIV:
		case CLKCTRL_SEL_EXTIN2:
		case CLKCTRL_SEL_EXTIN3:
		default: return 0;
	}

	nCLKCTRL.config = (reg_values & (CLKCTRL_CONFIG_MASK<<CLKCTRL_CONFIG_SHIFT))>>CLKCTRL_CONFIG_SHIFT;
	nCLKCTRL.freq = src_freq / (nCLKCTRL.config+1);

	return (uint32_t)nCLKCTRL.freq;
}

static int tcc_ckc_set_memphy(uint32_t rate)
{
	int ret;

	ret = tcc_ckc_clkctrl_set_rate(FBUS_MEM_SUB, rate);
	if (ret != 0) {
		return ret;
	}

	return 0;
}

static int tcc_ckc_set_membus(uint32_t rate, int mode)
{
	int idx;
	uint32_t pms, dcon;

	idx = tcc_find_pms_table(membus_list, rate, MEMBUS_DPMS_LIST_MAX);
	if (idx == -1) {
		tcc_ckc_pll_set_rate(MEMBUS_PLL, rate);
	}
	else {
		dcon = membus_dcon_list[idx];
		pms = membus_list[idx].pms;
		if (mode == DPLL_DITHERED_MODE) {
			pms |= (1 << DPLL_SSCG_EN_SHIFT);
		}
		tcc_ckc_dpll_set_val(MEMBUS_PLL, pms, dcon);
	}

	return 0;
}

static inline uint32_t tcc_pclk_support_below_freq(uint32_t periname)
{
	if ((periname == PERI_SDMMC0) || (periname == PERI_SDMMC1)
	 || (periname == PERI_SDMMC2)) {
	 	/* calc. freq. must be below(same or under) value */
	 	return 1;
	}

	return 0;
}

static inline uint32_t tcc_ckc_pclk_divider(tPCLKCTRL *PCLKCTRL, uint32_t *div,
	const uint32_t src_CLK, uint32_t div_min, uint32_t div_max)
{
	uint32_t	clk_rate1, clk_rate2, err1, err2;

	if (src_CLK <= PCLKCTRL->freq)
		*div = 1;
	else
		*div = src_CLK/PCLKCTRL->freq;

	if (*div > div_max)
		*div = div_max;

	clk_rate1 = src_CLK/(*div);
	clk_rate2 = src_CLK/((*div < div_max) ? (*div+1) : *div);
	if (tcc_pclk_support_below_freq(PCLKCTRL->periname)) {
		err1 = (clk_rate1 > PCLKCTRL->freq)?0xFFFFFFFF:(PCLKCTRL->freq - clk_rate1);
		err2 = (clk_rate2 > PCLKCTRL->freq)?0xFFFFFFFF:(PCLKCTRL->freq - clk_rate2);
	}
	else {
		err1 = (clk_rate1 > PCLKCTRL->freq)?(clk_rate1 - PCLKCTRL->freq):(PCLKCTRL->freq - clk_rate1);
		err2 = (clk_rate2 > PCLKCTRL->freq)?(clk_rate2 - PCLKCTRL->freq):(PCLKCTRL->freq - clk_rate2);
	}

	if (err1 > err2)
		*div += 1;

	return (err1 < err2) ? err1 : err2;
}

static inline uint32_t tcc_ckc_pclk_dco(	tPCLKCTRL *PCLKCTRL, uint32_t *div,
	const uint32_t src_CLK, uint32_t div_min, uint32_t div_max)
{
	uint32_t	clk_rate1, clk_rate2, err1, err2;
	uint64_t u64_tmp;

	if (src_CLK < PCLKCTRL->freq)
		return 0xFFFFFFFF;

	u64_tmp = (uint64_t)(PCLKCTRL->freq)*(uint64_t)div_max;
	do_div(u64_tmp,src_CLK);
	*div = (uint32_t)u64_tmp;

	if (*div > (div_max+1)/2)
		return 0xFFFFFFFF;

	u64_tmp = (uint64_t)src_CLK*(uint64_t)(*div);
	do_div(u64_tmp,(div_max+1));
	clk_rate1 = (uint32_t)u64_tmp;
	u64_tmp = (uint64_t)src_CLK*(uint64_t)(*div+1);
	do_div(u64_tmp,(div_max+1));
	clk_rate2 = (uint32_t)u64_tmp;

	err1 = (clk_rate1 > PCLKCTRL->freq) ? clk_rate1 - PCLKCTRL->freq : PCLKCTRL->freq - clk_rate1;
	err2 = (clk_rate2 > PCLKCTRL->freq) ? clk_rate2 - PCLKCTRL->freq : PCLKCTRL->freq - clk_rate2;
	if (err1 > err2)
		*div += 1;

	return (err1 < err2) ? err1 : err2;
}

static inline int tcc_find_pclk(tPCLKCTRL *PCLKCTRL, tPCLKTYPE type)
{
	int i;
	uint32_t div_max, searchsrc, err_dco, err_div, md;
	uint32_t div[MAX_CLK_SRC], err[MAX_CLK_SRC];
	uint32_t div_dco = PCLKCTRL_DIV_DCO_MIN;
	uint32_t div_div = PCLKCTRL_DIV_MIN;

	switch (type) {
	case PCLKCTRL_TYPE_XXX:
		PCLKCTRL->md = PCLKCTRL_MODE_DIVIDER;
		div_max = PCLKCTRL_DIV_XXX_MAX;
		break;
	case PCLKCTRL_TYPE_YYY:
		PCLKCTRL->md = PCLKCTRL_MODE_DCO;
		div_max = PCLKCTRL_DIV_YYY_MAX;
		break;
	default:
		return -1;
	}

	searchsrc = 0xFFFFFFFF;
	for (i=(MAX_CLK_SRC-1) ; i>=0 ; i--) {
		if (tcc_ckc_is_dpll_mode(i) == 1) {
			continue;
		}
		if (stClockSource[i] == 0) {
			continue;
		}
		if ((stClockSource[i] >= PCLKCTRL_MAX_FCKS) && (type == PCLKCTRL_TYPE_XXX)) {
			continue;
		}

		/* dco mode */
		if (type == PCLKCTRL_TYPE_XXX)
			err_dco = 0xFFFFFFFF;
		else {
			// DO NOT USE XIN, XTIN In DCO Mode
			if(i >= MAX_TCC_PLL * 2)
				continue;
			if((PCLKCTRL->periname == PERI_MSPDIF0)||(PCLKCTRL->periname == PERI_MSPDIF1))
				err_dco = 0xFFFFFFFF;
			else
				err_dco = tcc_ckc_pclk_dco(PCLKCTRL, &div_dco, stClockSource[i], PCLKCTRL_DIV_DCO_MIN, div_max);
		}

		/* divider mode */
		err_div = tcc_ckc_pclk_divider(PCLKCTRL, &div_div, stClockSource[i], PCLKCTRL_DIV_MIN+1, div_max+1);

		/* common */
		if (err_dco < err_div) {
			err[i] = err_dco;
			div[i] = div_dco;
			md = PCLKCTRL_MODE_DCO;
		}
		else {
			err[i] = err_div;
			div[i] = div_div;
			md = PCLKCTRL_MODE_DIVIDER;
		}

		if (searchsrc == 0xFFFFFFFF) {
			searchsrc = i;
			PCLKCTRL->md = md;
		}
		else {
			/* find similar clock */
			if (err[i] < err[searchsrc]) {
				searchsrc = i;
				PCLKCTRL->md = md;
			}
			else if ((err[i] == err[searchsrc]) && (md == PCLKCTRL_MODE_DIVIDER)) {
				searchsrc = i;
				PCLKCTRL->md = md;
			}
			// If err_dco is the same with before search source,
			// Use more lower dco divider source.
			else if ((err[i] == err[searchsrc]) && (div[i] < div[searchsrc])) {
				searchsrc = i;
				PCLKCTRL->md = md;
			}
		}

	}

	switch(searchsrc) {
	case PLL_0:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL0; break;
	case PLL_1:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL1; break;
	case PLL_2:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL2; break;
	case PLL_3:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL3; break;
	case PLL_4:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL4; break;
	case PLL_DIV_0:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL0DIV; break;
	case PLL_DIV_1:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL1DIV; break;
	case PLL_DIV_2:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL2DIV; break;
	case PLL_DIV_3:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL3DIV; break;
	case PLL_DIV_4:	PCLKCTRL->sel = PCLKCTRL_SEL_PLL4DIV; break;
	case PLL_XIN:	PCLKCTRL->sel = PCLKCTRL_SEL_XIN; break;
	case PLL_XTIN:	PCLKCTRL->sel = PCLKCTRL_SEL_XTIN; break;
	default: return -1;
	}

	if (PCLKCTRL->md == PCLKCTRL_MODE_DCO) {
		uint64_t u64_tmp;
		PCLKCTRL->div = div[searchsrc];
		if (PCLKCTRL->div > div_max/2)
			u64_tmp = (uint64_t)stClockSource[searchsrc]*(uint64_t)(div_max-PCLKCTRL->div);
		else
			u64_tmp = (uint64_t)stClockSource[searchsrc]*(uint64_t)PCLKCTRL->div;
		do_div(u64_tmp,div_max);
		PCLKCTRL->freq = (uint32_t)u64_tmp;

		if ((PCLKCTRL->div < PCLKCTRL_DIV_DCO_MIN) || (PCLKCTRL->div > (div_max-1)))
			return -1;
	}
	else { /* Divider mode */
		PCLKCTRL->div = div[searchsrc];
		if (PCLKCTRL->div >= (PCLKCTRL_DIV_MIN+1) && PCLKCTRL->div <= (div_max+1))
			PCLKCTRL->div -= 1;
		else
			return -1;
		PCLKCTRL->freq = stClockSource[searchsrc]/(PCLKCTRL->div+1);
	}
	return 0;
}

static inline tPCLKTYPE tcc_check_pclk_type(uint32_t periname)
{
	switch (periname) {
		case PERI_MDAI0:
		case PERI_MSPDIF0:
		case PERI_MDAI1:
		case PERI_MSPDIF1:
		case PERI_MDAI2:
		case PERI_MSPDIF2:
		case PERI_AUX0_INPUT:
		case PERI_AUX1_INPUT:
		case PERI_AUX0_OUTPUT:
		case PERI_AUX1_OUTPUT:
		case PERI_TSRX0:
		case PERI_TSRX1:
		case PERI_TSRX2:
		case PERI_TSRX3:
		case PERI_TSRX4:
		case PERI_TSRX5:
		case PERI_TSRX6:
		case PERI_TSRX7:
		case PERI_TSRX8:
			return PCLKCTRL_TYPE_YYY;
	}
	return PCLKCTRL_TYPE_XXX;
}

static int tcc_ckc_peri_enable(int id)
{
	uintptr_t	reg = ckc_base+CKC_PCLKCTRL+id*4;
	ckc_writel(ckc_readl(reg) | 1<<PCLKCTRL_EN_SHIFT, reg);
	if (tcc_check_pclk_type(id) == PCLKCTRL_TYPE_XXX)
		ckc_writel(ckc_readl(reg) | 1<<PCLKCTRL_OUTEN_SHIFT, reg);

	return 0;
}

#if (0)
static int tcc_ckc_peri_disable(int id)
{
	uintptr_t	reg = ckc_base+CKC_PCLKCTRL+id*4;
	if (tcc_check_pclk_type(id) == PCLKCTRL_TYPE_XXX)
		ckc_writel(ckc_readl(reg) & ~(1<<PCLKCTRL_OUTEN_SHIFT), reg);
	ckc_writel(ckc_readl(reg) & ~(1<<PCLKCTRL_EN_SHIFT), reg);

	return 0;
}
#endif

static int tcc_micom_find_pclk(tPCLKCTRL *PCLKCTRL, tPCLKTYPE type)
{
	int i;
	uint32_t div_max, searchsrc, err_div, md;
	uint32_t div[MPLL_MAX], err[MPLL_MAX];
	uint32_t div_div = PCLKCTRL_DIV_MIN;

	PCLKCTRL->md = PCLKCTRL_MODE_DIVIDER;
	div_max = PCLKCTRL_DIV_XXX_MAX;

	searchsrc = 0xFFFFFFFF;
	for (i = MPLL_MAX -1; i >= 0; i--) {
		if (stMicomClockSource[i] == 0) {
			continue;
		}
		if ((stMicomClockSource[i] >= PCLKCTRL_MAX_FCKS) && (type == PCLKCTRL_TYPE_XXX)) {
			continue;
		}

		/* divider mode */
		err_div = tcc_ckc_pclk_divider(PCLKCTRL, &div_div, stMicomClockSource[i], PCLKCTRL_DIV_MIN+1, div_max+1);

		err[i] = err_div;
		div[i] = div_div;
		md = PCLKCTRL_MODE_DIVIDER;

		if (searchsrc == 0xFFFFFFFF) {
			searchsrc = i;
			PCLKCTRL->md = md;
		}
		else {
			/* find similar clock */
			if (err[i] < err[searchsrc]) {
				searchsrc = i;
				PCLKCTRL->md = md;
			}
		}
	}

	switch(searchsrc) {
	case MPLL_0:	PCLKCTRL->sel = MPCLKCTRL_SEL_PLL0; break;
	case MPLL_1:	PCLKCTRL->sel = MPCLKCTRL_SEL_PLL1; break;
	case MPLL_DIV_0:	PCLKCTRL->sel = MPCLKCTRL_SEL_PLL0DIV; break;
	case MPLL_DIV_1:	PCLKCTRL->sel = MPCLKCTRL_SEL_PLL1DIV; break;
	case MPLL_XIN:	PCLKCTRL->sel = MPCLKCTRL_SEL_XIN; break;
	default: return -1;
	}

	PCLKCTRL->div = div[searchsrc];
	if (PCLKCTRL->div >= (PCLKCTRL_DIV_MIN+1) && PCLKCTRL->div <= (div_max+1))
		PCLKCTRL->div -= 1;
	else
		return -1;
	PCLKCTRL->freq = stMicomClockSource[searchsrc]/(PCLKCTRL->div+1);

	return 0;
}

static int tcc_ckc_micom_peri_set_rate(int id, uint32_t rate)
{
	uintptr_t	reg = micom_ckc_base+MCKC_PCLKCTRL+(id - PERI_MICOM_SFMC) * 4;
	tPCLKCTRL	nPCLKCTRL;

	nPCLKCTRL.freq = rate;
	nPCLKCTRL.periname = id;
	nPCLKCTRL.div = 0;
	nPCLKCTRL.md = PCLKCTRL_MODE_DIVIDER;
	nPCLKCTRL.sel = PCLKCTRL_SEL_XIN;

	if (tcc_micom_find_pclk(&nPCLKCTRL, PCLKCTRL_TYPE_XXX))
		goto tcc_ckc_setperi_failed;

	nPCLKCTRL.en = (ckc_readl(reg) & (1<<PCLKCTRL_EN_SHIFT)) ? 1 : 0;

	tcc_pclkctrl_write(reg, nPCLKCTRL.md, nPCLKCTRL.en, nPCLKCTRL.sel, nPCLKCTRL.div, PCLKCTRL_TYPE_XXX);

	return 0;

tcc_ckc_setperi_failed:
	tcc_pclkctrl_write(reg, PCLKCTRL_MODE_DIVIDER, CKC_DISABLE, PCLKCTRL_SEL_XIN, 1, PCLKCTRL_TYPE_XXX);
	return -1;
}

static int tcc_ckc_peri_set_rate(int id, uint32_t rate)
{
	uintptr_t	reg = ckc_base+CKC_PCLKCTRL+id*4;
	tPCLKCTRL	nPCLKCTRL;
	tPCLKTYPE	type = tcc_check_pclk_type(id);

	if (id >= PERI_MICOM_SFMC && id < PERI_MICOM_MAX) {
		tcc_ckc_micom_peri_set_rate(id, rate);
		return 0;
	}
	nPCLKCTRL.freq = rate;
	nPCLKCTRL.periname = id;
	nPCLKCTRL.div = 0;
	nPCLKCTRL.md = PCLKCTRL_MODE_DCO;
	nPCLKCTRL.sel = PCLKCTRL_SEL_XIN;

	/* if input rate are 27(dummy value for set HDMIPCLK) then set the lcdc pclk source to HDMIPCLK */
	if (((nPCLKCTRL.periname == PERI_LCD0) || (nPCLKCTRL.periname == PERI_LCD1))
			&& (nPCLKCTRL.freq == HDMI_PCLK_RATE)) {
		nPCLKCTRL.sel = PCLKCTRL_SEL_HDMIPCLK;
		nPCLKCTRL.div = 0;
		nPCLKCTRL.md = PCLKCTRL_MODE_DIVIDER;
		nPCLKCTRL.freq = HDMI_PCLK_RATE;
	}
	else {
		if (tcc_find_pclk(&nPCLKCTRL, type))
			goto tcc_ckc_setperi_failed;
	}

	nPCLKCTRL.en = (ckc_readl(reg) & (1<<PCLKCTRL_EN_SHIFT)) ? 1 : 0;

	tcc_pclkctrl_write(reg, nPCLKCTRL.md, nPCLKCTRL.en, nPCLKCTRL.sel, nPCLKCTRL.div, type);

	return 0;

tcc_ckc_setperi_failed:
	tcc_pclkctrl_write(reg, PCLKCTRL_MODE_DIVIDER, CKC_DISABLE, PCLKCTRL_SEL_XIN, 1, type);
	return -1;
}

static uint32_t tcc_ckc_peri_get_rate(int id)
{
	uintptr_t	reg = ckc_base+CKC_PCLKCTRL+id*4;
	uint32_t	reg_values = ckc_readl(reg);
	tPCLKCTRL	nPCLKCTRL;
	tPCLKTYPE	type = tcc_check_pclk_type(id);
	uint32_t	src_freq = 0, div_mask;

	nPCLKCTRL.md = reg_values & (1<<PCLKCTRL_MD_SHIFT) ? PCLKCTRL_MODE_DIVIDER : PCLKCTRL_MODE_DCO;
	nPCLKCTRL.sel = (reg_values&(PCLKCTRL_SEL_MASK<<PCLKCTRL_SEL_SHIFT))>>PCLKCTRL_SEL_SHIFT;
	switch(nPCLKCTRL.sel) {
	case PCLKCTRL_SEL_PLL0:
		src_freq = tcc_ckc_pll_get_rate(PLL_0);
		break;
	case PCLKCTRL_SEL_PLL1:
		src_freq = tcc_ckc_pll_get_rate(PLL_1);
		break;
	case PCLKCTRL_SEL_PLL2:
		src_freq = tcc_ckc_pll_get_rate(PLL_2);
		break;
	case PCLKCTRL_SEL_PLL3:
		src_freq = tcc_ckc_pll_get_rate(PLL_3);
		break;
	case PCLKCTRL_SEL_PLL4:
		src_freq = tcc_ckc_pll_get_rate(PLL_4);
		break;
	case PCLKCTRL_SEL_XIN:
		src_freq = XIN_CLK_RATE;
		break;
	case PCLKCTRL_SEL_XTIN:
		src_freq = XTIN_CLK_RATE;
		break;
	case PCLKCTRL_SEL_PLL0DIV:
		src_freq = tcc_ckc_plldiv_get_rate(PLL_0);
		break;
	case PCLKCTRL_SEL_PLL1DIV:
		src_freq = tcc_ckc_plldiv_get_rate(PLL_1);
		break;
	case PCLKCTRL_SEL_PLL2DIV:
		src_freq = tcc_ckc_plldiv_get_rate(PLL_2);
		break;
	case PCLKCTRL_SEL_PLL3DIV:
		src_freq = tcc_ckc_plldiv_get_rate(PLL_3);
		break;
	case PCLKCTRL_SEL_PLL4DIV:
		src_freq = tcc_ckc_plldiv_get_rate(PLL_4);
		break;
	case PCLKCTRL_SEL_PCIPHY_CLKOUT:
	case PCLKCTRL_SEL_HDMITMDS:
	case PCLKCTRL_SEL_HDMIPCLK:
	case PCLKCTRL_SEL_HDMIXIN:
	case PCLKCTRL_SEL_XINDIV:
	case PCLKCTRL_SEL_XTINDIV:
	case PCLKCTRL_SEL_EXTCLK0:
	case PCLKCTRL_SEL_EXTCLK1:
	default :
		return 0;
	}

	switch (type) {
	case PCLKCTRL_TYPE_XXX:
		div_mask = PCLKCTRL_DIV_XXX_MASK;
		nPCLKCTRL.md = PCLKCTRL_MODE_DIVIDER;
		break;
	case PCLKCTRL_TYPE_YYY:
		div_mask = PCLKCTRL_DIV_YYY_MASK;
		break;
	default:
		return 0;
	}
	nPCLKCTRL.freq = 0;
	nPCLKCTRL.div = (reg_values&(div_mask<<PCLKCTRL_DIV_SHIFT))>>PCLKCTRL_DIV_SHIFT;
	if (nPCLKCTRL.md == PCLKCTRL_MODE_DIVIDER)
		nPCLKCTRL.freq = src_freq/(nPCLKCTRL.div+1);
	else {
		uint64_t u64_tmp;
		if (nPCLKCTRL.div > (div_mask+1)/2)
			u64_tmp = (uint64_t)src_freq*(uint64_t)((div_mask+1)-nPCLKCTRL.div);
		else
			u64_tmp = (uint64_t)src_freq*(uint64_t)nPCLKCTRL.div;
		do_div(u64_tmp ,div_mask+1);
		nPCLKCTRL.freq = (uint32_t)u64_tmp;
	}
	return (uint32_t)nPCLKCTRL.freq;
}

static inline void tcc_ckc_reset_clock_source(int id)
{
	if (id >= MAX_CLK_SRC)
		return;

	if (id < MAX_TCC_PLL) {
		stClockSource[id] = tcc_ckc_pll_get_rate(id);
		stClockSource[MAX_TCC_PLL+id] = tcc_ckc_plldiv_get_rate(id);
	}
}

static int tcc_ckc_iobus_pwdn(int id, bool pwdn)
{
	uintptr_t ckc_reg = ckc_base+CKC_CLKCTRL+(FBUS_IO*0x4);
	uintptr_t reg;

	if ((ckc_readl(ckc_reg) & (1<<CLKCTRL_EN_SHIFT)) == 0)
		return -2;

	if      (id < 32*1)
		reg = iobus_cfg_base+IOBUS_PWDN0;
	else if (id < 32*2)
		reg = iobus_cfg_base+IOBUS_PWDN1;
	else if (id < 32*3)
		reg = iobus_cfg_base+IOBUS_PWDN2;
	else if (id < 32*4)
		reg = iobus_cfg_base1+IOBUS_PWDN3;
	else
		return -1;

	id %= 32;

	if (pwdn)
		ckc_writel(ckc_readl(reg) & ~(1<<id), reg);
	else
		ckc_writel(ckc_readl(reg) | (1<<id), reg);

	return 0;
}

static int tcc_ckc_iobus_swreset(int id, bool reset)
{
	uintptr_t ckc_reg = ckc_base+CKC_CLKCTRL+(FBUS_IO*0x4);
	uintptr_t reg;

	if ((ckc_readl(ckc_reg) & (1<<CLKCTRL_EN_SHIFT)) == 0)
		return -2;

	if      (id < 32*1)
		reg = iobus_cfg_base+IOBUS_RESET0;
	else if (id < 32*2)
		reg = iobus_cfg_base+IOBUS_RESET1;
	else if (id < 32*3)
		reg = iobus_cfg_base+IOBUS_RESET2;
	else if (id < 32*4)
		reg = iobus_cfg_base1+IOBUS_RESET3;
	else
		return -1;

	id %= 32;

	if (reset)
		ckc_writel(ckc_readl(reg) & ~(1<<id), reg);
	else
		ckc_writel(ckc_readl(reg) | (1<<id), reg);

	return 0;
}

static int tcc_ckc_hsiobus_pwdn(int id, bool pwdn)
{
	uintptr_t ckc_reg = ckc_base+CKC_CLKCTRL+(FBUS_HSIO*0x4);
	uintptr_t reg = hsiobus_cfg_base+HSIOBUS_PWDN;

	if (id >= HSIOBUS_MAX)
		return -1;

	if ((ckc_readl(ckc_reg) & (1<<CLKCTRL_EN_SHIFT)) == 0)
		return -2;

	if (pwdn)
		ckc_writel(ckc_readl(reg) & ~(1<<id), reg);
	else
		ckc_writel(ckc_readl(reg) | (1<<id), reg);

	return 0;
}

static int tcc_ckc_hsiobus_swreset(int id, bool reset)
{
	uintptr_t ckc_reg = ckc_base+CKC_CLKCTRL+(FBUS_HSIO*0x4);
	uintptr_t reg = hsiobus_cfg_base+HSIOBUS_RESET;

	if (id >= HSIOBUS_MAX)
		return -1;

	if ((ckc_readl(ckc_reg) & (1<<CLKCTRL_EN_SHIFT)) == 0)
		return -2;

	if (reset)
		ckc_writel(ckc_readl(reg) & ~(1<<id), reg);
	else
		ckc_writel(ckc_readl(reg) | (1<<id), reg);

	return 0;
}


/*
 * This functions called by nand driver.
 * Return value unit is 100Hz.
 */
uint32_t tca_ckc_get_nand_iobus_clk(void)
{
	return tcc_ckc_clkctrl_get_rate(FBUS_IO)/100;
}

static struct tcc_ckc_ops tcc805x_ops = {
	.ckc_pll_set_rate		= &tcc_ckc_pll_set_rate,
	.ckc_pll_get_rate		= &tcc_ckc_pll_get_rate,
	//.ckc_npll_set_val		= &tcc_ckc_npll_set_val,
	//.ckc_dpll_set_val		= &tcc_ckc_dpll_set_val,
	.ckc_plldiv_set			= &tcc_ckc_pll_div_set,
	.ckc_clkctrl_enable		= &tcc_ckc_clkctrl_enable,
	.ckc_clkctrl_disable		= &tcc_ckc_clkctrl_disable,
	.ckc_clkctrl_set_rate		= &tcc_ckc_clkctrl_set_rate,
	.ckc_clkctrl_get_rate		= &tcc_ckc_clkctrl_get_rate,
	.ckc_peri_enable		= &tcc_ckc_peri_enable,
	.ckc_peri_set_rate		= &tcc_ckc_peri_set_rate,
	.ckc_peri_get_rate		= &tcc_ckc_peri_get_rate,
	.ckc_iobus_pwdn			= &tcc_ckc_iobus_pwdn,
	.ckc_iobus_swreset		= &tcc_ckc_iobus_swreset,
	.ckc_hsiobus_pwdn		= &tcc_ckc_hsiobus_pwdn,
	.ckc_hsiobus_swreset		= &tcc_ckc_hsiobus_swreset,
	//.ckc_set_memphy			= &tcc_ckc_set_memphy,
	//.ckc_set_membus			= &tcc_ckc_set_membus,
};

static int initialized = 0;

void tcc_ckc_init(intptr_t hw_base)
{
	int i;

	if (initialized) {
		return;
	}
	initialized = 1;

	ckc_base = (uintptr_t )hw_base + TCC_CKC_BASE;
	micom_ckc_base = (uintptr_t )hw_base + TCC_MICOM_CKC_BASE;

	iobus_cfg_base = (uintptr_t )hw_base + TCC_IOBUSCFG_BASE;
	iobus_cfg_base1 = (uintptr_t )hw_base + TCC_IOBUSCFG1_BASE;
	hsiobus_cfg_base = (uintptr_t )hw_base + TCC_HSIOBUSCFG_BASE;

	mbusckc_base = (uintptr_t )hw_base + TCC_MBUSCFG_BASE + 0x40000;

	for (i=0 ; i<MAX_TCC_PLL*2 ; i++) {
		stClockSource[i] = 0;
	}
	stClockSource[MAX_TCC_PLL*2] = XIN_CLK_RATE;	// XIN
	stClockSource[MAX_TCC_PLL*2+1] = XTIN_CLK_RATE;	// XTIN

	for (i = 0; i < MPLL_MAX; i++) {
		stMicomClockSource[i] = 0;
	}
	stMicomClockSource[MPLL_XIN] = XIN_CLK_RATE;

	tcc_ckc_set_ops(&tcc805x_ops);

#if (0)
	/* disable all peri clocks*/
	/*for (i=0 ; i<PERI_MAX ; i++)
		tcc_pclkctrl_write((ckc_base + CKC_PCLKCTRL + (i*0x4)), 0, 0, PCLKCTRL_SEL_XIN, 0, 0);*/

	/* set clkctrl */
	for (i=0 ; i<FBUS_MAX ; i++) {
		if (i == FBUS_CBUS || i == FBUS_CMBUS || i == FBUS_HSIO || i == FBUS_SMU || i == FBUS_DDI || i == FBUS_IO)
			tcc_set_clkctrl(i, ENABLE, XIN_CLK_RATE/2);
	}

		/* Disable PLL Divider */
	ckc_writel(0x01010101, ckc_base+CKC_CLKDIVC);		/* PLL0,PLL1,PLL2 */
	ckc_writel(0x01010101, ckc_base+CKC_CLKDIVC+0x4);	/* XIN,XTIN */
#endif

	tcc_set_clkctrl(FBUS_MICOM_CPU, ENABLE, XIN_CLK_RATE);

	for (i=0 ; i< MAX_TCC_PLL ; i++) {
		tcc_ckc_reset_clock_source(i);
	}
}

