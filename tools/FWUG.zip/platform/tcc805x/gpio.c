/****************************************************************************
 *
 * Copyright (C) 2014 Telechips Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions
 * andlimitations under the License.
 ****************************************************************************/

#include <reg.h>
#include <dev/gpio.h>
#include <platform/iomap.h>
#include <platform/gpio.h>

typedef struct gpioregs gpioregs;

#define EXT_GPIO_MAX	2
//static struct ext_gpio *ext_gpio[EXT_GPIO_MAX] = { NULL, };

#define GPIO_REG(off)	(TCC_MICOM_GPIO_BASE + (off))
#define GPIO_MP_REG(off)	(TCC_GPIO_BASE + (off))

struct gpioregs
{
	unsigned data;		/* data */
	unsigned out_en;	/* output enable */
	unsigned out_or;	/* OR fnction on output data */
	unsigned out_bic;	/* BIC function on output data */
	unsigned out_xor;	/* XOR function on output data */
	unsigned strength0;	/* driver strength control 0 */
	unsigned strength1;	/* driver strength control 1 */
	unsigned pull_enable;	/* pull-up/down enable */
	unsigned pull_select;	/* pull-up/down select */
	unsigned in_en;		/* input enable */
	unsigned in_type;	/* input type (Shmitt / CMOS) */
	unsigned slew_rate;	/* slew rate */
	unsigned func_select0;	/* port configuration 0 */
	unsigned func_select1;	/* port configuration 1 */
	unsigned func_select2;	/* port configuration 2 */
	unsigned func_select3;	/* port configuration 3 */
};

static gpioregs GPIO_REGS[] = {
	{ /* GPIO A */
		.data		= GPIO_REG(0x000),
		.out_en		= GPIO_REG(0x004),
		.out_or		= GPIO_REG(0x008),
		.out_bic	= GPIO_REG(0x00C),
		.out_xor	= GPIO_REG(0x010),
		.strength0	= GPIO_REG(0x014),
		.strength1	= GPIO_REG(0x018),
		.pull_enable	= GPIO_REG(0x01C),
		.pull_select	= GPIO_REG(0x020),
		.in_en		= GPIO_REG(0x024),
		.in_type	= GPIO_REG(0x028),
		.slew_rate	= GPIO_REG(0x02C),
		.func_select0	= GPIO_REG(0x030),
		.func_select1	= GPIO_REG(0x034),
		.func_select2	= GPIO_REG(0x038),
		.func_select3	= GPIO_REG(0x03C),
	},
	{ /* GPIO B */
		.data		= GPIO_REG(0x040),
		.out_en		= GPIO_REG(0x044),
		.out_or		= GPIO_REG(0x048),
		.out_bic	= GPIO_REG(0x04C),
		.out_xor	= GPIO_REG(0x050),
		.strength0	= GPIO_REG(0x054),
		.strength1	= GPIO_REG(0x058),
		.pull_enable	= GPIO_REG(0x05C),
		.pull_select	= GPIO_REG(0x060),
		.in_en		= GPIO_REG(0x064),
		.in_type	= GPIO_REG(0x068),
		.slew_rate	= GPIO_REG(0x06C),
		.func_select0	= GPIO_REG(0x070),
		.func_select1	= GPIO_REG(0x074),
		.func_select2	= GPIO_REG(0x078),
		.func_select3	= GPIO_REG(0x07C),
	},
	{ /* GPIO C */
		.data		= GPIO_REG(0x080),
		.out_en		= GPIO_REG(0x084),
		.out_or		= GPIO_REG(0x088),
		.out_bic	= GPIO_REG(0x08C),
		.out_xor	= GPIO_REG(0x090),
		.strength0	= GPIO_REG(0x094),
		.strength1	= GPIO_REG(0x098),
		.pull_enable	= GPIO_REG(0x09C),
		.pull_select	= GPIO_REG(0x0A0),
		.in_en		= GPIO_REG(0x0A4),
		.in_type	= GPIO_REG(0x0A8),
		.slew_rate	= GPIO_REG(0x0AC),
		.func_select0	= GPIO_REG(0x0B0),
		.func_select1	= GPIO_REG(0x0B4),
		.func_select2	= GPIO_REG(0x0B8),
		.func_select3	= GPIO_REG(0x0BC),
	},
	{ /* GPIO E */
		.data		= GPIO_REG(0x100),
		.out_en		= GPIO_REG(0x104),
		.out_or		= GPIO_REG(0x108),
		.out_bic	= GPIO_REG(0x10C),
		.out_xor	= GPIO_REG(0x110),
		.strength0	= GPIO_REG(0x114),
		.strength1	= GPIO_REG(0x118),
		.pull_enable	= GPIO_REG(0x11C),
		.pull_select	= GPIO_REG(0x120),
		.in_en		= GPIO_REG(0x124),
		.in_type	= GPIO_REG(0x128),
		.slew_rate	= GPIO_REG(0x12C),
		.func_select0	= GPIO_REG(0x130),
		.func_select1	= GPIO_REG(0x134),
		.func_select2	= GPIO_REG(0x138),
		.func_select3	= GPIO_REG(0x13C), //reserved
	},
	{ /* GPIO G */
		.data		= GPIO_REG(0x180),
		.out_en		= GPIO_REG(0x184),
		.out_or		= GPIO_REG(0x188),
		.out_bic	= GPIO_REG(0x18C),
		.out_xor	= GPIO_REG(0x190),
		.strength0	= GPIO_REG(0x194),
		.strength1	= GPIO_REG(0x198),	//reserved
		.pull_enable	= GPIO_REG(0x19C),
		.pull_select	= GPIO_REG(0x1A0),
		.in_en		= GPIO_REG(0x1A4),
		.in_type	= GPIO_REG(0x1A8),
		.slew_rate	= GPIO_REG(0x1AC),
		.func_select0	= GPIO_REG(0x1B0),
		.func_select1	= GPIO_REG(0x1B4),
		.func_select2	= GPIO_REG(0x1B8), //reserved
		.func_select3	= GPIO_REG(0x1BC), //reserved
	},
	{ /* GPIO H */
		.data		= GPIO_REG(0x640),
		.out_en		= GPIO_REG(0x644),
		.out_or		= GPIO_REG(0x648),
		.out_bic	= GPIO_REG(0x64C),
		.out_xor	= GPIO_REG(0x650),
		.strength0	= GPIO_REG(0x654),
		.strength1	= GPIO_REG(0x658), //reserved
		.pull_enable	= GPIO_REG(0x65C),
		.pull_select	= GPIO_REG(0x660),
		.in_en		= GPIO_REG(0x664),
		.in_type	= GPIO_REG(0x668),
		.slew_rate	= GPIO_REG(0x66C),
		.func_select0	= GPIO_REG(0x670),
		.func_select1	= GPIO_REG(0x674),
		.func_select2	= GPIO_REG(0x678), //reserved
		.func_select3	= GPIO_REG(0x67C), //reserved
	},
	{ /* GPIO K */
		.data		= GPIO_REG(0x680),
		.out_en		= GPIO_REG(0x684),
		.out_or		= GPIO_REG(0x688),
		.out_bic	= GPIO_REG(0x68C),
		.out_xor	= GPIO_REG(0x690),
		.strength0	= GPIO_REG(0x694),	//reserved
		.strength1	= GPIO_REG(0x698),	//reserved
		.pull_enable	= GPIO_REG(0x69C),	//reserved
		.pull_select	= GPIO_REG(0x6A0),	//reserved
		.in_en		= GPIO_REG(0x6A4),		//reserved
		.in_type	= GPIO_REG(0x6A8),		//reserved
		.slew_rate	= GPIO_REG(0x6AC),		//reserved
		.func_select0	= GPIO_REG(0x6B0),
		.func_select1	= GPIO_REG(0x6B4),
		.func_select2	= GPIO_REG(0x6B8),
		.func_select3	= GPIO_REG(0x6BC), //reserved
	},
	{ /* GPIO SD0 */
		.data		= GPIO_MP_REG(0x200),
		.out_en		= GPIO_MP_REG(0x204),
		.out_or		= GPIO_MP_REG(0x208),
		.out_bic	= GPIO_MP_REG(0x20C),
		.out_xor	= GPIO_MP_REG(0x210),
		.strength0	= GPIO_MP_REG(0x214),
		.strength1	= GPIO_MP_REG(0x218),	//reserved
		.pull_enable	= GPIO_MP_REG(0x21C),
		.pull_select	= GPIO_MP_REG(0x220),
		.in_en		= GPIO_MP_REG(0x224),
		.in_type	= GPIO_MP_REG(0x228),
		.slew_rate	= GPIO_MP_REG(0x22C),
		.func_select0	= GPIO_MP_REG(0x230),
		.func_select1	= GPIO_MP_REG(0x234),
		.func_select2	= GPIO_MP_REG(0x238), //reserved
		.func_select3	= GPIO_MP_REG(0x23C), //reserved
	},
	{ /* GPIO SD1 */
		.data		= GPIO_MP_REG(0x240),
		.out_en		= GPIO_MP_REG(0x244),
		.out_or		= GPIO_MP_REG(0x248),
		.out_bic	= GPIO_MP_REG(0x24C),
		.out_xor	= GPIO_MP_REG(0x250),
		.strength0	= GPIO_MP_REG(0x254),
		.strength1	= GPIO_MP_REG(0x258),	//reserved
		.pull_enable	= GPIO_MP_REG(0x25C),
		.pull_select	= GPIO_MP_REG(0x260),
		.in_en		= GPIO_MP_REG(0x264),
		.in_type	= GPIO_MP_REG(0x268),
		.slew_rate	= GPIO_MP_REG(0x26C),
		.func_select0	= GPIO_MP_REG(0x270),
		.func_select1	= GPIO_MP_REG(0x274),
		.func_select2	= GPIO_MP_REG(0x278), //reserved
		.func_select3	= GPIO_MP_REG(0x27C), //reserved
	},
	{ /* GPIO SD2 */
		.data		= GPIO_MP_REG(0x600),
		.out_en		= GPIO_MP_REG(0x604),
		.out_or		= GPIO_MP_REG(0x608),
		.out_bic	= GPIO_MP_REG(0x60C),
		.out_xor	= GPIO_MP_REG(0x610),
		.strength0	= GPIO_MP_REG(0x614),
		.strength1	= GPIO_MP_REG(0x618),	//reserved
		.pull_enable	= GPIO_MP_REG(0x61C),
		.pull_select	= GPIO_MP_REG(0x620),
		.in_en		= GPIO_MP_REG(0x624),
		.in_type	= GPIO_MP_REG(0x628),
		.slew_rate	= GPIO_MP_REG(0x82C),
		.func_select0	= GPIO_MP_REG(0x630),
		.func_select1	= GPIO_MP_REG(0x634),
		.func_select2	= GPIO_MP_REG(0x638), //reserved
		.func_select3	= GPIO_MP_REG(0x63C), //reserved
	},
	{ /* GPIO MA */
		.data		= GPIO_REG(0x6C0),
		.out_en		= GPIO_REG(0x6C4),
		.out_or		= GPIO_REG(0x6C8),
		.out_bic	= GPIO_REG(0x6CC),
		.out_xor	= GPIO_REG(0x6D0),
		.strength0	= GPIO_REG(0x6D4),
		.strength1	= GPIO_REG(0x6D8),
		.pull_enable	= GPIO_REG(0x6DC),
		.pull_select	= GPIO_REG(0x6E0),
		.in_en		= GPIO_REG(0x6E4),
		.in_type	= GPIO_REG(0x6E8),
		.slew_rate	= GPIO_REG(0x6EC),
		.func_select0	= GPIO_REG(0x6F0),
		.func_select1	= GPIO_REG(0x6F4),
		.func_select2	= GPIO_REG(0x6F8),
		.func_select3	= GPIO_REG(0x6FC),
	},
	{ /* GPIO MB */
		.data		= GPIO_REG(0x700),
		.out_en		= GPIO_REG(0x704),
		.out_or		= GPIO_REG(0x708),
		.out_bic	= GPIO_REG(0x70C),
		.out_xor	= GPIO_REG(0x710),
		.strength0	= GPIO_REG(0x714),
		.strength1	= GPIO_REG(0x718),
		.pull_enable	= GPIO_REG(0x71C),
		.pull_select	= GPIO_REG(0x720),
		.in_en		= GPIO_REG(0x724),
		.in_type	= GPIO_REG(0x728),
		.slew_rate	= GPIO_REG(0x72C),
		.func_select0	= GPIO_REG(0x730),
		.func_select1	= GPIO_REG(0x734),
		.func_select2	= GPIO_REG(0x738),
		.func_select3	= GPIO_REG(0x73C),
	},
	{ /* GPIO MC */
		.data		= GPIO_REG(0x740),
		.out_en		= GPIO_REG(0x744),
		.out_or		= GPIO_REG(0x748),
		.out_bic	= GPIO_REG(0x74C),
		.out_xor	= GPIO_REG(0x750),
		.strength0	= GPIO_REG(0x754),
		.strength1	= GPIO_REG(0x758),
		.pull_enable	= GPIO_REG(0x75C),
		.pull_select	= GPIO_REG(0x760),
		.in_en		= GPIO_REG(0x764),
		.in_type	= GPIO_REG(0x768),
		.slew_rate	= GPIO_REG(0x76C),
		.func_select0	= GPIO_REG(0x770),
		.func_select1	= GPIO_REG(0x774),
		.func_select2	= GPIO_REG(0x778),
		.func_select3	= GPIO_REG(0x77C),
	},
	{ /* GPIO MD */
		.data		= GPIO_REG(0x780),
		.out_en		= GPIO_REG(0x784),
		.out_or		= GPIO_REG(0x788),
		.out_bic	= GPIO_REG(0x78C),
		.out_xor	= GPIO_REG(0x790),
		.strength0	= GPIO_REG(0x794),
		.strength1	= GPIO_REG(0x798),
		.pull_enable	= GPIO_REG(0x79C),
		.pull_select	= GPIO_REG(0x7A0),
		.in_en		= GPIO_REG(0x7A4),
		.in_type	= GPIO_REG(0x7A8),
		.slew_rate	= GPIO_REG(0x7AC),
		.func_select0	= GPIO_REG(0x7B0),
		.func_select1	= GPIO_REG(0x7B4),
		.func_select2	= GPIO_REG(0x7B8),
		.func_select3	= GPIO_REG(0x7BC),
	},

};

int gpio_config(unsigned n, unsigned flags)
{
	gpioregs *r = GPIO_REGS + ((n&GPIO_REGMASK) >> GPIO_REG_SHIFT);
	unsigned num = n&GPIO_BITMASK;;
	unsigned bit = (1<<num);

	if (r == 0) return -1;

	if (flags & GPIO_FN_BITMASK) {
		unsigned fn = ((flags & GPIO_FN_BITMASK) >> GPIO_FN_SHIFT) - 1;

		if (num < 8)
			RMWREG32(r->func_select0, num*4, 4, fn);
		else if (num < 16)
			RMWREG32(r->func_select1, (num-8)*4, 4, fn);
		else if (num < 24)
			RMWREG32(r->func_select2, (num-16)*4, 4, fn);
		else
			RMWREG32(r->func_select3, (num-24)*4, 4, fn);
	}

	if (flags & GPIO_CD_BITMASK) {
		unsigned cd = ((flags & GPIO_CD_BITMASK) >> GPIO_CD_SHIFT) - 1;

		if (num < 16)
			RMWREG32(r->strength0, num*2, 2, cd);
		else
			RMWREG32(r->strength1, (num-16)*2, 2, cd);
	}

	if (flags & GPIO_OUTPUT) {
		if (flags & GPIO_HIGH) {
			writel(readl(r->data) | bit, r->data);
		}
		if (flags & GPIO_LOW) {
			writel(readl(r->data) & (~bit), r->data);
		}
		writel(readl(r->out_en) | bit, r->out_en);
		writel(readl(r->in_en) & (~bit), r->in_en);
	} else if(flags & GPIO_INPUT) {
		writel(readl(r->out_en) & (~bit), r->out_en);
		writel(readl(r->in_en) | bit, r->in_en);
	}

	if (flags & GPIO_PULLUP){
		writel(readl(r->pull_select) | bit, r->pull_select);
		writel(readl(r->pull_enable) | bit, r->pull_enable);
	} else if (flags & GPIO_PULLDOWN) {
		writel(readl(r->pull_select) & (~bit), r->pull_select);
		writel(readl(r->pull_enable) | bit, r->pull_enable);
	} else if (flags & GPIO_PULLDISABLE) {
		writel(readl(r->pull_enable) & (~bit), r->pull_enable);
	}

	return 0;
}

void gpio_set(unsigned n, unsigned on)
{
	gpioregs *r = GPIO_REGS + ((n&GPIO_REGMASK) >> GPIO_REG_SHIFT);
	unsigned num = n&GPIO_BITMASK;;
	unsigned bit = (1<<num);

	if (r != 0) {
		if (on) {
			writel(readl(r->data) | bit, r->data);
		} else {
			writel(readl(r->data) & (~bit), r->data);
		}
	}
}

int gpio_get(unsigned n)
{
	gpioregs *r = GPIO_REGS + ((n&GPIO_REGMASK) >> GPIO_REG_SHIFT);
	unsigned num = n&GPIO_BITMASK;;
	unsigned bit = (1<<num);

	if (r == 0) return 0;

	return (readl(r->data) & bit) ? 1 : 0;
}
