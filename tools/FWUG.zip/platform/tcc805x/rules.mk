LOCAL_DIR := $(GET_LOCAL_DIR)

INCLUDES += -I$(LOCAL_DIR)/include

ARCH	:= arm
CFLAGS	+= -march=armv7-r

TOOLCHAIN_PREFIX=arm-eabi-

# Skip print information when DEBUG := 0
#DEBUG	:= 0
DEBUG	:= 3

ifneq ($(DEBUG),0)
DEFINES += WITH_DEBUG_UART=1
endif
#if WITH_DEBUG_UART
DEFINES += DEBUG_TCC805X
#endif


# Set MMU ADDRESS
# DEFINES += \
	WITH_EXTERNAL_TRANSLATION_TABLE=1 \
	MMU_TRANSLATION_TABLE_ADDR=0xF8000000


# Memory

# 0x0701_0000 - |---------------------|
#               |      R/W Area       |
#               |    (32KB-512Byte)   |
# 0x0700_8200 - |---------------------|
#               |      Code Area      |
#               |       (32KB)        |
# 0x0700_0200 - -----------------------
MEMBASE		:= 0x07000200

MEMSIZE		:= 0x0000FE00
RWOFFSET	:= 0x00008200


MODULES += \
	dev/snor

DEFINES += \
	MEMSIZE=$(MEMSIZE) \
	MEMBASE=$(MEMBASE)

OBJS += \
	$(LOCAL_DIR)/reboot.o \
	$(LOCAL_DIR)/tcc_ckc.o \
	$(LOCAL_DIR)/gpio.o \
	$(LOCAL_DIR)/uart.o \
	$(LOCAL_DIR)/interrupts.o
