
#include <reg.h>
#include <platform/gpio.h>
#include <platform/iomap.h>
#include <dev/gpio.h>
#include <platform/tcc_ckc.h>
#include <platform/uart.h>
#include <clock.h>

#define TCC8030_EVB_MICOM	35
#define TCC8039_TCU_MICOM	20

// UART Base address 
#define UART0_BASE 	(TCC_UART_BASE+0x00000)
#define UART1_BASE 	(TCC_UART_BASE+0x10000)
#define UART2_BASE 	(TCC_UART_BASE+0x20000)
#define UART3_BASE 	(TCC_UART_BASE+0x30000)
#define UARTPORTCFG	(TCC_UART_BASE+0x40010)

// UART Port CFG value address (UART_DEBUG_CFG in mkimage.cs.cfg)
#define SNOR_UARTCFG_VAL_ADDR	(TCC_SNOR_BASE + 0x1100)

#define GPIOA_SEL_BASE	(TCC_MICOM_PMU_BASE + 0x148)
#define GPIOB_SEL_BASE	(TCC_MICOM_PMU_BASE + 0x14C)
#define GPIOC_SEL_BASE	(TCC_MICOM_PMU_BASE + 0x150)
#define GPIOE_SEL_BASE	(TCC_MICOM_PMU_BASE + 0x154)
#define GPIOG_SEL_BASE	(TCC_MICOM_PMU_BASE + 0x158)
#define GPIOH_SEL_BASE	(TCC_MICOM_PMU_BASE + 0x15C)
#define GPIOMA_SEL_BASE	(TCC_MICOM_PMU_BASE + 0x160)
#define GPIO_SEL_MICOM	(0)
#define GPIO_SEL_SMU	(1)

// UART Register Offset
#define OFFSET_DR 		(0x00) 		// Data register 	
#define OFFSET_RSR 		(0x04) 		// Receive Status register
#define OFFSET_ECR 		(0x04) 		// Error Clear register
#define OFFSET_FR 		(0x18) 		// Flag register
#define OFFSET_ILPR 	(0x20) 		// IrDA Low-power Counter register
#define OFFSET_IBRD 	(0x24) 		// Integer Baud rate register
#define OFFSET_FBRD 	(0x28) 		// Fractional Baud rate register
#define OFFSET_LCRH 	(0x2c) 		// Line Control register
#define OFFSET_CR 		(0x30) 		// Control register
#define OFFSET_IFLS 	(0x34) 		// Interrupt FIFO Level status register
#define OFFSET_IMSC 	(0x38) 		// Interrupt Mask Set/Clear register
#define OFFSET_TRIS 	(0x3c) 		// Raw Interrupt Status register
#define OFFSET_TMIS 	(0x40) 		// Masked Interrupt Status register 
#define OFFSET_ICR 		(0x44) 		// Interrupt Clear register
#define OFFSET_DMACR 	(0x48) 		// DMA Control register

#define FR_TXFE  	(1 << 7) 	// Transmit FIFO empty
#define FR_RXFF  	(1 << 6)	// Receive FIFO full
#define FR_TXFF  	(1 << 5) 	// Transmit FIFO full
#define FR_RXFE  	(1 << 4) 	// Receive FIFO empty
#define FR_BUSY  	(1 << 3) 	// UART busy

#define LCRH_SPS             (1 << 7)
#define LCRH_WLEN(x)         ((x) << 5)
#define LCRH_FEN             (1 << 4)
#define LCRH_STP2            (1 << 3)
#define LCRH_EPS             (1 << 2)
#define LCRH_PEN             (1 << 1)
#define LCRH_BRK             (1 << 0)

enum {
	WORD_LEN_5 = 0,
	WORD_LEN_6,
	WORD_LEN_7,
	WORD_LEN_8
};

#define CR_CTSEN             (1 << 15)
#define CR_RTSEN             (1 << 14)
#define CR_OUT2              (1 << 13)
#define CR_OUT1              (1 << 12)
#define CR_RTS               (1 << 11)
#define CR_DTR               (1 << 10)
#define CR_RXE               (1 << 9)
#define CR_TXE               (1 << 8)
#define CR_LPE               (1 << 7)
#define CR_IIRLP             (1 << 2)
#define CR_SIREN             (1 << 1)
#define CR_UARTEN            (1 << 0)

struct uart_stat {
	addr_t base;
	int ch;
};

static struct uart_stat uart[] = {
	{ UART0_BASE, 0 },	// BL1 set only debug uart port
//	{ UART1_BASE, 1 },
//	{ UART2_BASE, 2 },
//	{ UART3_BASE, 3 },
};

#define uart_reg_write(p, a, v)	writel(v, uart[p].base + (a))
#define uart_reg_read(p, a)	readl(uart[p].base + (a))

struct board_serial_data {
	uint32 port_cfg;            // Config port ID
	uint32 port_tx;
	uint32 port_rx;
	uint32 port_fn;
};

#define PORT_CFG_MAX	36
static struct board_serial_data board_serial[PORT_CFG_MAX + 1] = {
	{ 0,  TCC_GPSD0(11), TCC_GPSD0(12), GPIO_FN7 },
	{ 1,  TCC_GPSD1(0),  TCC_GPSD1(1),  GPIO_FN7 },
	{ 2,  TCC_GPSD1(6),  TCC_GPSD1(7),  GPIO_FN7 },
	{ 3,  TCC_GPSD2(0),  TCC_GPSD2(1),  GPIO_FN7 },
	{ 4,  TCC_GPSD2(6),  TCC_GPSD2(7),  GPIO_FN7 },
	{ 5,  TCC_GPA(0),    TCC_GPA(1),    GPIO_FN7 },
	{ 6,  TCC_GPA(6),    TCC_GPA(7),    GPIO_FN7 },
	{ 7,  TCC_GPA(12),   TCC_GPA(13),   GPIO_FN7 },
	{ 8,  TCC_GPA(18),   TCC_GPA(19),   GPIO_FN7 },
	{ 9,  TCC_GPA(24),   TCC_GPA(25),   GPIO_FN7 },
	{ 10, TCC_GPB(0),    TCC_GPB(1),    GPIO_FN7 },
	{ 11, TCC_GPB(6),    TCC_GPB(7),    GPIO_FN7 },
	{ 12, TCC_GPB(12),   TCC_GPB(13),   GPIO_FN7 },
	{ 13, TCC_GPB(19),   TCC_GPB(20),   GPIO_FN7 },
	{ 14, TCC_GPB(25),   TCC_GPB(26),   GPIO_FN7 },
	{ 15, TCC_GPC(0),    TCC_GPC(1),    GPIO_FN7 },
	{ 16, TCC_GPC(4),    TCC_GPC(5),    GPIO_FN7 },
	{ 17, TCC_GPC(8),    TCC_GPC(9),    GPIO_FN7 },
	{ 18, TCC_GPC(10),   TCC_GPC(11),   GPIO_FN8 },
	{ 19, TCC_GPC(12),   TCC_GPC(13),   GPIO_FN7 },
	{ 20, TCC_GPC(16),   TCC_GPC(17),   GPIO_FN7 },
	{ 21, TCC_GPC(20),   TCC_GPC(21),   GPIO_FN7 },
	{ 22, TCC_GPC(26),   TCC_GPC(27),   GPIO_FN7 },
	{ 23, TCC_GPG(0),    TCC_GPG(1),    GPIO_FN7 },
	{ 24, TCC_GPG(7),    TCC_GPG(8),    GPIO_FN7 },
	{ 25, TCC_GPE(5),    TCC_GPG(6),    GPIO_FN7 },
	{ 26, TCC_GPE(11),   TCC_GPE(12),   GPIO_FN7 },
	{ 27, TCC_GPE(16),   TCC_GPE(17),   GPIO_FN7 },
	{ 28, TCC_GPH(4),    TCC_GPH(5),    GPIO_FN7 },
	{ 29, TCC_GPH(6),    TCC_GPH(7),    GPIO_FN7 },
	{ 30, TCC_GPH(0),    TCC_GPH(1),    GPIO_FN7 },
	{ 31, TCC_GPMA(0),   TCC_GPMA(1),   GPIO_FN7 },
	{ 32, TCC_GPMA(6),   TCC_GPMA(7),   GPIO_FN7 },
	{ 33, TCC_GPMA(12),  TCC_GPMA(13),  GPIO_FN7 },
	{ 34, TCC_GPMA(18),  TCC_GPMA(19),  GPIO_FN7 },
	{ 35, TCC_GPMA(24),  TCC_GPMA(25),  GPIO_FN7 },
	{ 36, TCC_GPK(9),    TCC_GPK(10),   GPIO_FN2 }
};

int32 uart_gpio_select(uint32 gpio, uint32 gpio_sel)
{
	unsigned num = gpio & GPIO_BITMASK;
	unsigned bit = (1 << num);

	if (gpio_sel == GPIO_SEL_MICOM)
	{
		switch(gpio & GPIO_REGMASK) {
			case GPIO_PORTA:
				writel(readl(GPIOA_SEL_BASE) & ~(bit), GPIOA_SEL_BASE);
				break;
			case GPIO_PORTB:
				writel(readl(GPIOB_SEL_BASE) & ~(bit), GPIOB_SEL_BASE);
				break;
			case GPIO_PORTC:
				writel(readl(GPIOC_SEL_BASE) & ~(bit), GPIOC_SEL_BASE);
				break;
			case GPIO_PORTE:
				writel(readl(GPIOE_SEL_BASE) & ~(bit), GPIOE_SEL_BASE);
				break;
			case GPIO_PORTG:
				writel(readl(GPIOG_SEL_BASE) & ~(bit), GPIOG_SEL_BASE);
				break;
			case GPIO_PORTH:
				writel(readl(GPIOH_SEL_BASE) & ~(bit), GPIOH_SEL_BASE);
				break;
			case GPIO_PORTMA:
				writel(readl(GPIOMA_SEL_BASE) & ~(bit), GPIOMA_SEL_BASE);
				break;
			default:
				return (-1);
		}
	}
	else
	{
		switch(gpio & GPIO_REGMASK) {
			case GPIO_PORTA:
				writel(readl(GPIOA_SEL_BASE) | (bit), GPIOA_SEL_BASE);
				break;
			case GPIO_PORTB:
				writel(readl(GPIOB_SEL_BASE) | (bit), GPIOB_SEL_BASE);
				break;
			case GPIO_PORTC:
				writel(readl(GPIOC_SEL_BASE) | (bit), GPIOC_SEL_BASE);
				break;
			case GPIO_PORTE:
				writel(readl(GPIOE_SEL_BASE) | (bit), GPIOE_SEL_BASE);
				break;
			case GPIO_PORTG:
				writel(readl(GPIOG_SEL_BASE) | (bit), GPIOG_SEL_BASE);
				break;
			case GPIO_PORTH:
				writel(readl(GPIOH_SEL_BASE) | (bit), GPIOH_SEL_BASE);
				break;
			case GPIO_PORTMA:
				writel(readl(GPIOMA_SEL_BASE) | (bit), GPIOMA_SEL_BASE);
				break;
			default:
				return (-1);
		}
	}
	
	return 0;
}

void uart_set_gpio(uint32 ch, const struct board_serial_data *info)
{
	void __iomem *portcfg = (void __iomem *)UARTPORTCFG;
	uint32 portcfg_val;

	/* set portcfg */
	portcfg_val = readl(portcfg);
	portcfg_val = (portcfg_val & ~(0xFF<<(ch*8))) | (info->port_cfg<<(ch*8));
	writel(portcfg_val, portcfg);

	if (uart_gpio_select(info->port_tx, GPIO_SEL_MICOM))
		return;
	if (uart_gpio_select(info->port_rx, GPIO_SEL_MICOM))
		return;

	/* set debug port */
	gpio_config(info->port_tx, (info->port_fn));	// TX  
	gpio_config(info->port_rx, (info->port_fn));	// RX
}

void uart_init_port(int port, uint baud)
{
	unsigned int tmp, mod;
	unsigned int brd_i, brd_f;
	unsigned int cr_data, lcr_data;

	// calculate integer baud rate divisor
	tmp = 16 * baud;
	brd_i = DEBUG_CLK / tmp;
	uart_reg_write(port, OFFSET_IBRD, brd_i);

	// calculate faction baud rate divisor
	// NOTICE : fraction maybe need sampling
	mod = DEBUG_CLK % (16 * baud);
	tmp = ((1 << 3) * 16 * mod) / (16 * baud);
	brd_f = tmp / 2;
	uart_reg_write(port, OFFSET_FBRD, brd_f);

	// control register setting
	cr_data = CR_UARTEN;
	cr_data |= CR_TXE;
	cr_data |= CR_RXE;
	uart_reg_write(port, OFFSET_CR, cr_data);

	// line control setting 
	lcr_data = LCRH_WLEN(WORD_LEN_8);
	lcr_data |= LCRH_FEN;
	uart_reg_write(port, OFFSET_LCRH, lcr_data);
}

void uart_init(void)
{
}

void uart_init_early(void)
{
	unsigned int i;
	uint32 cfg_val;

	/* GPIO_MA is selected to AP controls until selected by MICOM FW. */
	writel(0xFFFFFFFF, GPIOMA_SEL_BASE);

	// Initialize uart port configuration register
	writel(0xFFFFFFFF, UARTPORTCFG);
#if WITH_DEBUG_UART
	cfg_val = (readl(SNOR_UARTCFG_VAL_ADDR) & 0xFF);
	if (cfg_val > PORT_CFG_MAX)
		cfg_val = TCC8030_EVB_MICOM;	// default config

	for(i = 0; i <= PORT_CFG_MAX; i++) {
		if(board_serial[i].port_cfg == cfg_val) {
			tcc_set_peri(PERI_MICOM_UART0 + DEBUG_UART, ENABLE, DEBUG_CLK);
			uart_init_port(DEBUG_UART, DEBUG_BR);
			uart_set_gpio(DEBUG_UART, &board_serial[i]);
			break;
		}
	}
#endif /* WITH_DEBUG_UART */
}

static int __uart_putc(int port, char c)
{
	while (uart_reg_read(port, OFFSET_FR) & FR_TXFF)
		;

	uart_reg_write(port, OFFSET_DR, c);

	return 0;
}

int uart_putc(int port, char c)
{
	if (c == '\n')
		__uart_putc(port, '\r');
	return __uart_putc(port, c);
}

int uart_getc(int port, bool wait)
{
	unsigned int data;

	if(wait) {
		while (uart_reg_read(port, OFFSET_FR) & FR_RXFE);
	} else {
		if(uart_reg_read(port, OFFSET_FR) & FR_RXFE)
			return -1;
	}

	data = uart_reg_read(port, OFFSET_DR);

	return (int) data;
}

void uart_flush_tx(int port)
{
	while(!(uart_reg_read(port, OFFSET_FR) & FR_TXFE))
		;
}

void uart_flush_rx(int port)
{
	while(!(uart_reg_read(port, OFFSET_FR) & FR_RXFE)) {
		volatile char c = uart_reg_read(port, OFFSET_DR); 
		(void)c;
	}
}


