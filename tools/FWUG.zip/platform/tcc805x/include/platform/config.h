
#ifndef __PLATFORM_CONFIG_H__
#define __PLATFORM_CONFIG_H__

#define CORE_NUMBER	1
#define ARM_TIMER_RATE	24000000

#define STACK_SIZE	(0x1000)
#endif
