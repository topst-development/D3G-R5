/* Copyright (c) 2012-2013, The Linux Foundation. All rights reserved.
 * Copyright (C) 2016, Telechips Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *     * Neither the name of The Linux Foundation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _PLATFORM_TCC_IOMAP_H_
#define _PLATFORM_TCC_IOMAP_H_

#ifndef __iomem
#define __iomem
#endif

#define TCC_OTP_BASE		    0xE0000000
#define TCC_SRAM0_BASE		    0x06000000
#define TCC_SRAM1_BASE		    0x07000000
#define TCC_HIVEC_BASE		    0xFFFF0000

/* Part 2. SMU & CKC */
#define TCC_CKC_BASE		    0x14000000
#define TCC_MICOM_CKC_BASE      0x1B931000
#define TCC_GPIO_BASE		    0x14200000
#define TCC_MICOM_GPIO_BASE		0x1B935000
#define TCC_TIMER_BASE		    0x1B933000
#define TCC_PMU_BASE		    0x14400000
#define TCC_MICOM_PMU_BASE     	0x1B936000

/* Part 4. Memory */
#define TCC_MBUSCFG_BASE	    0x13500000
#define TCC_MBUSCBCMAC_BASE	    0x13530000


/* Part 5. IO */
#define TCC_IOBUSCFG_BASE	    0x16051000
#define TCC_IOBUSCFG1_BASE	    0x16494400
#define TCC_PL080_BASE          0x1B600000

#define TCC_I2CCFG_BASE         0x1B330000
#define TCC_I2C0_BASE			0x1B300000

#define TCC_NFC_BASE            0x16400000
#define TCC_EDI_BASE            0x16430000

#define TCC_SDMMC_BASE(x)       (0x16440000+(x)*0x10000)
#define TCC_SDMMC0_BASE         0x16440000
#define TCC_SDMMCCFG_BASE       0x16470000

#define TCC_GPSB0_BASE          0x1B100000
#define TCC_GPSBCFG_BASE        0x1B130000

#define TCC_SFMC_BASE           0x1B910000

#define TCC_SNOR_BASE           0x08000000

#define TCC_UART_BASE		    0x1B200000

/* Part 6. High Speed H/O */

#define TCC_USB20DEV_BASE	    0x11980000
#define TCC_HSIOBUSCFG_BASE	    0x11DA0000
#define TCC_USBPHYCFG_BASE	    0x11DA0100
#define TCC_HSIOBUSTRNG_BASE	0x11DB0100
#define TCC_HSIOBUSCIPHER_BASE	0x11DC0000


/* Part 9. CMBUS */

#define TCC_CM4_CODE_BASE	    0x19080000
#define TCC_CM4_DATA_BASE	    0x19090000
#define TCC_CM4_TSD_CFG_BASE	0x190F0000


/* Part 10. CPU */
#define TCC_CPU_MICOM_BASE		0x1B000000
#define TCC_CBUS_BASE			0x17000000
#define TCC_CPU_MP_BASE			0x17100000
#define TCC_CPU_SP_BASE			0x17200000
#define MICOM_GIC_DIST_BASE	    0x1B901000
#define MICOM_GIC_CPU_BASE	    0x1B902000

#define KEYTABLE_BASE		    0x0603F000
#define SYS_INFO_BASE		    0x0603F400


#define BL1_HEADER_BASE         TCC_SRAM1_BASE
#define BL1_HEADER_SIZE         0x00000200
#define BL1_START_ADDR          (BL1_HEADER_BASE + BL1_HEADER_SIZE)

#define RESET_STS_STORE         0x0603F400
#define SECURE_BOOT_STATUS      0x0603F500  /* 16 bytes */
#define DMA_BUFFER_BASE         0x0603F700    /* buffer for hardware block (256 bytes) */
#define DMA_BUFFER_SIZE         0x06000100

/* MP BASE ADDRESS */
#define MP_BL1_HEADER_BASE		0xF0000000
#define MP_BL1_HEADER_SIZE		0x00000200
#define MP_BL1_START_ADDR		(MP_BL1_HEADER_BASE + MP_BL1_HEADER_SIZE)
#endif
