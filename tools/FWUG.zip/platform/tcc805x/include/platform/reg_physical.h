/****************************************************************************
 * FileName    : reg_physical.h
 * Description : 
 ****************************************************************************
 *
 * Copyright (C) 2016 Telechips, Inc.
 * All Rights Reserved
 *
 ****************************************************************************/

#ifndef _PLATFORM_REG_PHYSICAL_H_
#define _PLATFORM_REG_PHYSICAL_H_

#include <globals.h>

typedef struct {
	unsigned VALUE		:16;
} TCC_DEF16BIT_IDX_TYPE;

typedef union {
	unsigned short		nREG;
	TCC_DEF16BIT_IDX_TYPE	bREG;
} TCC_DEF16BIT_TYPE;

typedef struct {
	unsigned VALUE		:32;
} TCC_DEF32BIT_IDX_TYPE;

typedef union {
	unsigned long		nREG;
	TCC_DEF32BIT_IDX_TYPE	bREG;
} TCC_DEF32BIT_TYPE;

/*******************************************************************************
*
*	TCC805X DataSheet PART 7 DISPLAY BUS
*
********************************************************************************/

// DISP Control Reg
#define HwDISP_EVP                      Hw31                                // External Vsync Polarity
#define HwDISP_EVS                      Hw30                                // External Vsync Enable
#define HwDISP_R2YMD                 (Hw29+Hw28+Hw27)                         // RGB to YCbCr Conversion Option
#define HwDISP_ADVI                    Hw26                                // Advanced interlaced mode
#define HwDISP_656                      Hw25                                // CCIR 656 Mode
#define HwDISP_CKG                      Hw24                                // Clock Gating Enable for Timing Generator

#define HwDISP_Y2RMD			(Hw23+Hw22+Hw21)				// YUV to RGB converter mode register
#define HwDISP_PXDW                     (Hw20+Hw19+Hw18+Hw17+Hw16)               // PXDW
#define HwDISP_SREQ                     Hw15                                // stop request
#define HwDISP_ID                       Hw14                                // Inverted Data Enable
#define HwDISP_IV                       Hw13                                // Inverted Vertical Sync
#define HwDISP_IH                       Hw12                                // Inverted Horizontal Sync
#define HwDISP_IP                       Hw11                                // Inverted Pixel Clock
#define HwDISP_CLEN                     Hw10                                // Clipping Enable
#define HwDISP_R2Y                      Hw9                                // RGB to YCbCr Converter Enable for Output 
#define HwDISP_DP                       Hw8                                 // Double Pixel Data
#define HwDISP_NI                       Hw7                                 // Non-Interlace
#define HwDISP_TV                       Hw6                                 // TV mode 
#define HwDISP_SRST                     Hw5                                 // Device display reset 
#define HwDISP_Y2R				Hw4						// YUV to RGB converter enable register
#define HwDISP_SWAP                     (Hw3+Hw2+Hw1)                       // Output RGB overlay swap
#define HwDISP_LEN                      Hw0                                 // LCD Controller Enable



// RDMA Control Reg
#define HwDMA_INTL                      Hw31                                // Interlaced Image
#define HwDMA_BFMD                      Hw30                                // Bfield mode
#define HwDMA_BF                        Hw29                                // Bottom field
#define HwDMA_IEN                       Hw28                                // Image Display Function for Each Image
#define HwDMA_STRM                      Hw27                                // streaming mode
#define HwDMA_3DMD				Hw26 + Hw25				// 3D mode type
#define HwDMA_ASEL                      Hw24                                // Image Displaying Function for Each Image
#define HwDMA_UVI                       Hw23                                // UV ineterpolation
#define HwDMA_NUVI                       Hw22                               
#define HwDMA_R2YMD			(Hw19+Hw18+Hw6)				// RGB to YUV converter mode register
#define HWDMA_R2Y				Hw17					// RGB to YUV converter enable register
#define HwDMA_UPD                       Hw16                                // data update enable
#define HwDMA_PD                        Hw15                                // Bit padding
#define HwDMA_SWAP				Hw14+Hw13+Hw12			// RGB swap register
#define HwDMA_AEN				Hw11					// Alpha enable register
#define HwDMA_Y2RMD                     (Hw10+Hw9+Hw5)                          // YCbCr to RGB Conversion Option
#define HwDMA_Y2R                       Hw8                                 // YCbCr to RGB Conversion Enable Bit
#define HwDMA_BR                        Hw7                                 // Bit Reverse
#define HwDMA_FMT                       (Hw4+Hw3+Hw2+Hw1+Hw0)               // Image Format

//DISP status
#define HwLSTATUS_VS                    Hw31                                // Monitoring vertical sync
#define HwLSTATUS_BUSY                  Hw30                                // Busy signal
#define HwLSTATUS_EF                    Hw29                                // Even-Field(Read Only). 0:Odd field or frame, 1:Even field or frame
#define HwLSTATUS_DEOF                  Hw28                                // DMA End of Frame flag

#define HwLSTATUS_SREQ                  Hw5                                 // Device stop request
#define HwLSTATUS_DD                    Hw4                                 // Disable done
#define HwLSTATUS_RU                    Hw3                                 // Register update flag
#define HwLSTATUS_VSF                   Hw2                                 // VS falling flag
#define HwLSTATUS_VSR                   Hw1                                 // VS rising flag
#define HwLSTATUS_FU                    Hw0                                 // LCD output fifo under-run flag.

//#include "structures_display.h"
#define HwVIOC_BASE                             (0x12000000)


#define BASE_ADDR_VIOC                          HwVIOC_BASE
#define HwVIOC_CONFIG           ( (BASE_ADDR_VIOC  + 0xA000        ))                // TCC8910 | TCC8010

/* DISP */
#define HwVIOC_DISP0            ( (BASE_ADDR_VIOC  + 0x0000 + 0x0000)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_DISP1            ( (BASE_ADDR_VIOC  + 0x0000 + 0x0100)) // 64 words    // TCC8910 
#define HwVIOC_DISP2            ( (BASE_ADDR_VIOC  + 0x0000 + 0x0200)) // 64 words    // TCC8910
/* RDMA */
#define HwVIOC_RDMA_GAP     	(0x100)
#define HwVIOC_RDMA00           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0400)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_RDMA01           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0500)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_RDMA02           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0600)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_RDMA03           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0700)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_RDMA04           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0800)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_RDMA05           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0900)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_RDMA06           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0A00)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_RDMA07           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0B00)) // 64 words    // TCC8910
#define HwVIOC_RDMA08           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0C00)) // 64 words    // TCC8910
#define HwVIOC_RDMA09           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0D00)) // 64 words    // TCC8910
#define HwVIOC_RDMA10           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0E00)) // 64 words    // TCC8910
#define HwVIOC_RDMA11           ( (BASE_ADDR_VIOC  + 0x0000 + 0x0F00)) // 64 words    // TCC8910
#define HwVIOC_RDMA12           ( (BASE_ADDR_VIOC  + 0x0000 + 0x1000)) // 64 words    // TCC8910
#define HwVIOC_RDMA13           ( (BASE_ADDR_VIOC  + 0x0000 + 0x1100)) // 64 words    // TCC8910
#define HwVIOC_RDMA14           ( (BASE_ADDR_VIOC  + 0x0000 + 0x1200)) // 64 words    // TCC8910
#define HwVIOC_RDMA15           ( (BASE_ADDR_VIOC  + 0x0000 + 0x1300)) // 64 words    // TCC8910
#define HwVIOC_RDMA16           ( (BASE_ADDR_VIOC  + 0x0000 + 0x1400)) // 64 words    // TCC8910
#define HwVIOC_RDMA17           ( (BASE_ADDR_VIOC  + 0x0000 + 0x1500)) // 64 words    // TCC8910

/* WMIX */
#define HwVIOC_WMIX0            ( (BASE_ADDR_VIOC  + 0x0000 + 0x1800)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WMIX1            ( (BASE_ADDR_VIOC  + 0x0000 + 0x1900)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WMIX2            ( (BASE_ADDR_VIOC  + 0x0000 + 0x1A00)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WMIX3            ( (BASE_ADDR_VIOC  + 0x0000 + 0x1B00)) // 64 words    // TCC8910
#define HwVIOC_WMIX4            ( (BASE_ADDR_VIOC  + 0x0000 + 0x1C00)) // 64 words    // TCC8910
#define HwVIOC_WMIX5            ( (BASE_ADDR_VIOC  + 0x0000 + 0x1D00)) // 64 words    // TCC8910
#define HwVIOC_WMIX6            ( (BASE_ADDR_VIOC  + 0x0000 + 0x1E00)) // 64 words    // TCC8910

/* SCALER */
#define HwVIOC_SC0              ( (BASE_ADDR_VIOC  + 0x0000 + 0x2000)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_SC1              ( (BASE_ADDR_VIOC  + 0x0000 + 0x2100)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_SC2              ( (BASE_ADDR_VIOC  + 0x0000 + 0x2200)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_SC3              ( (BASE_ADDR_VIOC  + 0x0000 + 0x2300)) // 64 words    // TCC8910
#define HwVIOC_SC4              ( (BASE_ADDR_VIOC  + 0x0000 + 0x2400)) // 64 words    // TCC8910
#define HwVIOC_SC5              ( (BASE_ADDR_VIOC  + 0x0000 + 0x2500)) // 64 words    // TCC8910

/* WDMA */
#define HwVIOC_WDMA00           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2800)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WDMA01           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2900)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WDMA02           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2A00)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WDMA03           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2B00)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WDMA04           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2C00)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WDMA05           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2D00)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WDMA06           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2E00)) // 64 words    // TCC8910 | TCC8010
#define HwVIOC_WDMA07           ( (BASE_ADDR_VIOC  + 0x0000 + 0x2F00)) // 64 words    // TCC8910
#define HwVIOC_WDMA08           ( (BASE_ADDR_VIOC  + 0x0000 + 0x3000)) // 64 words    // TCC8910


#define HwVIOCLUT_BASE                 (0x12009000)

#define HwVIOC_OUTCFG           ((0x12100200)) // [09:08] == 2'b10, 
#define HwNTSCPAL_BASE                          		(0x12200000)
#define HwTVE_BASE								(0x12200000)
#define HwNTSCPAL_ENC_CTRL_BASE                 (0x12200800)


// Encoder Mode Control A
#define	HwTVECMDA_PWDENC_PD							Hw7											// Power down mode for entire digital logic of TV encoder
#define	HwTVECMDA_FDRST_1							Hw6											// Chroma is free running as compared to H-sync
#define	HwTVECMDA_FDRST_0							HwZERO										// Relationship between color burst & H-sync is maintained for video standards
#define	HwTVECMDA_FSCSEL(X)							((X)*Hw4)
#define	HwTVECMDA_FSCSEL_NTSC						HwTVECMDA_FSCSEL(0)							// Color subcarrier frequency is 3.57954545 MHz for NTSC
#define	HwTVECMDA_FSCSEL_PALX						HwTVECMDA_FSCSEL(1)							// Color subcarrier frequency is 4.43361875 MHz for PAL-B,D,G,H,I,N
#define	HwTVECMDA_FSCSEL_PALM						HwTVECMDA_FSCSEL(2)							// Color subcarrier frequency is 3.57561149 MHz for PAL-M
#define	HwTVECMDA_FSCSEL_PALCN						HwTVECMDA_FSCSEL(3)							// Color subcarrier frequency is 3.58205625 MHz for PAL-combination N
#define	HwTVECMDA_FSCSEL_MASK						HwTVECMDA_FSCSEL(3)
#define	HwTVECMDA_PEDESTAL							Hw3											// Video Output has a pedestal
#define	HwTVECMDA_NO_PEDESTAL						HwZERO										// Video Output has no pedestal
#define	HwTVECMDA_PIXEL_SQUARE						Hw2											// Input data is at square pixel rates.
#define	HwTVECMDA_PIXEL_601							HwZERO										// Input data is at 601 rates.
#define	HwTVECMDA_IFMT_625							Hw1											// Output data has 625 lines
#define	HwTVECMDA_IFMT_525							HwZERO										// Output data has 525 lines
#define	HwTVECMDA_PHALT_PAL							Hw0											// PAL encoded chroma signal output
#define	HwTVECMDA_PHALT_NTSC						HwZERO										// NTSC encoded chroma signal output

// Encoder Mode Control B
#define	HwTVECMDB_YBIBLK_BLACK						Hw4											// Video data is forced to Black level for Vertical non VBI processed lines.
#define	HwTVECMDB_YBIBLK_BYPASS						HwZERO										// Input data is passed through forn non VBI processed lines.
#define	HwTVECMDB_CBW(X)							((X)*Hw2)
#define	HwTVECMDB_CBW_LOW							HwTVECMDB_CBW(0)							// Low Chroma band-width
#define	HwTVECMDB_CBW_MEDIUM						HwTVECMDB_CBW(1)							// Medium Chroma band-width
#define	HwTVECMDB_CBW_HIGH							HwTVECMDB_CBW(2)							// High Chroma band-width
#define	HwTVECMDB_CBW_MASK							HwTVECMDB_CBW(3)							// 
#define	HwTVECMDB_YBW(X)							((X)*Hw0)
#define	HwTVECMDB_YBW_LOW							HwTVECMDB_YBW(0)							// Low Luma band-width
#define	HwTVECMDB_YBW_MEDIUM						HwTVECMDB_YBW(1)							// Medium Luma band-width
#define	HwTVECMDB_YBW_HIGH							HwTVECMDB_YBW(2)							// High Luma band-width
#define	HwTVECMDB_YBW_MASK							HwTVECMDB_YBW(3)							// 

// Encoder Clock Generator
#define	HwTVEGLK_XT24_24MHZ							Hw4											// 24MHz Clock input
#define	HwTVEGLK_XT24_27MHZ							HwZERO										// 27MHz Clock input
#define	HwTVEGLK_GLKEN_RST_EN						Hw3											// Reset Genlock
#define	HwTVEGLK_GLKEN_RST_DIS						~Hw3										// Release Genlock
#define	HwTVEGLK_GLKE(X)							((X)*Hw1)
#define	HwTVEGLK_GLKE_INT							HwTVEGLK_GLKE(0)							// Chroma Fsc is generated from internal constants based on current user setting
#define	HwTVEGLK_GLKE_RTCO							HwTVEGLK_GLKE(2)							// Chroma Fsc is adjusted based on external RTCO input
#define	HwTVEGLK_GLKE_CLKI							HwTVEGLK_GLKE(3)							// Chroma Fsc tracks non standard encoder clock (CLKI) frequency
#define	HwTVEGLK_GLKE_MASK							HwTVEGLK_GLKE(3)							//
#define	HwTVEGLK_GLKEN_GLKPL_HIGH					Hw0											// PAL ID polarity is active high
#define	HwTVEGLK_GLKEN_GLKPL_LOW					HwZERO										// PAL ID polarity is active low

// Encoder Mode Control C
#define	HwTVECMDC_CSMDE_EN							Hw7											// Composite Sync mode enabled
#define	HwTVECMDC_CSMDE_DIS							~Hw7										// Composite Sync mode disabled (pin is tri-stated)
#define	HwTVECMDC_CSMD(X)							((X)*Hw5)
#define	HwTVECMDC_CSMD_CSYNC						HwTVECMDC_CSMD(0)							// CSYN pin is Composite sync signal
#define	HwTVECMDC_CSMD_KEYCLAMP						HwTVECMDC_CSMD(1)							// CSYN pin is Keyed clamp signal
#define	HwTVECMDC_CSMD_KEYPULSE						HwTVECMDC_CSMD(2)							// CSYN pin is Keyed pulse signal
#define	HwTVECMDC_CSMD_MASK							HwTVECMDC_CSMD(3)
#define	HwTVECMDC_RGBSYNC(X)						((X)*Hw3)
#define	HwTVECMDC_RGBSYNC_NOSYNC					HwTVECMDC_RGBSYNC(0)						// Disable RGBSYNC (when output is configured for analog EGB mode)
#define	HwTVECMDC_RGBSYNC_RGB						HwTVECMDC_RGBSYNC(1)						// Sync on RGB output signal (when output is configured for analog EGB mode)
#define	HwTVECMDC_RGBSYNC_G							HwTVECMDC_RGBSYNC(2)						// Sync on G output signal (when output is configured for analog EGB mode)
#define	HwTVECMDC_RGBSYNC_MASK						HwTVECMDC_RGBSYNC(3)

// DAC Output Selection
#define	HwTVEDACSEL_DACSEL_CODE0					HwZERO										// Data output is diabled (output is code '0')
#define	HwTVEDACSEL_DACSEL_CVBS						Hw0											// Data output in CVBS format

// DAC Power Down
#define	HwTVEDACPD_PD_EN							Hw0											// DAC Power Down Enabled
#define	HwTVEDACPD_PD_DIS							~Hw0										// DAC Power Down Disabled

// Sync Control
#define	HwTVEICNTL_FSIP_ODDHIGH						Hw7											// Odd field active high
#define	HwTVEICNTL_FSIP_ODDLOW						HwZERO										// Odd field active low
#define	HwTVEICNTL_VSIP_HIGH						Hw6											// V-sync active high
#define	HwTVEICNTL_VSIP_LOW							HwZERO										// V-sync active low
#define	HwTVEICNTL_HSIP_HIGH						Hw5											// H-sync active high
#define	HwTVEICNTL_HSIP_LOW							HwZERO										// H-sync active low
#define	HwTVEICNTL_HSVSP_RISING						Hw4											// H/V-sync latch enabled at rising edge
#define	HwTVEICNTL_HVVSP_FALLING					HwZERO										// H/V-sync latch enabled at falling edge
#define	HwTVEICNTL_VSMD_START						Hw3											// Even/Odd field H/V sync output are aligned to video line start
#define	HwTVEICNTL_VSMD_MID							HwZERO										// Even field H/V sync output are aligned to video line midpoint
#define	HwTVEICNTL_ISYNC(X)							((X)*Hw0)
#define	HwTVEICNTL_ISYNC_FSI						HwTVEICNTL_ISYNC(0)							// Alignment input format from FSI pin
#define	HwTVEICNTL_ISYNC_HVFSI						HwTVEICNTL_ISYNC(1)							// Alignment input format from HSI,VSI,FSI pin
#define	HwTVEICNTL_ISYNC_HVSI						HwTVEICNTL_ISYNC(2)							// Alignment input format from HSI,VSI pin
#define	HwTVEICNTL_ISYNC_VFSI						HwTVEICNTL_ISYNC(3)							// Alignment input format from VSI,FSI pin
#define	HwTVEICNTL_ISYNC_VSI						HwTVEICNTL_ISYNC(4)							// Alignment input format from VSI pin
#define	HwTVEICNTL_ISYNC_ESAV_L						HwTVEICNTL_ISYNC(5)							// Alignment input format from EAV,SAV codes (line by line)
#define	HwTVEICNTL_ISYNC_ESAV_F						HwTVEICNTL_ISYNC(6)							// Alignment input format from EAV,SAV codes (frame by frame)
#define	HwTVEICNTL_ISYNC_FREE						HwTVEICNTL_ISYNC(7)							// Alignment is free running (Master mode)
#define	HwTVEICNTL_ISYNC_MASK						HwTVEICNTL_ISYNC(7)

// Offset Control
#define	HwTVEHVOFFST_INSEL(X)						((X)*Hw6)
#define	HwTVEHVOFFST_INSEL_BW16_27MHZ				HwTVEHVOFFST_INSEL(0)						// 16bit YUV 4:2:2 sampled at 27MHz
#define	HwTVEHVOFFST_INSEL_BW16_13P5MH				HwTVEHVOFFST_INSEL(1)						// 16bit YUV 4:2:2 sampled at 13.5MHz
#define	HwTVEHVOFFST_INSEL_BW8_13P5MHZ				HwTVEHVOFFST_INSEL(2)						// 8bit YUV 4:2:2 sampled at 13.5MHz
#define	HwTVEHVOFFST_INSEL_MASK						HwTVEHVOFFST_INSEL(3)
#define	HwTVEHVOFFST_VOFFST_256						Hw3											// Vertical offset bit 8 (Refer to HwTVEVOFFST)
#define	HwTVEHVOFFST_HOFFST_1024					Hw2											// Horizontal offset bit 10 (Refer to HwTVEHOFFST)
#define	HwTVEHVOFFST_HOFFST_512						Hw1											// Horizontal offset bit 9 (Refer to HwTVEHOFFST)
#define	HwTVEHVOFFST_HOFFST_256						Hw0											// Horizontal offset bit 8 (Refer to HwTVEHOFFST)

// Sync Output Control
#define	HwTVEHSVSO_VSOB_256							Hw6											// VSOB bit 8 (Refer to HwVSOB)
#define	HwTVEHSVSO_HSOB_1024						Hw5											// HSOB bit 10 (Refer to HwHSOB)
#define	HwTVEHSVSO_HSOB_512							Hw4											// HSOB bit 9 (Refer to HwHSOB)
#define	HwTVEHSVSO_HSOB_256							Hw3											// HSOB bit 8 (Refer to HwHSOB)
#define	HwTVEHSVSO_HSOE_1024						Hw2											// HSOE bit 10 (Refer to HwHSOE)
#define	HwTVEHSVSO_HSOE_512							Hw1											// HSOE bit 9 (Refer to HwHSOE)
#define	HwTVEHSVSO_HSOE_256							Hw0											// HSOE bit 8 (Refer to HwHSOE)

// Trailing Edge of Vertical Sync Control
#define	HwTVEVSOE_VSOST(X)							((X)*Hw6)									// Programs V-sync relative location for Odd/Even Fields.
#define	HwTVEVSOE_NOVRST_EN							Hw5											// No vertical reset on every field
#define	HwTVEVSOE_NOVRST_NORMAL						HwZERO										// Normal vertical reset operation (interlaced output timing)
#define	HwTVEVSOE_VSOE(X)							((X)*Hw0)									// Trailing Edge of Vertical Sync Control

// VBI Control Register
#define	HwTVEVCTRL_VBICTL(X)						((X)*Hw5)									// VBI Control indicating the current line is VBI.
#define	HwTVEVCTRL_VBICTL_NONE						HwTVEVCTRL_VBICTL(0)						// Do nothing, pass as active video.
#define	HwTVEVCTRL_VBICTL_10LINE					HwTVEVCTRL_VBICTL(1)						// Insert blank(Y:16, Cb,Cr: 128), for example, 10 through 21st line.
#define	HwTVEVCTRL_VBICTL_1LINE						HwTVEVCTRL_VBICTL(2)						// Insert blank data 1 line less for CC processing.
#define	HwTVEVCTRL_VBICTL_2LINE						HwTVEVCTRL_VBICTL(3)						// Insert blank data 2 line less for CC and CGMS processing.
#define	HwTVEVCTRL_MASK								HwTVEVCTRL_VBICTL(3)					
#define	HwTVEVCTRL_CCOE_EN							Hw4											// Closed caption odd field enable.
#define	HwTVEVCTRL_CCEE_EN							Hw3											// Closed caption even field enable.
#define	HwTVEVCTRL_CGOE_EN							Hw2											// Copy generation management system enable odd field.
#define	HwTVEVCTRL_CGEE_EN							Hw1											// Copy generation management system enable even field.
#define	HwTVEVCTRL_WSSE_EN							Hw0											// Wide screen enable.

// Connection between LCDC & TVEncoder Control
#define	HwTVEVENCON_EN_EN							Hw0											// Connection between LCDC & TVEncoder Enabled
#define	HwTVEVENCON_EN_DIS							~Hw0										// Connection between LCDC & TVEncoder Disabled

// I/F between LCDC & TVEncoder Selection
#define	HwTVEVENCIF_MV_1							Hw1											// reserved
#define	HwTVEVENCIF_FMT_1							Hw0											// PXDATA[7:0] => CIN[7:0], PXDATA[15:8] => YIN[7:0]
#define	HwTVEVENCIF_FMT_0							HwZERO										// PXDATA[7:0] => YIN[7:0], PXDATA[15:8] => CIN[7:0]



/************************************************************************
*   DDI_CONFIG (Base Addr = 0x72380000) // R/W
*************************************************************************/

#define HwDDI_CONFIG_BASE                       (0x12380000)

// Power Down
#define HwDDIC_PWDN_L2_LCLK                Hw18           // L2_LCLK(peri) Clock select
#define HwDDIC_PWDN_L1_LCLK                Hw17           // L1_LCLK(peri) Clock select
#define HwDDIC_PWDN_L0_LCLK                Hw16           // L0_LCLK(peri) Clock select

#define HwDDIC_PWDN_HDMI                      Hw2           // HDMI
#define HwDDIC_PWDN_NTSC                      Hw1            // NTSL/PAL
#define HwDDIC_PWDN_LCDC                       Hw0         // VIOC

// Soft Reset
#define HwDDIC_SWRESET_HDMI                  Hw2           // HDMI
#define HwDDIC_SWRESET_NTSC                  Hw1              // NTSL/PAL
#define HwDDIC_SWRESET_LCDC                   Hw0             // VIOC
#endif /* _PLATFORM_REG_PHYSICAL_H_ */
