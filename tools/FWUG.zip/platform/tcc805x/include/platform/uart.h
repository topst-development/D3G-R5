/****************************************************************************
 *
 * Copyright (C) 2016 Telechips Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions
 * andlimitations under the License.
 ****************************************************************************/

#ifndef _PLATFORM_TCC_UART_H_
#define _PLATFORM_TCC_UART_H_

#define DEBUG_UART 	0
#define DEBUG_CLK 	24000000 	// 24MHz

#define DEBUG_BR 	115200

#define PORT_BT 	1 	// Bluetooth port
//#define PORT_GPS 	2 	// GPS port

//------------------------------------------------
// USB to UART
//------------------------------------------------
#define DEBUG_USB_UART 	4
#define DEBUG_USB_BR 	115200
#define DEBUG_USB_CLK 	48000000 	// 48MHz

//#define DEBUG_USB_UART_PORT 	0x1C	// OTG Mux
#define DEBUG_USB_UART_PORT 	0x1E	// EHCI
//#define DEBUG_USB_UART_PORT 	0x1D	// XHCI

//********* NOTE : UART Controller #7 for Smart Card ***********//
#endif
