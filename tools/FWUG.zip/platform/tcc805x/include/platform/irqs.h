/****************************************************************************
 * Copyright (C) 2016 Telechips Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions
 * andlimitations under the License.
 ****************************************************************************/

#ifndef __PLATFORM_TCC805X_IRQS__H__
#define __PLATFORM_TCC805X_IRQS__H__

#define INT_GIC_OFFSET			(32)

#define MICOM_IRQ_CAN_FD_0_0	(0 + INT_GIC_OFFSET)
#define MICOM_IRQ_CAN_FD_0_1	(1 + INT_GIC_OFFSET)
#define MICOM_IRQ_CAN_FD_1_0	(2 + INT_GIC_OFFSET)
#define MICOM_IRQ_CAN_FD_1_1	(3 + INT_GIC_OFFSET)
#define MICOM_IRQ_CAN_FD_2_0	(4 + INT_GIC_OFFSET)
#define MICOM_IRQ_CAN_FD_2_1	(5 + INT_GIC_OFFSET)
#define MICOM_IRQ_WDT			(50 + INT_GIC_OFFSET)
#define MICOM_IRQ_SMBOX0_WRITE	(52 + INT_GIC_OFFSET)
#define MICOM_IRQ_SMBOX0_READ	(53 + INT_GIC_OFFSET)
#define MICOM_IRQ_NSMBOX0_WRITE	(54 + INT_GIC_OFFSET)
#define MICOM_IRQ_NSMBOX0_READ	(55 + INT_GIC_OFFSET)
#define MICOM_IRQ_SMBOX1_WRITE	(56 + INT_GIC_OFFSET)
#define MICOM_IRQ_SMBOX1_READ	(57 + INT_GIC_OFFSET)
#define MICOM_IRQ_NSMBOX1_WRITE	(58 + INT_GIC_OFFSET)
#define MICOM_IRQ_NSMBOX1_READ	(59 + INT_GIC_OFFSET)
#define MICOM_IRQ_MBOX2_WRITE	(60 + INT_GIC_OFFSET)
#define MICOM_IRQ_MBOX2_READ	(61 + INT_GIC_OFFSET)
#define MICOM_IRQ_PMIO			(103 + INT_GIC_OFFSET)
/* MICOM IRQ[479:104] = IRQ[375:0] */
#define SMU_IRQ_EXT_INT_0		(0 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT5			(162 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT6			(163 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT7			(164 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT0			(182 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT1			(183 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT2			(184 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT3			(185 + INT_GIC_OFFSET)
#define SMU_IRQ_CB_WDT4			(186 + INT_GIC_OFFSET)
#define SMU_IRQ_PMU_WDT			(190 + INT_GIC_OFFSET)
#define SMU_IRQ_CMB_MBOX0		(375 + INT_GIC_OFFSET)

#define MICOM_IRQ_EXT_INT_0		(SMU_IRQ_EXT_INT_0 + 104)
#define MICOM_IRQ_CB_WDT5		(SMU_IRQ_CB_WDT5 + 104)
#define MICOM_IRQ_CB_WDT6		(SMU_IRQ_CB_WDT6 + 104)
#define MICOM_IRQ_CB_WDT7		(SMU_IRQ_CB_WDT7 + 104)
#define MICOM_IRQ_CB_WDT0		(SMU_IRQ_CB_WDT0 + 104)
#define MICOM_IRQ_CB_WDT1		(SMU_IRQ_CB_WDT1 + 104)
#define MICOM_IRQ_CB_WDT2		(SMU_IRQ_CB_WDT2 + 104)
#define MICOM_IRQ_CB_WDT3		(SMU_IRQ_CB_WDT3 + 104)
#define MICOM_IRQ_CB_WDT4		(SMU_IRQ_CB_WDT4 + 104)
#define MICOM_IRQ_PMU_WDT		(SMU_IRQ_PMU_WDT + 104)
#define MICOM_IRQ_CMB_MBOX0		(SMU_IRQ_CMB_MBOX0 + 104)

#define IRQ_NUM					(479 + INT_GIC_OFFSET)
#define NR_IRQS					(IRQ_NUM + 1)

#endif /* __PLATFORM_TCC805X_IRQS__H__ */

