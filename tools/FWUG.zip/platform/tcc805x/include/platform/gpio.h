/****************************************************************************
 *
 * Copyright (C) 2016 Telechips Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions
 * andlimitations under the License.
 ****************************************************************************/

#ifndef __PLATFORM_GPIO_H
#define __PLATFORM_GPIO_H

#define GPIO_REG_SHIFT	6
#define GPIO_REGMASK	(0xF<<GPIO_REG_SHIFT)
#define GPIO_BITMASK	(0x3F<<0)

#define GPIO_PORTA	(0 << GPIO_REG_SHIFT)
#define GPIO_PORTB	(1 << GPIO_REG_SHIFT)
#define GPIO_PORTC	(2 << GPIO_REG_SHIFT)
#define GPIO_PORTE	(3 << GPIO_REG_SHIFT)
#define GPIO_PORTG	(4 << GPIO_REG_SHIFT)
#define GPIO_PORTH	(5 << GPIO_REG_SHIFT)
#define GPIO_PORTK	(6 << GPIO_REG_SHIFT)
#define GPIO_PORTSD0 (7 << GPIO_REG_SHIFT)		// MP GPIO Register
#define GPIO_PORTSD1 (8 << GPIO_REG_SHIFT)		// MP GPIO Register
#define GPIO_PORTSD2 (9 << GPIO_REG_SHIFT)		// MP GPIO Register
#define GPIO_PORTMA	(10 << GPIO_REG_SHIFT)
#define GPIO_PORTMB	(11 << GPIO_REG_SHIFT)
#define GPIO_PORTMC	(12 << GPIO_REG_SHIFT)
#define GPIO_PORTMD	(13 << GPIO_REG_SHIFT)
#define GPIO_PORTEXT1	(14 << GPIO_REG_SHIFT)
#define GPIO_PORTEXT2	(15 << GPIO_REG_SHIFT)

#define TCC_GPA(x)	(GPIO_PORTA | (x))
#define TCC_GPB(x)	(GPIO_PORTB | (x))
#define TCC_GPC(x)	(GPIO_PORTC | (x))
#define TCC_GPE(x)	(GPIO_PORTE | (x))
#define TCC_GPG(x)	(GPIO_PORTG | (x))
#define TCC_GPH(x)	(GPIO_PORTH | (x))
#define TCC_GPK(x)	(GPIO_PORTK | (x))
#define TCC_GPSD0(x)	(GPIO_PORTSD0 | (x))
#define TCC_GPSD1(x)	(GPIO_PORTSD1 | (x))
#define TCC_GPSD2(x)	(GPIO_PORTSD2 | (x))
#define TCC_GPMA(x)	(GPIO_PORTMA | (x))
#define TCC_GPMB(x)	(GPIO_PORTMB | (x))
#define TCC_GPMC(x)	(GPIO_PORTMC | (x))
#define TCC_GPMD(x)	(GPIO_PORTMD | (x))
#define TCC_GPEXT1(x)	(GPIO_PORTEXT1 | (x))
#define TCC_GPEXT2(x)	(GPIO_PORTEXT2 | (x))

#define GPIO_FN_SHIFT	27
#define GPIO_FN_BITMASK	(0x1F<<GPIO_FN_SHIFT)
#define GPIO_FN(x)	((x+1) << GPIO_FN_SHIFT)
#define GPIO_FN0	( 1 << GPIO_FN_SHIFT)
#define GPIO_FN1	( 2 << GPIO_FN_SHIFT)
#define GPIO_FN2	( 3 << GPIO_FN_SHIFT)
#define GPIO_FN3	( 4 << GPIO_FN_SHIFT)
#define GPIO_FN4	( 5 << GPIO_FN_SHIFT)
#define GPIO_FN5	( 6 << GPIO_FN_SHIFT)
#define GPIO_FN6	( 7 << GPIO_FN_SHIFT)
#define GPIO_FN7	( 8 << GPIO_FN_SHIFT)
#define GPIO_FN8	( 9 << GPIO_FN_SHIFT)
#define GPIO_FN9	(10 << GPIO_FN_SHIFT)
#define GPIO_FN10	(11 << GPIO_FN_SHIFT)
#define GPIO_FN11	(12 << GPIO_FN_SHIFT)
#define GPIO_FN12	(13 << GPIO_FN_SHIFT)
#define GPIO_FN13	(14 << GPIO_FN_SHIFT)
#define GPIO_FN14	(15 << GPIO_FN_SHIFT)
#define GPIO_FN15	(16 << GPIO_FN_SHIFT)

#define GPIO_CD_SHIFT	24
#define GPIO_CD_BITMASK	(0x7<<GPIO_CD_SHIFT)
#define GPIO_CD(x)	((x+1) << GPIO_CD_SHIFT)
#define GPIO_CD0	(1 << GPIO_CD_SHIFT)
#define GPIO_CD1	(2 << GPIO_CD_SHIFT)
#define GPIO_CD2	(3 << GPIO_CD_SHIFT)
#define GPIO_CD3	(4 << GPIO_CD_SHIFT)

void gpio_init_early(void);

#endif
