LOCAL_DIR := $(GET_LOCAL_DIR)

# shared platform code
OBJS += \
	$(LOCAL_DIR)/debug.o

