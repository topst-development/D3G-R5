#include <arch/arm/mpu.h>
#include <arch/defines.h>
#include <arch/ops.h>
#include <string.h>


/*****************************************************************************/
/*                                TYPE DEFINE                                */
/*****************************************************************************/
static const struct {
	unsigned int region_enable;
	unsigned int region_base;
	unsigned int region_size;
	unsigned int region_attr;
}mpu_table[MPU_MAX_REGION] = {
	{ 0x1, 0x08000000, REGION_128M, NSHARED_NCACHE | PRIV_RO_USER_RO},
};

/* Setup memory for this platform */
void platform_init_mpu_mappings(void)
{
    MPU_SetRegionByRegNum(MPU_REGION_NUM_SNOR, mpu_table[0].region_base, mpu_table[0].region_size, mpu_table[0].region_attr);

}

void MPU_SetRegionByRegNum(unsigned int  reg_num, unsigned int  addr, unsigned long long  size, unsigned int  attr)
{
    unsigned int  address = addr;
    unsigned int  Regionsize = 0;

    wcp(CP15_MPU_MEM_REG_NUMBER, reg_num);
    isb();

	Regionsize = size;
	Regionsize <<= 1;
	Regionsize |= REGION_EN;
    dsb();

    wcp(CP15_MPU_REG_BASEADDR, address);
    wcp(CP15_MPU_REG_ACL, attr);
    wcp(CP15_MPU_REG_SIZE_EN, Regionsize);

    dsb();
    isb();
}

#if 0 //not used
mpu_cfg mpucfg;

void MPU_EnableMPU(void)
{
    unsigned int  CtrlReg;

    CtrlReg = rcp("p15, 0, %0, c1, c0, 0");
    arch_disable_cache(UCACHE);

    CtrlReg = rcp("p15, 0, %0, c1, c0, 0");
    CtrlReg |= 0x00000001U;

    dsb();
    wcp("p15, 0, %0, c1, c0, 0", CtrlReg);
    isb();


    arch_enable_cache(UCACHE);
}

void MPU_DisableMPU(void)
{
    unsigned int  CtrlReg;

    CtrlReg = rcp("p15, 0, %0, c1, c0, 0");
    arch_disable_cache(UCACHE);

    wcp("p15, 0, %0, c7, c5, 6", 0); // invalidata branch prediction

    CtrlReg = rcp("p15, 0, %0, c1, c0, 0");
    CtrlReg &= ~(0x00000001U);

    dsb();
    wcp("p15, 0, %0, c1, c0, 0", CtrlReg);
    isb();

    arch_enable_cache(UCACHE);
}

unsigned int  MPU_UpdateConfig(unsigned int  reg_num, unsigned int  addr, unsigned int  size, unsigned int  attr)
{
    unsigned int  ret = 0;
    unsigned int  reg_size = size;

    if(reg_num > MPU_MAX_REGION){
        /* PUT Debug Message */
        ret = 1;
        goto exit;
    }

    if(size & REGION_EN){
        mpucfg[reg_num].RegionEnable = MPU_ENABLE;
        mpucfg[reg_num].BaseAddress = addr;
        reg_size &= ~(REGION_EN);
        reg_size >>= 1;

        mpucfg[reg_num].Size = reg_size;
        mpucfg[reg_num].Attribute = attr;
    }else{
        mpucfg[reg_num].RegionEnable = 0U;
        mpucfg[reg_num].BaseAddress = 0U;
        mpucfg[reg_num].Size = 0U;
        mpucfg[reg_num].Attribute = 0U;
    }

exit:
    return ret;
}

void MPU_GetConfig(mpu_cfg config)
{
    unsigned int  index = 0;

    while(index < MPU_MAX_REGION){
        config[index].RegionEnable = mpucfg[index].RegionEnable;
        config[index].BaseAddress = mpucfg[index].BaseAddress;
        config[index].Attribute = mpucfg[index].Attribute;
        config[index].Size = mpucfg[index].Size;
        index++;
    }
}

unsigned int  MPU_GetNumberofFreeRegions(void)
{
    unsigned int  index = 0U;
    int nFreeRegions = 0U;

    while(index < MPU_MAX_REGION){
        if(MPU_DISABLED == mpucfg[index].RegionEnable)
            nFreeRegions++;

        index++;
    }

    return nFreeRegions;
}

unsigned int  MPU_GetFreeRegMask(void)
{

    unsigned int  index = 0;
    unsigned int  FreeRegMask = 0;

    while(index < MPU_MAX_REGION){
        if(MPU_DISABLED == mpucfg[index].RegionEnable)
            FreeRegMask |= (0x1<<index);

        index++;
    }

    return FreeRegMask;
}

unsigned int  MPU_DisableRegionByNum(unsigned int  reg_num)
{

    unsigned int  CtrlReg = 0;
    unsigned int  ret = 0;

    if(reg_num > MPU_MAX_REGION){
        /* debug print out */
        ret = 1;
        goto exit;
    }

    arch_disable_cache(UCACHE);

    wcp(CP15_MPU_MEM_REG_NUMBER, reg_num);
    CtrlReg = rcp(CP15_MPU_REG_SIZE_EN);
    CtrlReg &= ~(REGION_EN);

    dsb();
    wcp(CP15_MPU_REG_SIZE_EN, CtrlReg);
    dsb();
    isb();

    MPU_UpdateConfig(reg_num, 0, 0, 0);

    arch_enable_cache(UCACHE);

exit:
    return ret;
}

void MPU_InitializeExistingRegConfig(void)
{
    unsigned int  idx0=0;

    unsigned int  MPURegSize;
    unsigned int  MPURegBaseaddr;
    unsigned int  MPURegAttr;

    unsigned int  RegionSize = 0;

	memset(mpucfg, 0x0 , sizeof(mpu_cfg));

    while(idx0 < MPU_MAX_REGION){
        wcp(CP15_MPU_MEM_REG_NUMBER, idx0);
        MPURegSize = rcp(CP15_MPU_REG_SIZE_EN);
        MPURegBaseaddr = rcp(CP15_MPU_REG_BASEADDR);
        MPURegAttr = rcp(CP15_MPU_REG_ACL);

        if(MPURegSize & REGION_EN){
            mpucfg[idx0].RegionEnable = MPU_ENABLE;
            mpucfg[idx0].BaseAddress = MPURegBaseaddr;
            mpucfg[idx0].Attribute = MPURegAttr;

            RegionSize = (MPURegSize & ~(REGION_EN));
            RegionSize >>=1;

			mpucfg[idx0].Size = RegionSize;
		}
		idx0++;
	}
}

unsigned int  MPU_GetNextRegion(void)
{
    unsigned int  index = 0;
    unsigned int  NextAvailableReg = 0xFF;

    while(index < MPU_MAX_REGION){
        if(mpucfg[index].RegionEnable != MPU_ENABLE){
            NextAvailableReg = index;
        }

        index++;
    }

    return NextAvailableReg;

}
#endif
