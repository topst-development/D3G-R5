/*****************************************************************************/
/**
* @file mmp.h
*
* @ r5_mpu_apis Cortex R5 Processor MPU specific APIs
*
* MPU functions provides access to MPU operations such as enable MPU, disable
* MPU and set attrute for section of memory.
* Boot code invokes Init_MPU function to configure the MPU. A total of 10 MPU
* regions are allocated with another 6 being free for users. Overview of the
* memory attrutes for different MPU regions is as given below,
*
*|                       | Memory Range            | attrutes of MPURegion                    |
*|-----------------------|-------------------------|------------------------------------------- |
*| ALL                   | 0x00000000 - 0xFFFFFFFF | Normal write-back Cacheable                |
*| PL                    | 0x80000000 - 0xBFFFFFFF | write-back noalloc ap_read only            |
*| QSPI                  | 0xC0000000 - 0xDFFFFFFF | Device Memory                              |
*| PCIe                  | 0xE0000000 - 0xEFFFFFFF | Device Memory                              |
*| STM_CORESIGHT         | 0xF8000000 - 0xF8FFFFFF | Device Memory                              |
*| RPU_R5_GIC            | 0xF9000000 - 0xF90FFFFF | Device memory                              |
*| FPS                   | 0xFD000000 - 0xFDFFFFFF | Device Memory                              |
*| LPS                   | 0xFE000000 - 0xFFFFFFFF | Device Memory                              |
*| OCM                   | 0xFFFC0000 - 0xFFFFFFFF | Normal write-back Cacheable                |
*
* ********************************************************************************/

#ifndef MPU_H
#define MPU_H


#define MPU_DISABLED    0x0
#define MPU_ENABLE      0x1

/* Only SNOR region needs to be set */
#define MPU_MAX_REGION      1U
/* SNOR region number is 6, refer to the mpu settings in R5 mcu bsp(main F/W) */
#define MPU_REGION_NUM_SNOR 6UL


/* CP15 operation */

#define wcp(rn, val) __asm__ __volatile__("mcr " rn : : "r" (val));
#define rcp(rn) ({unsigned int  rval = 0U;\
                __asm__ __volatile__("mrc " rn : "=r" (rval));\
                rval;})


#define CP15_MPU_TYPE           "p15, 0, %0, c0, c0, 4"
#define CP15_MPU_REG_BASEADDR   "p15, 0, %0, c6, c1, 0"
#define CP15_MPU_REG_SIZE_EN    "p15, 0, %0, c6, c1, 2"
#define CP15_MPU_REG_ACL        "p15, 0, %0, c6, c1, 4"
#define CP15_MPU_MEM_REG_NUMBER "p15, 0, %0, c6, c2, 0"

/*MPU region definitions*/
#define REGION_32B     0x00000004U
#define REGION_64B     0x00000005U
#define REGION_128B    0x00000006U
#define REGION_256B    0x00000007U
#define REGION_512B    0x00000008U
#define REGION_1K      0x00000009U
#define REGION_2K      0x0000000AU
#define REGION_4K      0x0000000BU
#define REGION_8K      0x0000000CU
#define REGION_16K     0x0000000DU
#define REGION_32K     0x0000000EU
#define REGION_64K     0x0000000FU
#define REGION_128K    0x00000010U
#define REGION_256K    0x00000011U
#define REGION_512K    0x00000012U
#define REGION_1M      0x00000013U
#define REGION_2M      0x00000014U
#define REGION_4M      0x00000015U
#define REGION_8M      0x00000016U
#define REGION_16M     0x00000017U
#define REGION_32M     0x00000018U
#define REGION_64M     0x00000019U
#define REGION_128M    0x0000001AU
#define REGION_256M    0x0000001BU
#define REGION_512M    0x0000001CU
#define REGION_1G      0x0000001DU
#define REGION_2G      0x0000001EU
#define REGION_4G      0x0000001FU

#define REGION_EN      0x00000001U

#define SHAREABLE               0x00000004U     /*shareable */
#define STRONG_ORDERD_SHARED    0x00000000U     /*strongly ordered, always shareable*/

#define DEVICE_SHARED           0x00000001U     /*device, shareable*/
#define DEVICE_NONSHARED        0x00000010U     /*device, non shareable*/

#define NSHARED_WT_NWA     0x00000002U     /*Outer and Inner write-through, no write-allocate non-shareable*/
#define SHARED_WT_NWA      0x00000006U     /*Outer and Inner write-through, no write-allocate shareable*/

#define NSHARED_WB_NWA     0x00000003U     /*Outer and Inner write-back, no write-allocate non shareable*/
#define SHARED_WB_NWA      0x00000007U     /*Outer and Inner write-back, no write-allocate shareable*/

#define NSHARED_NCACHE     0x00000008U     /*Outer and Inner Non cacheable  non shareable*/
#define SHARED_NCACHE      0x0000000CU     /*Outer and Inner Non cacheable shareable*/

#define NSHARED_WB_WA      0x0000000BU     /*Outer and Inner write-back non shared*/
#define SHARED_WB_WA       0x0000000FU     /*Outer and Inner write-back shared*/

/* inner and outer cache policies can be combined for different combinations */

#define IN_POLICY_NCACHE   0x00000020U     /*inner non cacheable*/
#define IN_POLICY_WB_WA    0x00000021U     /*inner write back write allocate*/
#define IN_POLICY_WT_NWA   0x00000022U     /*inner write through no write allocate*/
#define IN_POLICY_WB_NWA   0x00000023U     /*inner write back no write allocate*/

#define OUT_POLICY_NCACHE  0x00000020U     /*outer non cacheable*/
#define OUT_POLICY_WB_WA   0x00000028U     /*outer write back write allocate*/
#define OUT_POLICY_WT_NWA  0x00000030U     /*outer write through no write allocate*/
#define OUT_POLICY_WB_NWA  0x00000038U     /*outer write back no write allocate*/

#define NO_ACCESS               (0x00000000U<<8U)   /*No access*/
#define PRIV_RW_USER_NA         (0x00000001U<<8U)   /*Privileged access only*/
#define PRIV_RW_USER_RO         (0x00000002U<<8U)   /*Writes in User mode generate permission faults*/
#define PRIV_RW_USER_RW         (0x00000003U<<8U)   /*Full Access*/
#define PRIV_RO_USER_NA         (0x00000005U<<8U)   /*Privileged eead only*/
#define PRIV_RO_USER_RO         (0x00000006U<<8U)   /*Privileged/User read-only*/

#define EXECUTE_NEVER           (0x00000001U<<12U)  /* Bit 12*/

struct mpuconfig {
    unsigned int  RegionEnable; /* Reagion Enable / Disable */
    unsigned int  BaseAddress;  /* MPU Region Base Address */
    unsigned int  Size;         /* MPU Region Size */
    unsigned int  Attribute;    /* MPU Region Attribute */
};


typedef struct mpuconfig mpu_cfg[MPU_MAX_REGION];
extern mpu_cfg  mpucfg;

void MPU_SetRegionByRegNum (unsigned int  reg_num, unsigned int  addr, unsigned long long  size, unsigned int  attr);

#if 0 //not used
void EnableMPU(void);
void DisableMPU(void);
unsigned int  MPU_SetRegion(unsigned int  addr, unsigned long long  size, unsigned int  attr);
unsigned int  MPU_UpdateConfig(unsigned int  reg_num, unsigned int  addr, unsigned int  size, unsigned int  attr);
void MPU_GetConfig (mpu_cfg mpucfg);
unsigned int  MPU_GetNumOfFreeRegions (void);
unsigned int  MPU_GetNextRegion(void);
unsigned int  MPU_DisableRegionByRegNum (unsigned int  reg_num);
unsigned int  MPU_GetFreeRegMask (void);
#endif

#endif
