/**/

#include <compiler.h>

__WEAK void get_canary(void)
{
}

__WEAK unsigned int TNFTL_CalcCRC(void)
{
	return 0;
}

__WEAK unsigned int FWUG_CalcCrc8I(void)
{
	return 0;
}

__WEAK void *dma_alloc(void)
{
	return 0;
}

__WEAK unsigned int smc_sip_service(void)
{
	return 0;
}