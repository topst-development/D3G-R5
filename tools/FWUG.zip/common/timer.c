/*
 * Copyright (c) 2008, Google Inc.
 * Copyright (c) 2013 Telechips, Inc.
 * All rights reserved.
 *
 * Copyright (c) 2009-2011, The Linux Foundation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  * Neither the name of Google, Inc. nor the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <debug.h>
#include <reg.h>
#include <sys/types.h>

#include <platform/timer.h>
#include <platform/irqs.h>
#include <platform/iomap.h>
#include <platform/interrupts.h>
#include <platform/tcc_ckc.h>
#include <clock.h>

#define TIMER_REG(off)	*REG32(TCC_TIMER_BASE + (off))

#define TIMER_MAX_NUM	6

#define TIMER0		0x00
#define TIMER1		0x20
#define TIMER2		0x40
#define TIMER3		0x60
#define TIMER4		0x80
#define TIMER5		0xA0

#define TIMER_OP_EN_CFG	    0x00
#define TIMER_MAIN_CNT_LVD	0x04
#define TIMER_CMP0	        0x08
#define TIMER_CMP1	        0x0C
#define TIMER_PSCL_CNT	    0x10
#define TIMER_MAIN_CNT	    0x14
#define TIMER_IRQ_CTRL	    0x18

#define TIMER_TICK_RATE	12000000

static volatile uint32_t ticks = 0;
static time_t tick_interval = 10;

time_t current_time(void)
{

    return readl((TCC_TIMER_BASE+TIMER_MAIN_CNT)) * tick_interval;

}

void platform_uninit_timer(void)
{
    writel((readl(TCC_TIMER_BASE+ TIMER_OP_EN_CFG) & ~(1<<24)), (TCC_TIMER_BASE+TIMER_OP_EN_CFG));
}

void mdelay(unsigned msecs)
{
    unsigned int ref;
    ref = (readl(TCC_TIMER_BASE + TIMER_MAIN_CNT) + (msecs * 1000));
    while(readl(TCC_TIMER_BASE + TIMER_MAIN_CNT) < ref);
}

void udelay(unsigned usecs)
{

    unsigned int ref;
    ref = (readl(TCC_TIMER_BASE + TIMER_MAIN_CNT) + usecs);
    while(readl(TCC_TIMER_BASE + TIMER_MAIN_CNT) < ref);
}

/* Initialize timer */
void timer_init_early(void)
{
    /* PCLK TIMER 0 Clock need to setup */

    writel(0x0, (TCC_TIMER_BASE+TIMER_OP_EN_CFG));

    writel((readl(TCC_TIMER_BASE+ TIMER_OP_EN_CFG) | (0xB<<0)), (TCC_TIMER_BASE+TIMER_OP_EN_CFG));
    writel(0x0 , (TCC_TIMER_BASE+TIMER_MAIN_CNT_LVD));
    writel((readl(TCC_TIMER_BASE+ TIMER_OP_EN_CFG) | (1<<24)), (TCC_TIMER_BASE+TIMER_OP_EN_CFG));
}
