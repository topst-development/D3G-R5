/*
 * Copyright (c) 2008 Travis Geiselbrecht
 *
 * Copyright (c) 2009-2014, The Linux Foundation. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include <compiler.h>
#include <debug.h>
#include <string.h>
#include <arch.h>
#include <reg.h>
#include <lib/heap.h>
#include <kernel/thread.h>
#include <platform/timer.h>
#include <platform/config.h>
#include <platform/iomap.h>
#include <platform/interrupts.h>
//#include <mbox.h>
#include <mbox_phy.h>
#include <mbox_dev.h>
#include <fwug_protocol.h>


#define VERSION_INFO	"0.01"

#if 0
#define WRITE_IN_BYTES			(256)
#define SNOR_SECTOR_SIZE		(4096)
#endif

int critical_section_count = 0;

void cmain(void) __NO_RETURN __EXTERNALLY_VISIBLE;
extern void timer_init_early(void);
extern void platform_init_interrupts(void);
extern void platform_init_mpu_mappings(void);


#if 0 //Not supported yet
static void armtf_reboot(MBOX_CH ch, const mboxData * pMboxData, int32 uiMboxRet)
{
	if((pMboxData->cmd[0] == CTRL_ARMTF) && (pMboxData->cmd[2] == (CMD_A53_REBOOT<<16))) {
		dprintf(INFO, "Coretx-A53MP Request to System Reboot : %s \n", (char*)pMboxData->cmd);

		while(1){
			if((readl(0x17100040) & (0xF<<16)) !=0 )
				break;
		}

		writel(0x1, 0x1b93617c);

	} else {
		dprintf(INFO, "armtf_reboot fail\n");
	}
}
#endif

#if 0 //Not supported yet
static void armtf_mbox_init(void)
{
	tcc_mbox_open(MBOX_CH_CA53_NS, MBOX_APP_ID_ARMTF/*id*/, INT_LEVEL_8, (mbox_callback)armtf_reboot);
}
#endif

static int is_update_flag_set()
{
	unsigned int update_flag = SNOR_UPDATE_FLAG;

	if (memcmp((const void *)(TCC_SNOR_BASE + SNOR_UPDATE_FLAG_OFFSET), (const void *)&update_flag, 4) == 0) {
		return TRUE;
	}

	return FALSE;
}

static int is_micom_fw_valid()
{
	/* To Do: */

	return TRUE;
}

void cmain(void)
{
	dprintf(INFO, "\nWelcome to R5 Sub f/w Ver %s\n", VERSION_INFO);

	heap_init();
	timer_init_early();
	platform_init_interrupts();

    platform_init_mpu_mappings();
#if 0 //Not supported yet
	armtf_mbox_init();
#endif
	if (is_update_flag_set() == FALSE) {
		if (is_micom_fw_valid() == FALSE) {
			/* To Do:
			 * 1. Recovery Mode
			 * 2. Suspend & Resume
			 * */

			//writel(0x1, 0x1b93617x); //Cold Reset
		}

	}

    FWUG_InitProtocol();
    FWUG_Process();

	while(1)
		arch_idle();
}
