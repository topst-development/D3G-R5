/****************************************************************************************
 *   FileName    : fwug_protocol.h
 *   Description :
 ****************************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips Inc.
 *   All rights reserved

This source code contains confidential information of Telechips.
Any unauthorized use without a written permission of Telechips including not limited
to re-distribution in source or binary form is strictly prohibited.
This source code is provided ��AS IS�� and nothing contained in this source code
shall constitute any express or implied warranty of any kind, including without limitation,
any warranty of merchantability, fitness for a particular purpose or non-infringement of any patent,
copyright or other third party intellectual property right.
No warranty is made, express or implied, regarding the information��s accuracy,
completeness, or performance.
In no event shall Telechips be liable for any claim, damages or other liability arising from,
out of or in connection with this source code or the use in the source code.
This source code is provided subject to the terms of a Mutual Non-Disclosure Agreement
between Telechips and Company.
*
****************************************************************************************/

#ifndef __FWUG_PROTOCOL_H__
#define __FWUG_PROTOCOL_H__

//#define SNOR_SECTOR_SIZE 4096
#define MAX_FW_BUF_SIZE 256
#define SNOR_UPDATE_FLAG_OFFSET	0x00126000
#define SNOR_UPDATE_FLAG 0x47555746 //FWUG

typedef enum {
    FWUG_CMD_UPDATE_START = 0x01,
    FWUG_CMD_UPDATE_READY,
    FWUG_CMD_UPDATE_FW_START,
    FWUG_CMD_UPDATE_FW_READY,
    FWUG_CMD_UPDATE_FW_SEND,
    FWUG_CMD_UPDATE_FW_SEND_ACK,
    FWUG_CMD_UPDATE_FW_DONE,
    FWUG_CMD_UPDATE_FW_COMPLETE,
    FWUG_CMD_UPDATE_DONE,
    FWUG_CMD_UPDATE_COMPLETE,
    FWUG_CMD_UPDATE_MAX,
}FWUG_MBOX_CMD;

typedef enum {
    FWUG_ACK = 0x01,
    FWUG_NACK
}FWUG_ACK_ID;

typedef enum {
    FWUG_NACK_NO = 0x00,
    FWUG_NACK_UPDATER_LOAD_FAIL,
    FWUG_NACK_SNOR_INIT_FAIL,
    FWUG_NACK_SNOR_ACCESS_FAIL,
    FWUG_NACK_CRC_ERR,
    FWUG_NACK_SNOR_ERASE_FAIL,
    FWUG_NACK_SNOR_WRITE_FAIL,
    FWUG_NACK_COUNT_ERR,
    FWUG_NACK_MAX,
}FWUG_NACK_TYPE;

typedef enum {
    FWUG_STATUS_IDLE = 0x00,
    FWUG_STATUS_READY,
    FWUG_STATUS_MAX,
} FWUG_CMD_STATUS;

typedef struct _FWUG_COMMAND_INFO {
    FWUG_CMD_STATUS status; //current status
    FWUG_MBOX_CMD id; //current command
    uint32 fwDataCnt; //current F/W data count
    int32 error; //current error type
} FWUG_COMMAND_INFO_T;

typedef struct _FWUG_INFO {
    FWUG_COMMAND_INFO_T current_cmd;
} FWUG_INFO_T;

typedef struct _FWUG_DEV {
    mbox_dvice_t *dev;
} FWUG_DEV_T;

#define MAX_MBOX_CMD_FIFO_CNT	8
#define MAX_MBOX_DATA_FIFO_CNT	128

typedef struct _FWUG_MSG {
	uint32 cmd[MAX_MBOX_CMD_FIFO_CNT];
	uint32 data[MAX_MBOX_DATA_FIFO_CNT];
} FWUG_MSG_T;

#define HSM_MBOX_GET_VERSION 0x20010000u
#define HSM_MBOX_VERIFY_STOP 0x00060000u

extern void FWUG_InitProtocol(void);
extern void FWUG_Process(void);

#endif /* __FWUG_PROTOCOL_H__ */
