/****************************************************************************
 *
 * Copyright (C) 2014 Telechips Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions
 * andlimitations under the License.
 ****************************************************************************/

#ifndef __CLOCK_H__
#define __CLOCK_H__

#include <sys/types.h>

#ifndef ENABLE
#define ENABLE 1
#endif
#ifndef DISABLE
#define DISABLE 0
#endif

enum {
	CKC_OK = 0,
	CKC_FAILED,
	CKC_INVALIED_SRC,
	CKC_NO_OPS_DATA = 10,
};

typedef enum {
	PLLDIV_0 = 0,	/* Disable */
	PLLDIV_2 = 2,	/* 1/2 */
	PLLDIV_3,	/* 1/3 */
	PLLDIV_4,	/* 1/4 */
} plldiv_t;

struct tcc_ckc_ops {
	/* pll */
	int (*ckc_pll_set_rate)(int id, uint32_t rate);
	uint32_t (*ckc_pll_get_rate)(int id);
	int (*ckc_plldiv_set)(int id, uint32_t div);

	/* clkctrl */
	int (*ckc_clkctrl_enable)(int id);
	int (*ckc_clkctrl_disable)(int id);
	int (*ckc_clkctrl_set_rate)(int id, uint32_t rate);
	uint32_t (*ckc_clkctrl_get_rate)(int id);

	/* peripheral */
	int (*ckc_peri_enable)(int id);
	int (*ckc_peri_set_rate)(int id, uint32_t rate);
	uint32_t (*ckc_peri_get_rate)(int id);

	/* io bus */
	int (*ckc_iobus_pwdn)(int id, bool pwdn);
	int (*ckc_iobus_swreset)(int id, bool reset);

	/* hsio bus */
	int (*ckc_hsiobus_pwdn)(int id, bool pwdn);
	int (*ckc_hsiobus_swreset)(int id, bool reset);
};

extern void tcc_ckc_set_ops(struct tcc_ckc_ops *ops);

extern int tcc_set_pll(int id, bool en, uint32_t rate, plldiv_t div);
extern uint32_t tcc_get_pll(int id);
extern int tcc_set_clkctrl(int id, bool en, uint32_t rate);
extern uint32_t tcc_get_clkctrl(int id);
extern int tcc_set_peri(int bus_type, bool en, uint32_t rate);
extern uint32_t tcc_get_peri(int id);
extern int tcc_set_ddibus_pwdn(int id, bool pwdn);
extern int tcc_set_ddibus_swreset(int id, bool reset);
extern int tcc_set_iobus_pwdn(int id, bool pwdn);
extern int tcc_set_iobus_swreset(int id, bool reset);
extern int tcc_set_hsiobus_pwdn(int id, bool pwdn);
extern int tcc_set_hsiobus_swreset(int id, bool reset);

#if defined(TCC805X) && defined(HDMI_V2_0)
extern void tcc_ckc_isoip_hdmi_pwdn(bool pwdn);
#endif

#endif /* __CLOCK_H__ */
