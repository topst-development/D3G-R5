LOCAL_DIR := $(GET_LOCAL_DIR)

INCLUDES += -I$(LOCAL_DIR)/include

MODULES += \
	lib/libc \
	lib/debug \
	lib/heap

OBJS += \
	$(LOCAL_DIR)/main.o \
	$(LOCAL_DIR)/debug.o \
	$(LOCAL_DIR)/div64.o \
	$(LOCAL_DIR)/timer.o \
	$(LOCAL_DIR)/fwug_protocol.o


OBJS += $(LOCAL_DIR)/dummy_func.o
