make tcc805x clean; make tcc805x -j12;
cp build-tcc805x/r5_sub_fw.rom ../../boot-firmware/prebuilt/r5_sub_fw.rom
